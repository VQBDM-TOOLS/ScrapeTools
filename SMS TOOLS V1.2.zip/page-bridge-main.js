(() => {
  const AUTH = new Set([
    "authorization","x-authorization","x-access-token","x-auth-token",
    "access-token","x-token","token"
  ]);

  function emit(headers, url) {
    const clean = {};
    for (const [k,v] of Object.entries(headers || {})) {
      const n = String(k).toLowerCase();
      if (AUTH.has(n) && typeof v === "string" && v) clean[k] = v;
    }
    if (Object.keys(clean).length) {
      window.postMessage({
        source: "BANTUSAKU_AUTH_BRIDGE",
        type: "AUTH",
        headers: clean,
        url: String(url || location.href)
      }, location.origin);
    }
  }

  const originalFetch = window.fetch;
  window.fetch = function(input, init) {
    try {
      const url = typeof input === "string" ? input : (input && input.url) || "";
      const h = new Headers(
        (init && init.headers) ||
        (input && input.headers) ||
        undefined
      );
      const obj = {};
      h.forEach((v,k) => obj[k] = v);
      emit(obj, url);
    } catch (_) {}
    return originalFetch.apply(this, arguments);
  };

  const originalOpen = XMLHttpRequest.prototype.open;
  const originalSet = XMLHttpRequest.prototype.setRequestHeader;
  const originalSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function(method, url) {
    try { this.__bs_url = url; } catch (_) {}
    return originalOpen.apply(this, arguments);
  };

  XMLHttpRequest.prototype.setRequestHeader = function(name, value) {
    try {
      const n = String(name).toLowerCase();
      if (AUTH.has(n)) {
        this.__bs_auth = this.__bs_auth || {};
        this.__bs_auth[name] = value;
      }
    } catch (_) {}
    return originalSet.apply(this, arguments);
  };

  XMLHttpRequest.prototype.send = function() {
    try { emit(this.__bs_auth || {}, this.__bs_url || ""); } catch (_) {}
    return originalSend.apply(this, arguments);
  };
})();