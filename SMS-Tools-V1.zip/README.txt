SMS TOOLS V1 v1.0.7

Perbaikan v5:
- Memperbaiki bug utama v1.0.4: workflow scraper/SMS memanggil fungsi API yang salah.
- Case, Contact, dan SMS sekarang menggunakan pageApiPost yang benar.
- Response Contact disesuaikan dengan format API aplikasi lama:
  data = array
  contactPhone / contactType / relationship
- CSV parser SMS diperbaiki untuk newline normal.
- Tetap tanpa input Bearer Token.
- Request dijalankan dalam konteks halaman SOSI dan menggunakan session browser.
- Header auth yang terlihat dari request halaman hanya disimpan sementara.

INSTALL:
1. chrome://extensions
2. Remove versi BantuSaku sebelumnya.
3. Load unpacked folder v1.0.7.
4. Login ke https://cco-agent.bantusaku.id/
5. Refresh halaman SOSI.
6. Pastikan tab SOSI aktif.
7. Buka extension.
8. Cek Login Aktif.
9. Jalankan Scrape.

Jika login sudah hijau tetapi scraper tidak berjalan, buka tab LOG extension.


PERBAIKAN OUTPUT v1.0.6:
- Memperbaiki escape newline/UTF-8 BOM/CR pada CSV parser dan generator.
- Memperbaiki regex numerik Case ID dan Phone ID.
- Output Contacts dan Template/Hasil SMS sekarang .xlsx native (tanpa mengubah nilai menjadi angka), sehingga leading zero pada Mobile/Phone ID tetap dipertahankan saat dibuka di Excel.
- CSV tetap didukung untuk input SMS.


PERBAIKAN OUTPUT v1.0.7:
- Output Excel disesuaikan mengikuti format Tools awal.
- Workbook memiliki sheet SMS CH, SMS EC, SET UP TEMPLATE, dan Petunjuk.
- SMS CH memakai contact Phone Type=MYSELF; jika tidak ada, memakai fallback dari Case.
- SMS EC otomatis memuat pesan dengan rumus nama CH berdasarkan Case ID.
- Lebar kolom, header, filter, freeze pane, dan gaya tabel disesuaikan.
- Output scraper otomatis diunduh setelah proses selesai.
