const API_HOST = "cco-agent.bantusaku.id";
const AUTH_NAMES = new Set([
  "authorization","x-authorization","x-access-token","x-auth-token",
  "access-token","x-token","token"
]);

chrome.webRequest.onBeforeSendHeaders.addListener(
  async (details) => {
    if (!details.url.startsWith("https://" + API_HOST + "/api/")) return;
    const found = {};
    for (const h of (details.requestHeaders || [])) {
      const n = (h.name || "").toLowerCase();
      if (AUTH_NAMES.has(n) && h.value) found[h.name] = h.value;
    }
    if (Object.keys(found).length) {
      await chrome.storage.session.set({
        capturedAuth: found,
        capturedAt: Date.now(),
        capturedUrl: details.url
      });
    }
  },
  { urls: ["https://" + API_HOST + "/api/*"] },
  ["requestHeaders", "extraHeaders"]
);

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === "capturePageAuth") {
    const auth = {};
    for (const [k, v] of Object.entries(msg.headers || {})) {
      if (typeof v === "string" && v && v.length < 5000) auth[k] = v;
    }
    if (Object.keys(auth).length) {
      chrome.storage.session.set({
        capturedAuth: auth,
        capturedAt: Date.now(),
        capturedUrl: msg.url || ""
      }).then(() => sendResponse({ok: true}));
    } else {
      sendResponse({ok: false});
    }
    return true;
  }

  if (msg?.type === "getCapturedAuth") {
    chrome.storage.session.get(["capturedAuth","capturedAt","capturedUrl"])
      .then(x => sendResponse({
        auth: x.capturedAuth || {},
        capturedAt: x.capturedAt || 0,
        capturedUrl: x.capturedUrl || ""
      }));
    return true;
  }

  if (msg?.type === "clearCapturedAuth") {
    chrome.storage.session.remove(["capturedAuth","capturedAt","capturedUrl"])
      .then(() => sendResponse({ok: true}));
    return true;
  }
});
