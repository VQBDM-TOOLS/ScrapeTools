# BantuSaku Scraper Tools - Cloud License Extension Only

Versi ini tidak membutuhkan install_agent.bat, Setup_Client.bat, Python, Windows Service, atau aplikasi tambahan.

## Instalasi Client
1. Extract ZIP.
2. Buka Chrome -> chrome://extensions
3. Aktifkan Developer mode.
4. Klik Load unpacked.
5. Pilih folder `work_cloud`.
6. Buka extension BantuSaku Scraper Tools.
7. Masukkan License Key dari Owner.
8. Klik AKTIVASI.
9. Setelah aktif, gunakan scraper.

## Catatan binding
Versi extension-only membuat Device ID acak yang disimpan di `chrome.storage.local`. Server Cloudflare mengikat license ke Device ID tersebut.

Ini bukan Hardware ID Windows sejati. Menghapus data extension / browser profile dapat membuat Device ID baru. Jika terjadi, Owner perlu melakukan RESET PC/Binding sebelum license dapat diaktivasi kembali.


## Alur Menu Client
Extension hanya memiliki 2 menu:
1. **LICENSE** — menu wajib untuk memasukkan dan memvalidasi License Key.
2. **SCRAPE** — terkunci dan tidak dapat dibuka sebelum license valid.

Jika license expired, revoked, device mismatch, atau server menyatakan license tidak aktif, menu **SCRAPE otomatis dikunci kembali** dan client dikembalikan ke **LICENSE**.


## Output Template
Output Excel mengikuti struktur workbook contoh: Sheet, EC & CH, DATA NASABAH, EMERGENCY CONTACT, SUMMARY, RAW USER INFO, RAW CONTACT JSON, RAW CASE JSON, dan INFO. EC & CH serta EMERGENCY CONTACT memakai kolom `caseId, contactName, contactPhone, contactType, Nama CH, DPD, Ammount`.
