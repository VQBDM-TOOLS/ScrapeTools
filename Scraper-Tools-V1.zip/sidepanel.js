const PRODUCTS = new Set(["Scraper Tools V1", "BantuSaku Scraper Pro"]);



const $=id=>document.getElementById(id);

let apiModalBusy=false;

function showApiModal(title="API belum terdeteksi", text="Session API pada tab Chrome aktif belum terdeteksi. Silakan refresh halaman lalu coba lagi.", hint="Pastikan Anda sudah login di cco-agent.bantusaku.id."){
  const modal=$("apiModal"); if(!modal)return;
  $("apiModalTitle").textContent=title;
  $("apiModalText").textContent=text;
  $("apiModalHint").textContent=hint;
  modal.hidden=false;
}
function hideApiModal(){ const modal=$("apiModal"); if(modal) modal.hidden=true; }

async function inspectActiveTab(){
  const tab=await activeTab();
  const result={tab,site:false,content:false,api:false};
  if(!tab?.id)return result;
  result.site=/^https:\/\/cco-agent\.bantusaku\.id\//.test(tab.url||"");
  if(!result.site)return result;
  try{ const pong=await chrome.tabs.sendMessage(tab.id,{type:"PING"}); result.content=!!pong?.ok; }catch(_){ result.content=false; }
  try{
    const r=await new Promise(resolve=>chrome.runtime.sendMessage({type:"GET_AUTH_HEADERS",tabId:tab.id},resolve));
    result.api=!!(r?.ok && r.headers && Object.keys(r.headers).length);
  }catch(_){ result.api=false; }
  return result;
}

async function checkApiConnection(showPopup=false){
  if(apiModalBusy)return false;
  const state=await inspectActiveTab();
  const ready=state.site && state.content && state.api;
  const notice=$("siteNotice");
  if(ready){
    if(notice){ notice.classList.remove("session-warning"); notice.classList.add("session-ok"); notice.textContent="API/session terdeteksi. Siap scrape."; }
    return true;
  }
  if(notice){
    notice.classList.remove("session-ok"); notice.classList.add("session-warning");
    notice.textContent=state.site ? "API/session belum terdeteksi. Refresh halaman Chrome lalu coba lagi." : "Buka dan login ke cco-agent.bantusaku.id pada tab Chrome aktif.";
  }
  if(showPopup){
    if(!state.site) showApiModal("Tab belum siap","Buka cco-agent.bantusaku.id pada tab Chrome aktif sebelum menjalankan scraper.","Setelah halaman terbuka dan login, klik Coba Lagi.");
    else if(!state.content) showApiModal("Session belum siap","Extension belum terhubung ke halaman aktif. Refresh halaman agar extension terpasang kembali.","Klik REFRESH HALAMAN, tunggu halaman selesai dimuat, lalu coba lagi.");
    else if(!state.api) showApiModal("API belum terdeteksi","Extension belum menangkap session/API request dari halaman aktif. Refresh halaman untuk memuat ulang session.","Pastikan Anda sudah login dan tunggu halaman selesai dimuat sebelum scrape.");
  }
  return false;
}

async function refreshActivePage(){
  const tab=await activeTab(); if(!tab?.id)return;
  apiModalBusy=true;
  try{
    await chrome.tabs.reload(tab.id); hideApiModal();
    $("status").textContent="Halaman sedang di-refresh. Tunggu sebentar...";
    setTimeout(async()=>{ apiModalBusy=false; await checkApiConnection(false); },2000);
  }catch(_){
    apiModalBusy=false;
    showApiModal("Refresh gagal","Halaman tidak dapat di-refresh otomatis. Silakan refresh tab Chrome secara manual.","Setelah selesai, klik Coba Lagi.");
  }
}

function showActivationAlert(title,text,type="error"){
  const box=$("activationAlert");
  if(!box)return;
  $("activationAlertTitle").textContent=title;
  $("activationAlertText").textContent=text;
  box.className=`activation-alert ${type}`;
  box.hidden=false;
}
function hideActivationAlert(){
  const box=$("activationAlert");
  if(box)box.hidden=true;
}
function explainActivationError(raw){
  const s=String(raw||"").toLowerCase();
  if(!s)return["Aktivasi gagal","Server tidak memberikan pesan error. Coba lagi."];
  if(s.includes("not found")||s.includes("invalid")||s.includes("license not found")||s.includes("unknown license"))
    return["License tidak ditemukan","Periksa kembali License Key yang Anda masukkan."];
  if(s.includes("expired")||s.includes("expire"))
    return["License sudah expired","License ini sudah melewati masa aktif. Gunakan license yang masih aktif."];
  if(s.includes("revoked")||s.includes("disabled")||s.includes("suspended"))
    return["License dinonaktifkan","License ini sudah di-revoke atau dinonaktifkan oleh server."];
  if(s.includes("device")&&(s.includes("mismatch")||s.includes("bound")||s.includes("different")||s.includes("limit")))
    return["Device tidak cocok","License sudah terikat ke device lain atau batas device telah tercapai."];
  if(s.includes("network")||s.includes("fetch")||s.includes("failed to fetch")||s.includes("offline")||s.includes("timeout"))
    return["Server tidak dapat dihubungi","Periksa koneksi internet dan pastikan License Server sedang online."];
  if(s.includes("401")||s.includes("403")||s.includes("unauthorized")||s.includes("forbidden"))
    return["Akses ditolak","License Server menolak permintaan aktivasi. Periksa konfigurasi server."];
  if(s.includes("500")||s.includes("502")||s.includes("503"))
    return["Server sedang bermasalah","Coba lagi beberapa saat lagi. Jika berulang, periksa License Server."];
  return["Aktivasi gagal",String(raw).replace(/^error:\s*/i,"").slice(0,180)];
}


function showMenu(name){
  const licensed = name === "scrape";
  $("licenseView").hidden = licensed;
  $("scrapeView").hidden = !licensed;
  $("menuLicense").classList.toggle("active", !licensed);
  $("menuScrape").classList.toggle("active", licensed);
}

function lockScrapeMenu(){
  $("menuScrape").disabled = true;
  showMenu("license");
}

function unlockScrapeMenu(){
  $("menuScrape").disabled = false;
}

let hardwareId="";

// Extension-only device binding. No Windows agent/service is required.
// A random device ID is generated once and kept in chrome.storage.local.
// This is a browser-profile binding, not a true Windows hardware ID.
async function getHardwareId(){
  const key="device_binding_id";
  const saved=await chrome.storage.local.get([key]);
  if(saved[key]) return String(saved[key]).toUpperCase();
  const raw=crypto.randomUUID().replaceAll("-","").toUpperCase();
  const id="EXT-"+raw;
  await chrome.storage.local.set({[key]:id});
  return id;
}
async function getLicense(){
  const s=await chrome.storage.local.get(["license"]);
  return s.license||{};
}
async function serverStatus(key,hw){
  const r=await fetch(LICENSE_SERVER_URL+"/validate",{
    method:"POST",headers:{"content-type":"application/json"},
    body:JSON.stringify({license_key:key,hardware_id:hw})
  });
  let d={};try{d=await r.json()}catch(_){d={error:"Respons server tidak valid"}}
  if(!r.ok) throw new Error(d.error||`Server HTTP ${r.status}`);
  return d;
}
function parseExpiry(value){
  if(!value) return null;
  const s=String(value);
  const d=new Date(s);
  if(Number.isNaN(d.getTime())) return null;
  // Server returns ISO timestamps; date-only values are treated as end-of-day local time.
  if(/^\d{4}-\d{2}-\d{2}$/.test(s)){
    const [y,m,day]=s.split("-").map(Number);
    return new Date(y,m-1,day,23,59,59,999);
  }
  return d;
}
function formatExpiry(value){
  const d=parseExpiry(value);
  if(!d) return value||"-";
  return d.toLocaleString("id-ID",{dateStyle:"medium",timeStyle:"short"});
}
async function licenseInfo(){
  const lic=await getLicense();
  if(!lic.license_key) return {active:false,status:"BELUM AKTIF",expires:"-",expiresAt:null,days:null,key:"-",hw:hardwareId};
  try{
    const d=await serverStatus(lic.license_key,hardwareId);
    const end=parseExpiry(d.expires_at), now=new Date();
    const days=Math.max(0,Math.ceil((end-now)/86400000));
    return {active:true,status:"AKTIF",expires:formatExpiry(d.expires_at),expiresAt:end?.toISOString()||null,days,key:lic.license_key,hw:hardwareId};
  }catch(e){
    const msg=String(e.message||e);
    if(msg.toLowerCase().includes("expired")) return {active:false,status:"EXPIRED",expires:formatExpiry(lic.expires_at),expiresAt:parseExpiry(lic.expires_at)?.toISOString()||null,days:null,key:lic.license_key,hw:hardwareId};
    if(msg.includes("LICENSE_ALREADY_BOUND_TO_ANOTHER_PC") || msg.includes("HARDWARE_MISMATCH")) return {active:false,status:"DEVICE TIDAK COCOK",expires:formatExpiry(lic.expires_at),expiresAt:parseExpiry(lic.expires_at)?.toISOString()||null,days:null,key:lic.license_key,hw:hardwareId};
    if(msg.includes("REVOKED")||msg.toLowerCase().includes("revoke")) return {active:false,status:"REVOKED",expires:formatExpiry(lic.expires_at),expiresAt:parseExpiry(lic.expires_at)?.toISOString()||null,days:null,key:lic.license_key,hw:hardwareId};
    return {active:false,status:"SERVER TIDAK TERHUBUNG",expires:formatExpiry(lic.expires_at),expiresAt:parseExpiry(lic.expires_at)?.toISOString()||null,days:null,key:lic.license_key,hw:hardwareId};
  }
}
let headerLicenseExpiryAt=null;
function updateHeaderCountdown(){
  const el=$("headerLicenseDays"), header=$("licenseHeader");
  if(!el || !header) return;
  if(!headerLicenseExpiryAt){
    if(el.textContent==="") el.textContent="—";
    return;
  }
  const diff=new Date(headerLicenseExpiryAt).getTime()-Date.now();
  if(diff<=0){
    el.textContent="0 hari";
    header.classList.remove("expiring"); header.classList.add("expired");
    $("headerLicenseStatus").textContent="EXPIRED";
    $("headerLicenseExpiry").textContent="Masa aktif berakhir";
    return;
  }
  const totalMinutes=Math.floor(diff/60000);
  const days=Math.floor(totalMinutes/1440);
  const hours=Math.floor((totalMinutes%1440)/60);
  const mins=totalMinutes%60;
  el.textContent=days>0 ? `${days}h ${hours}j` : `${hours}j ${mins}m`;
  header.classList.toggle("expiring", days < 7);
}
setInterval(updateHeaderCountdown, 30000);

async function refreshLicense(){
  const i=await licenseInfo();
  $("licStatus").textContent=i.status;
  $("licExpiry").textContent=i.expires;
  $("licDays").textContent=i.days==null?"-":`${i.days} hari`;
  $("licenseBadge").textContent=i.status;
  $("licenseBadge").className="badge "+(i.active?"ok":"off");
  $("start").disabled=!i.active;

  // Header: always show the current license state and remaining active period.
  const header=$("licenseHeader");
  const headerStatus=$("headerLicenseStatus");
  const headerDays=$("headerLicenseDays");
  headerLicenseExpiryAt=i.expiresAt || null;
  const headerExpiry=$("headerLicenseExpiry");
  if(header){
    header.classList.remove("expiring","expired");
    headerStatus.textContent=i.status;
    if(i.active){
      const days=Number(i.days);
      headerDays.textContent=Number.isFinite(days) ? `${days} hari` : "—";
      headerExpiry.textContent=i.expires && i.expires!=="-" ? `s.d. ${i.expires}` : "—";
      if(Number.isFinite(days) && days <= 7) header.classList.add("expiring");
    }else{
      headerDays.textContent=i.status==="EXPIRED" ? "0 hari" : "—";
      headerExpiry.textContent=i.expires && i.expires!=="-" ? `s.d. ${i.expires}` : "—";
      if(i.status==="EXPIRED") header.classList.add("expired");
    }
  }
  updateHeaderCountdown();

  if(i.active){
    unlockScrapeMenu();
    showMenu("scrape");
  }else{
    lockScrapeMenu();
  }
  return i.active;
}
async function activate(){
  hideActivationAlert();
  const key=$("licenseKey").value.trim().toUpperCase();
  if(!key){
    showActivationAlert("License Key kosong","Masukkan License Key terlebih dahulu.");
    return;
  }
  if(key.length<8){
    showActivationAlert("License Key tidak valid","Format License Key terlalu pendek. Periksa kembali key Anda.");
    return;
  }

  const btn=$("activate");
  btn.disabled=true;
  btn.classList.add("loading");
  btn.innerHTML="<span>⏳</span> MEMVERIFIKASI...";
  $("licenseMsg").textContent="Menghubungi License Server...";

  try{
    const r=await fetch(LICENSE_SERVER_URL+"/activate",{
      method:"POST",
      headers:{"content-type":"application/json"},
      body:JSON.stringify({
        license_key:key,
        hardware_id:hardwareId,
        app_version:chrome.runtime.getManifest().version
      })
    });

    let d={};
    try{d=await r.json()}catch(_){d={error:"Respons server tidak valid"}}

    if(!r.ok){
      const serverError=d.error||d.message||`Aktivasi gagal (HTTP ${r.status}).`;
      const [title,text]=explainActivationError(serverError);
      $("licenseMsg").textContent="";
      showActivationAlert(title,text,"error");
      await refreshLicense();
      return;
    }

    await chrome.storage.local.set({
      license:{
        license_key:key,
        expires_at:d.expires_at,
        activated_at:new Date().toISOString()
      }
    });

    $("licenseMsg").textContent=`Lisensi aktif sampai ${formatExpiry(d.expires_at)}.`;
    showActivationAlert(
      "License berhasil diaktifkan",
      `Masa aktif sampai ${formatExpiry(d.expires_at)}. Menu SCRAPE sekarang terbuka.`,
      "success"
    );
    await refreshLicense();
  }catch(e){
    const [title,text]=explainActivationError(e?.message||e);
    $("licenseMsg").textContent="";
    showActivationAlert(title,text,"error");
    lockScrapeMenu();
  }finally{
    btn.disabled=false;
    btn.classList.remove("loading");
    btn.innerHTML="<span>🔐</span> AKTIFKAN LICENSE";
  }
}

async function clearLicense(){
  await chrome.storage.local.remove("license"); $("licenseKey").value="";
  $("licenseMsg").textContent="Data license lokal dihapus. Binding di server TIDAK dihapus; Owner harus Reset Binding jika ingin dipindahkan.";
  await refreshLicense();
}

async function activeTab(){
  const tabs=await chrome.tabs.query({active:true,currentWindow:true});
  return tabs[0];
}
async function pingTab(){
  const tab=await activeTab();
  if(!tab?.id) return false;
  if(!/^https:\/\/cco-agent\.bantusaku\.id\//.test(tab.url||"")) return false;
  try{
    await chrome.tabs.sendMessage(tab.id,{type:"PING"});
    return true;
  }catch(_){return false}
}
async function startScrape(){
  if(!(await refreshLicense())) return;
  const state=await inspectActiveTab();
  if(!state.site){
    showApiModal("Tab belum siap","Buka cco-agent.bantusaku.id pada tab Chrome aktif sebelum menjalankan scraper.","Setelah halaman terbuka dan login, klik Coba Lagi."); return;
  }
  if(!state.content || !state.api){ await checkApiConnection(true); return; }
  try{
    const tab=state.tab;
    await chrome.tabs.sendMessage(tab.id,{type:"START_SCRAPE",options:{
      tenantId:$("tenantId").value,pageSize:$("pageSize").value,maxPages:$("maxPages").value,
      retry:$("retry").value,caseFilter:$("caseFilter").value
    }});
    $("start").disabled=true;$("stop").disabled=false;$("bar").style.width="0%";
    $("status").textContent="Scrape dimulai...";
  }catch(e){
    $("status").textContent="Session/tab belum siap. Refresh halaman lalu coba lagi.";
    showApiModal("Session/API belum siap","Extension gagal terhubung ke API pada tab aktif. Refresh halaman lalu coba lagi.","Klik REFRESH HALAMAN dan tunggu sampai halaman selesai dimuat.");
  }
}

async function stopScrape(){
  const tab=await activeTab(); if(tab?.id) try{await chrome.tabs.sendMessage(tab.id,{type:"STOP_SCRAPE"})}catch(_){}
  $("stop").disabled=true;$("status").textContent="Meminta penghentian...";
}
chrome.runtime.onMessage.addListener(msg=>{
  if(msg.type==="SCRAPER_PROGRESS"){
    if(msg.phase==="CASE") $("status").textContent=`Case page ${msg.page}: ${msg.total} case terkumpul`;
    else {
      const pct=msg.total?Math.round(msg.index/msg.total*100):0;
      $("bar").style.width=pct+"%";
      $("status").textContent=`Case ${msg.index}/${msg.total} • ${msg.users||0} user • ${msg.contacts||0} contact`;
      $("caseCount").textContent=msg.index||0;$("userCount").textContent=msg.users||0;$("contactCount").textContent=msg.contacts||0;
    }
  }
  if(msg.type==="SCRAPER_DONE"){
    $("stop").disabled=true;$("start").disabled=false;$("bar").style.width="100%";
    $("caseCount").textContent=msg.cases;$("userCount").textContent=msg.users;$("contactCount").textContent=msg.contacts;
    $("status").textContent=`Selesai. File hasil masuk ke folder download "${msg.folder}".`;
  }
  if(msg.type==="SCRAPER_ERROR"){
    $("stop").disabled=true; refreshLicense(); $("status").textContent="ERROR: "+msg.message;
  }
});

$("menuLicense").onclick=()=>showMenu("license");
$("menuScrape").onclick=async()=>{
  if(await refreshLicense()) showMenu("scrape");
};

(async()=>{
  try{ hardwareId=await getHardwareId(); $("deviceId").textContent=hardwareId; }
  catch(e){ $("deviceId").textContent="DEVICE ID GAGAL DIBUAT"; $("licenseMsg").textContent=e.message; }
  showMenu("license");
  const saved=await getLicense(); $("licenseKey").value=saved.license_key||"";
  if(hardwareId) await refreshLicense();
  if(!$("scrapeView").hidden){
    await checkApiConnection(false);
  }
})();
$("activate").onclick=activate; $("clearLicense").onclick=clearLicense; $("start").onclick=startScrape; $("stop").onclick=stopScrape;
$("activationAlertClose")?.addEventListener("click",hideActivationAlert);
$("apiModalClose")?.addEventListener("click",hideApiModal);
$("apiModalRetry")?.addEventListener("click",async()=>{ hideApiModal(); await checkApiConnection(true); });
$("apiModalRefresh")?.addEventListener("click",refreshActivePage);
$("apiModal")?.addEventListener("click",e=>{ if(e.target.classList.contains("api-modal-backdrop")) hideApiModal(); });
chrome.tabs?.onUpdated?.addListener(async(tabId,changeInfo)=>{
  if(changeInfo.status==="complete"){
    const tab=await activeTab();
    if(tab?.id===tabId && !$("scrapeView").hidden) setTimeout(()=>checkApiConnection(false),500);
  }
});
