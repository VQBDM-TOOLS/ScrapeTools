# Scraper Tools V1 — Cloud License 1 PC

Chrome Extension untuk Scraper Tools V1 dengan license server cloud dan Windows Hardware ID.

## Quick start
1. Deploy `cloudflare` mengikuti `SETUP_CLOUD_LICENSE.md`.
2. Isi URL Worker pada `cloud-config.js`.
3. Install `agent/install_agent.bat` di PC user.
4. Load unpacked folder ini pada Chrome.
5. Owner membuat license di `/owner`.
6. User memasukkan license ke extension.

License binding disimpan di cloud, sehingga reinstall Chrome tidak melepaskan license.
