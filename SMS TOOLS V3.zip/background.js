const API_HOST = "cco-agent.bantusaku.id";
const AUTH_NAMES = new Set([
  "authorization","x-authorization","x-access-token","x-auth-token",
  "access-token","x-token","token"
]);

chrome.webRequest.onBeforeSendHeaders.addListener(
  async (details) => {
    if (!details.url.startsWith("https://" + API_HOST + "/api/")) return;
    const found = {};
    for (const h of (details.requestHeaders || [])) {
      const n = (h.name || "").toLowerCase();
      if (AUTH_NAMES.has(n) && h.value) found[h.name] = h.value;
    }
    if (Object.keys(found).length) {
      // Keep auth scoped to the tab that owns the login/session.
      // This prevents another CCO tab from overwriting the credentials
      // used by the tool while the user switches tabs.
      const key = `capturedAuth_${details.tabId}`;
      await chrome.storage.session.set({
        [key]: {
          auth: found,
          capturedAt: Date.now(),
          capturedUrl: details.url,
          tabId: details.tabId
        }
      });
    }
  },
  { urls: ["https://" + API_HOST + "/api/*"] },
  ["requestHeaders", "extraHeaders"]
);

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === "capturePageAuth") {
    const tabId = sender?.tab?.id;
    const auth = msg?.headers || {};
    if (Number.isInteger(tabId) && Object.keys(auth).length) {
      const key = `capturedAuth_${tabId}`;
      chrome.storage.session.set({
        [key]: {
          auth,
          capturedAt: Date.now(),
          capturedUrl: String(msg.url || ""),
          tabId
        }
      }).then(() => sendResponse({ok:true}));
      return true;
    }
    sendResponse({ok:false});
    return false;
  }
  if (msg?.type === "getCapturedAuth") {
    const tabId = Number(msg.tabId);
    const key = Number.isInteger(tabId) ? `capturedAuth_${tabId}` : "";
    if (!key) {
      sendResponse({auth:{},capturedAt:0,capturedUrl:"",tabId:0});
      return false;
    }
    chrome.storage.session.get(key).then(x => {
      const v = x[key] || {};
      sendResponse({
        auth: v.auth || {},
        capturedAt: v.capturedAt || 0,
        capturedUrl: v.capturedUrl || "",
        tabId: v.tabId || tabId
      });
    });
    return true;
  }
  if (msg?.type === "clearCapturedAuth") {
    const tabId = Number(msg.tabId);
    const key = Number.isInteger(tabId) ? `capturedAuth_${tabId}` : "";
    (key ? chrome.storage.session.remove(key) : Promise.resolve()).then(() => sendResponse({ok:true}));
    return true;
  }
});


chrome.tabs.onRemoved.addListener((tabId) => {
  chrome.storage.session.remove(`capturedAuth_${tabId}`).catch(() => {});
});

// ===== SIDE PANEL TOOLS =====
// Tools stay attached to the current Chrome tab instead of opening a new tab/window.
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === "closeToolsWindow") {
    const tabId = sender?.tab?.id;
    if (tabId != null && chrome.sidePanel?.close) {
      chrome.sidePanel.close({ tabId }).then(
        () => sendResponse({ok: true}),
        () => sendResponse({ok: false})
      );
      return true;
    }
    sendResponse({ok: false});
  }
});
