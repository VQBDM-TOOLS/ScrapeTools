const LICENSE_SERVER_URL = "https://bantusaku-license.div1.workers.dev";
