const CASE_ENDPOINT="https://cco-agent.bantusaku.id/api/v1/collection/im-cases/select-cases";
const CONTACT_ENDPOINT="https://cco-agent.bantusaku.id/api/v1/collection/contact/select-user-contact-listing";
const SMS_ENDPOINT="https://cco-agent.bantusaku.id/api/v1/collection/case-reach/channel-reach";
const REQUIRED=["Case ID","Contact Name","Amount","Mobile","Phone ID","Phone Type","Relation","Pesan","Status","Waktu Kirim","Keterangan"];
const APP_VERSION=chrome.runtime.getManifest().version;
const CHECKPOINT_KEY="sms_tools_v3_checkpoint";
const DEFAULT_CASE_CONCURRENCY=6;
const DEFAULT_CONTACT_CONCURRENCY=6;
const DEFAULT_PAGE_DELAY=0;
const LICENSE_CHECK_INTERVAL=10*60*1000;
const API_RETRYABLE=new Set([408,425,429,500,502,503,504]);
let scrapeAbort=false, smsAbort=false;

let stopScrape=false, stopSms=false, cases={}, contacts=[], smsRows=[], settings={};
let smsFileBuffer=null, smsChannelMode="CH";
const $=id=>document.getElementById(id);

// ===== PROFESSIONAL APP NOTIFICATION =====
function appAlert(message, title="SMS Tools V3", type="info") {
  const modal=$("appAlertModal");
  if(!modal){ console.warn(message); return Promise.resolve(); }
  $("appAlertTitle").textContent=title;
  $("appAlertText").textContent=String(message||"");
  const icon=$("appAlertIcon");
  icon.textContent=type==="success"?"✓":type==="error"?"!":"i";
  modal.className=`app-alert-modal ${type}`;
  modal.hidden=false; modal.setAttribute("aria-hidden","false");
  const ok=$("appAlertOk"), close=$("appAlertClose"), backdrop=modal.querySelector(".app-alert-backdrop");
  return new Promise(resolve=>{
    let done=false;
    const finish=()=>{if(done)return;done=true;modal.hidden=true;modal.setAttribute("aria-hidden","true");cleanup();resolve();};
    const cleanup=()=>{ok.removeEventListener("click",finish);close.removeEventListener("click",finish);backdrop?.removeEventListener("click",finish);document.removeEventListener("keydown",esc);};
    const esc=e=>{if(e.key==="Escape")finish()};
    ok.addEventListener("click",finish);close.addEventListener("click",finish);backdrop?.addEventListener("click",finish);document.addEventListener("keydown",esc);
    setTimeout(()=>ok.focus(),0);
  });
}

function closeToolsWindow(){
  chrome.runtime.sendMessage({type:"closeToolsWindow"}, () => {
    // Fallback for standalone extension windows.
    try { window.close(); } catch (_) {}
  });
}
document.addEventListener("DOMContentLoaded", () => {
  const btn = $("closeTools");
  if (btn) btn.addEventListener("click", closeToolsWindow);
});


// ===== LICENSE GATE (same activation/validation flow as reference tool) =====
let hardwareId="";
let hardwareIdReady=null;

// Device binding is generated locally and does NOT depend on the active CCO tab.
// It must also work in Chrome Side Panel contexts where tab APIs can be restricted.
function makeLocalDeviceId(){
  try{
    const existing=window.localStorage.getItem("sms_tools_device_binding_id");
    if(existing && /^SMS-[A-Z0-9-]{8,}$/i.test(existing)) return existing.toUpperCase();
  }catch(_){ }
  let raw="";
  try{
    if(globalThis.crypto?.randomUUID) raw=crypto.randomUUID().replaceAll("-","");
    else if(globalThis.crypto?.getRandomValues){
      raw=Array.from(crypto.getRandomValues(new Uint8Array(16)),b=>b.toString(16).padStart(2,"0")).join("");
    }
  }catch(_){ }
  if(!raw) raw=(Date.now().toString(36)+Math.random().toString(36).slice(2)+Math.random().toString(36).slice(2));
  const id="SMS-"+raw.toUpperCase();
  try{window.localStorage.setItem("sms_tools_device_binding_id",id)}catch(_){ }
  return id;
}

function paintHardwareId(id){
  const el=$("deviceId");
  if(el && id) el.textContent=id;
}

async function getHardwareId(){
  // 1) Chrome storage is the primary persistent store.
  try{
    const saved=await chrome.storage.local.get(["device_binding_id"]);
    if(saved?.device_binding_id){
      const id=String(saved.device_binding_id).toUpperCase();
      paintHardwareId(id);
      return id;
    }
  }catch(_){ }

  // 2) localStorage makes this resilient if the Chrome storage call is delayed/fails.
  const id=makeLocalDeviceId();
  try{await chrome.storage.local.set({device_binding_id:id})}catch(_){ }
  paintHardwareId(id);
  return id;
}

async function ensureHardwareId(){
  if(hardwareId){paintHardwareId(hardwareId);return hardwareId;}
  // Generate and paint a usable ID immediately, before any async storage operation.
  hardwareId=makeLocalDeviceId();
  paintHardwareId(hardwareId);
  if(!hardwareIdReady){
    hardwareIdReady=(async()=>{
      try{
        const saved=await chrome.storage.local.get(["device_binding_id"]);
        if(saved?.device_binding_id) hardwareId=String(saved.device_binding_id).toUpperCase();
        else await chrome.storage.local.set({device_binding_id:hardwareId});
      }catch(_){ }
      paintHardwareId(hardwareId);
      return hardwareId;
    })();
  }
  return await hardwareIdReady;
}
async function getLicense(){const s=await chrome.storage.local.get(["license"]);return s.license||{}}
async function serverStatus(key,hw){
  const ctl=new AbortController();const timer=setTimeout(()=>ctl.abort(),12000);
  try{
    const r=await fetch(LICENSE_SERVER_URL+"/validate",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({license_key:key,hardware_id:hw,app_version:APP_VERSION}),signal:ctl.signal});
    let d={};try{d=await r.json()}catch(_){d={error:"Respons server tidak valid"}}
    if(!r.ok)throw new Error(d.error||`Server HTTP ${r.status}`);return d;
  }finally{clearTimeout(timer)}
}
function parseExpiry(value){if(!value)return null;const s=String(value),d=new Date(s);if(Number.isNaN(d.getTime()))return null;if(/^\d{4}-\d{2}-\d{2}$/.test(s)){const[y,m,day]=s.split("-").map(Number);return new Date(y,m-1,day,23,59,59,999)}return d}
function formatExpiry(value){const d=parseExpiry(value);if(!d)return value||"-";return d.toLocaleString("id-ID",{dateStyle:"medium",timeStyle:"short"})}
function showActivationAlert(title,text,type="error"){const box=$("activationAlert");if(!box)return;$("activationAlertTitle").textContent=title;$("activationAlertText").textContent=text;box.className=`activation-alert ${type}`;box.hidden=false}
function hideActivationAlert(){const box=$("activationAlert");if(box)box.hidden=true}
function explainActivationError(raw){const s=String(raw||"").toLowerCase();if(!s)return["Aktivasi gagal","Server tidak memberikan pesan error. Coba lagi."];if(s.includes("not found")||s.includes("invalid")||s.includes("license not found")||s.includes("unknown license"))return["License tidak ditemukan","Periksa kembali License Key yang Anda masukkan."];if(s.includes("expired")||s.includes("expire"))return["License sudah expired","License ini sudah melewati masa aktif. Gunakan license yang masih aktif."];if(s.includes("revoked")||s.includes("disabled")||s.includes("suspended"))return["License dinonaktifkan","License ini sudah di-revoke atau dinonaktifkan oleh server."];if(s.includes("device")&&(s.includes("mismatch")||s.includes("bound")||s.includes("different")||s.includes("limit")))return["Device tidak cocok","License sudah terikat ke device lain atau batas device telah tercapai."];if(s.includes("network")||s.includes("fetch")||s.includes("failed to fetch")||s.includes("offline")||s.includes("timeout")||s.includes("abort"))return["Server tidak dapat dihubungi","Periksa koneksi internet dan pastikan License Server sedang online."];if(s.includes("401")||s.includes("403")||s.includes("unauthorized")||s.includes("forbidden"))return["Akses ditolak","License Server menolak permintaan aktivasi. Periksa konfigurasi server."];if(s.includes("500")||s.includes("502")||s.includes("503"))return["Server sedang bermasalah","Coba lagi beberapa saat lagi. Jika berulang, periksa License Server."];return["Aktivasi gagal",String(raw).replace(/^error:\s*/i,"").slice(0,180)]}
async function licenseInfo(force=false){
  const lic=await getLicense();if(!lic.license_key)return{active:false,status:"BELUM AKTIF",expires:"-",days:null};
  const localEnd=parseExpiry(lic.expires_at),now=new Date();
  if(localEnd&&localEnd<=now)return{active:false,status:"EXPIRED",expires:formatExpiry(lic.expires_at),days:0};
  if(!force && lic.validated_at && Date.now()-Number(lic.validated_at)<LICENSE_CHECK_INTERVAL){
    const days=localEnd?Math.max(0,Math.ceil((localEnd-now)/86400000)):null;
    return{active:true,status:"AKTIF",expires:formatExpiry(lic.expires_at),days,key:lic.license_key};
  }
  try{
    const d=await serverStatus(lic.license_key,hardwareId),end=parseExpiry(d.expires_at),days=end?Math.max(0,Math.ceil((end-now)/86400000)):null;
    await chrome.storage.local.set({license:{...lic,expires_at:d.expires_at||lic.expires_at,validated_at:Date.now()}});
    return{active:true,status:"AKTIF",expires:formatExpiry(d.expires_at),days,key:lic.license_key};
  }catch(e){
    const msg=String(e.message||e),low=msg.toLowerCase();
    if(low.includes("expired"))return{active:false,status:"EXPIRED",expires:formatExpiry(lic.expires_at),days:null};
    if(msg.includes("LICENSE_ALREADY_BOUND_TO_ANOTHER_PC")||msg.includes("HARDWARE_MISMATCH"))return{active:false,status:"DEVICE TIDAK COCOK",expires:formatExpiry(lic.expires_at),days:null};
    if(msg.includes("REVOKED")||low.includes("revoke"))return{active:false,status:"REVOKED",expires:formatExpiry(lic.expires_at),days:null};
    return{active:!!localEnd,status:"SERVER TIDAK TERHUBUNG",expires:formatExpiry(lic.expires_at),days:localEnd?Math.max(0,Math.ceil((localEnd-now)/86400000)):null};
  }
}
async function refreshLicense(force=false){const i=await licenseInfo(force);const h=$("headerLicense");if(h)h.textContent=i.active?(i.days===0?"• Sisa masa aktif: < 1 hari":`• Sisa masa aktif: ${i.days} hari`):`• ${i.status}`;$("licStatus").textContent=i.status;$("licExpiry").textContent=i.expires;$("licDays").textContent=i.days==null?"-":`${i.days} hari`;$("licenseBadge").textContent=i.status;$("licenseBadge").className="license-badge "+(i.active?"ok":"off");$("licenseView").hidden=!!i.active;$("toolsMain").hidden=!i.active;return i.active}
async function activateLicense(){hideActivationAlert();const key=$("licenseKey").value.trim().toUpperCase();if(!key){showActivationAlert("License Key kosong","Masukkan License Key terlebih dahulu.");return}if(key.length<8){showActivationAlert("License Key tidak valid","Format License Key terlalu pendek. Periksa kembali key Anda.");return}const btn=$("activateLicense");btn.disabled=true;try{await ensureHardwareId()}catch(e){btn.disabled=false;showActivationAlert("Device ID gagal dibuat","Muat ulang tools lalu coba aktivasi kembali.");return}btn.textContent="⏳ MEMVERIFIKASI...";$("licenseMsg").textContent="Menghubungi License Server...";try{const ctl=new AbortController(),timer=setTimeout(()=>ctl.abort(),12000);let r;try{r=await fetch(LICENSE_SERVER_URL+"/activate",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({license_key:key,hardware_id:hardwareId,app_version:APP_VERSION}),signal:ctl.signal})}finally{clearTimeout(timer)}let d={};try{d=await r.json()}catch(_){d={error:"Respons server tidak valid"}}if(!r.ok){const[title,text]=explainActivationError(d.error||d.message||`Aktivasi gagal (HTTP ${r.status}).`);$("licenseMsg").textContent="";showActivationAlert(title,text);await refreshLicense(true);return}await chrome.storage.local.set({license:{license_key:key,expires_at:d.expires_at,activated_at:new Date().toISOString(),validated_at:Date.now()}});$("licenseMsg").textContent=`Lisensi aktif sampai ${formatExpiry(d.expires_at)}.`;showActivationAlert("License berhasil diaktifkan",`Masa aktif sampai ${formatExpiry(d.expires_at)}. Tools sekarang terbuka.`,"success");await refreshLicense(true);setTimeout(()=>checkLogin(true),200)}catch(e){const[title,text]=explainActivationError(e?.message||e);$("licenseMsg").textContent="";showActivationAlert(title,text)}finally{btn.disabled=false;btn.textContent="🔐 AKTIFKAN LICENSE"}}
async function clearLicense(){await chrome.storage.local.remove("license");$("licenseKey").value="";$("licenseMsg").textContent="Data license lokal dihapus. Binding di server TIDAK dihapus.";await refreshLicense(true)}
async function initLicenseGate(){await ensureHardwareId();const btn=$("activateLicense");if(btn)btn.disabled=false;return await refreshLicense(true)}

function log(s){const line=`[${new Date().toLocaleTimeString()}] ${s}`;$("logBox").value+=line+"\n";$("logBox").scrollTop=$("logBox").scrollHeight;console.log(line)}
function clean(v){return v==null?"":String(v).trim().replace(/^(['"])(.*)\1$/,"$2").trim()}
function cfg(){return {
  pageSize:Math.max(1,+$("pageSize").value||100),
  maxPages:Math.max(0,+$("maxPages").value||0),
  // V3: parallelism is intentionally fixed at 6 to keep the client simple.
  caseConcurrency:DEFAULT_CASE_CONCURRENCY,
  contactConcurrency:DEFAULT_CONTACT_CONCURRENCY,
  pageDelay:DEFAULT_PAGE_DELAY,
  tenant:"154",
  country:"ID",
  language:"id"
}}
async function save(){
  settings=cfg();
  await chrome.storage.local.set({settings});
}
async function load(){
  const x=await chrome.storage.local.get("settings");
  const saved=x.settings||{};
  settings={
    pageSize:Math.max(1,+saved.pageSize||100),
    maxPages:Math.max(0,+saved.maxPages||0),
    caseConcurrency:DEFAULT_CASE_CONCURRENCY,
    contactConcurrency:DEFAULT_CONTACT_CONCURRENCY,
    pageDelay:DEFAULT_PAGE_DELAY,
    tenant:"154",
    country:"ID",
    language:"id"
  };
  $("pageSize").value=settings.pageSize;
  $("maxPages").value=settings.maxPages;
}

function headers(){return {"Accept":"application/json, text/plain, */*","Content-Type":"application/json","Country":settings.country||"ID","Language":settings.language||"id","Tenantid":settings.tenant||"154","Timezone":"7","Origin":"https://cco-agent.bantusaku.id","Referer":"https://cco-agent.bantusaku.id/"}}

const TARGET_TAB_KEY = "sms_tools_target_tab_id";

function isCcoTab(tab){
  return !!tab?.id && /^https:\/\/cco-agent\.bantusaku\.id\//i.test(String(tab.url||""));
}

async function getTargetTab({bindIfMissing=true}={}){
  // The tool is bound to the CCO tab that was active when this side panel
  // instance was opened. Switching to another Chrome tab must NOT move the
  // API/session context to that new tab.
  const saved = await chrome.storage.session.get([TARGET_TAB_KEY]);
  const savedId = Number(saved[TARGET_TAB_KEY] || 0);

  if(savedId){
    try{
      const tab = await chrome.tabs.get(savedId);
      if(isCcoTab(tab)) return tab;
    }catch(_){}
  }

  const activeTabs = await chrome.tabs.query({active:true,currentWindow:true});
  const active = activeTabs[0];
  if(isCcoTab(active)){
    if(bindIfMissing) await chrome.storage.session.set({[TARGET_TAB_KEY]:active.id});
    return active;
  }

  throw new Error("Tab SOSI/CCO yang sudah login tidak ditemukan. Buka tab cco-agent.bantusaku.id yang sudah login, lalu buka extension.");
}

async function getActiveCcoTab(){
  return getTargetTab();
}

async function getCapturedAuth(tabId){
  try{
    return await chrome.runtime.sendMessage({type:"getCapturedAuth",tabId:Number(tabId)});
  }catch{
    return {auth:{},capturedAt:0,capturedUrl:"",tabId:Number(tabId)||0};
  }
}

async function pageApiPost(url,payload,opts={}){
  const tab=await getTargetTab();
  const cap=await getCapturedAuth(tab.id);const auth=cap?.auth||{};
  const timeoutMs=Number(opts.timeoutMs||30000),requestId="bsk_"+crypto.randomUUID();
  const result=await chrome.scripting.executeScript({target:{tabId:tab.id},world:"MAIN",func:async ({url,payload,settings,auth,timeoutMs,requestId})=>{
    window.__BSK_ABORTS=window.__BSK_ABORTS||new Map();
    const controller=new AbortController();window.__BSK_ABORTS.set(requestId,controller);
    const base={"Accept":"application/json, text/plain, */*","Content-Type":"application/json","Country":settings.country||"ID","Language":settings.language||"id","Tenantid":settings.tenant||"154","Timezone":"7"};
    const parse=async r=>{let d={};try{d=await r.clone().json()}catch{try{d={_raw:await r.text()}}catch{}}return{ok:r.ok,status:r.status,data:d}};
    const attempt=async headers=>{
      try{
        const timer=setTimeout(()=>controller.abort(),timeoutMs);
        try{
          const r=await fetch(url,{method:"POST",headers:{...base,...headers},credentials:"include",body:JSON.stringify(payload),signal:controller.signal});
          return await parse(r);
        }finally{clearTimeout(timer)}
      }catch(e){
        return {ok:false,status:0,data:{_error:e?.name==="AbortError"?"Request dibatalkan/timeout":String(e?.message||e)}};
      }
    };
    try{const first=await attempt({});if(first.ok)return first;if(Object.keys(auth).length&&!controller.signal.aborted){const second=await attempt(auth);if(second.ok||second.status!==first.status)return second}return first}finally{window.__BSK_ABORTS.delete(requestId)}} ,args:[{url,payload,settings,auth,timeoutMs,requestId}]});
  const x=result?.[0]?.result;if(!x)throw new Error("Tidak mendapat respons dari halaman SOSI.");return{r:{ok:!!x.ok,status:x.status||0},d:x.data||{},requestId};
}
async function abortPageRequests(tabId){try{await chrome.scripting.executeScript({target:{tabId},world:"MAIN",func:()=>{if(window.__BSK_ABORTS)for(const c of window.__BSK_ABORTS.values())try{c.abort()}catch{}}})}catch{}}
async function apiWithRetry(url,payload,opts={}){
  const attempts=Math.max(1,Number(opts.attempts||3));let last=null;
  for(let n=1;n<=attempts;n++){
    if(opts.shouldStop?.())throw new Error("Dihentikan oleh pengguna.");
    last=await pageApiPost(url,payload,opts);
    if(last.r.ok)return last;
    if(!API_RETRYABLE.has(last.r.status)&&last.r.status!==0)return last;
    if(n<attempts){const delay=Math.min(4000,500*2**(n-1));log(`${opts.label||"API"} retry ${n+1}/${attempts} dalam ${delay}ms • HTTP ${last.r.status||"NETWORK"}`);await new Promise(r=>setTimeout(r,delay))}
  }return last;
}


async function appConfirm(message, title="Konfirmasi", okText="Lanjutkan") {
  const modal=$("appAlertModal");
  if(!modal) return window.confirm(message);
  $("appAlertTitle").textContent=title; $("appAlertText").textContent=String(message||"");
  $("appAlertIcon").textContent="?"; $("appAlertOk").textContent=okText;
  const cancel=$("appAlertCancel"); if(cancel) cancel.hidden=false;
  modal.className="app-alert-modal info"; modal.hidden=false; modal.setAttribute("aria-hidden","false");
  const ok=$("appAlertOk"), close=$("appAlertClose"), backdrop=modal.querySelector(".app-alert-backdrop");
  return await new Promise(resolve=>{
    let done=false; const finish=v=>{if(done)return;done=true;modal.hidden=true;modal.setAttribute("aria-hidden","true");ok.textContent="MENGERTI";if(cancel)cancel.hidden=true;cleanup();resolve(v)};
    const cleanup=()=>{ok.removeEventListener("click",yes);close.removeEventListener("click",no);backdrop?.removeEventListener("click",no);cancel?.removeEventListener("click",no);document.removeEventListener("keydown",esc)};
    const yes=()=>finish(true),no=()=>finish(false),esc=e=>{if(e.key==="Escape")no()};
    ok.addEventListener("click",yes);close.addEventListener("click",no);backdrop?.addEventListener("click",no);cancel?.addEventListener("click",no);document.addEventListener("keydown",esc);setTimeout(()=>ok.focus(),0);
  });
}

async function promptRefreshForLogin(){
  const shouldRefresh=await appConfirm("SOSI / SSO LOGIN AKTIF belum aktif.\n\nSilakan refresh halaman SOSI agar sesi login dapat terdeteksi.\n\nLanjutkan dengan refresh halaman sekarang?","Sesi SOSI / SSO belum aktif","REFRESH HALAMAN");
  if(!shouldRefresh)return false;
  try{
    const tab=await getActiveCcoTab();
    await chrome.tabs.reload(tab.id);
    log("HALAMAN SOSI DIRELOAD • Menunggu sesi login terdeteksi kembali.");
    return true;
  }catch(e){
    appAlert("Gagal refresh halaman SOSI: "+(e.message||e));
    return false;
  }
}

async function checkLogin(silent=false){
  $("loginBadge").className="badge pending";
  $("loginBadge").textContent="● MENGECEK SOSI / SSO...";

  try{
    const tab=await getActiveCcoTab();
    const cap=await getCapturedAuth();

    // Inspect same-origin storage as a diagnostic only; never expose its values.
    let storageInfo={localKeys:[],sessionKeys:[]};
    try{
      const rr=await chrome.scripting.executeScript({
        target:{tabId:tab.id},
        world:"MAIN",
        func:()=>{
          const keys=(s)=>{const a=[];for(let i=0;i<s.length;i++)a.push(s.key(i)||"");return a;};
          return {localKeys:keys(localStorage),sessionKeys:keys(sessionStorage)};
        }
      });
      storageInfo=rr?.[0]?.result||storageInfo;
    }catch{}

    const {r,d}=await pageApiPost(
      CASE_ENDPOINT,
      {page:1,pageSize:1,scene:"collector_case_detail",tenantId:+(settings.tenant||154)}
    );

    if(r.ok){
      $("loginBadge").className="badge ok";
      $("loginBadge").textContent="● SOSI / SSO LOGIN AKTIF";
      $("loginText").textContent="Request API berhasil menggunakan sesi login browser.";
      if(!silent)log("LOGIN AKTIF • API berhasil.");
      return true;
    }

    $("loginBadge").className="badge bad";
    $("loginBadge").textContent="● LOGIN TIDAK TERDETEKSI";

    const authSeen=Object.keys(cap?.auth||{}).length>0;
    const storageKeys=[...(storageInfo.localKeys||[]),...(storageInfo.sessionKeys||[])];
    const tokenLike=storageKeys.filter(k=>/token|auth|access|session|jwt|sso|login/i.test(k));

    let reason=`API HTTP ${r.status}.`;
    if(authSeen) reason+=" Header auth halaman sudah tertangkap, tetapi API masih menolak request.";
    else if(tokenLike.length) reason+=` Ada ${tokenLike.length} key storage yang terlihat terkait sesi, tetapi header auth belum tertangkap.`;
    else reason+=" Belum terlihat header auth dari request halaman.";

    $("loginText").textContent=reason;
    log(`LOGIN CHECK GAGAL • HTTP ${r.status} • authHeader=${authSeen?"YA":"TIDAK"} • storageKeysTerkait=${tokenLike.length}`);
    if(d?._error) log("Detail: "+d._error);
    if(!silent) await promptRefreshForLogin();
    return false;
  }catch(e){
    $("loginBadge").className="badge bad";
    $("loginBadge").textContent="● LOGIN TIDAK TERDETEKSI";
    $("loginText").textContent=e.message||"Gagal mengakses tab SOSI.";
    if(!silent)log("LOGIN ERROR • "+e.message);
    if(!silent) await promptRefreshForLogin();
    return false;
  }
}

function addScrape(step,detail,status,count=""){const tr=document.createElement("tr");[step,detail,status,count].forEach(v=>{const td=document.createElement("td");td.textContent=v;tr.appendChild(td)});$("scrapeTable").appendChild(tr)}

function csvEscape(v){const s=String(v??"");return /[",\n\r]/.test(s)?`"${s.replaceAll('"','""')}"`:s}
function toCsv(rows,headers){return "\ufeff"+headers.map(csvEscape).join(",")+"\n"+rows.map(r=>headers.map(h=>csvEscape(r[h])).join(",")).join("\n")}
function todayFileDate(){const d=new Date();const y=d.getFullYear();const m=String(d.getMonth()+1).padStart(2,"0");const day=String(d.getDate()).padStart(2,"0");return `${y}-${m}-${day}`}
function download(name,text,type="text/csv;charset=utf-8"){const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([text],{type}));a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
function xmlEsc(v){
  return String(v??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;");
}
function crc32(bytes){
  let table=crc32.table;
  if(!table){table=new Uint32Array(256);for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=(c&1)?(0xEDB88320^(c>>>1)):(c>>>1);table[n]=c>>>0;}crc32.table=table;}
  let c=0xFFFFFFFF;for(const b of bytes)c=table[(c^b)&255]^(c>>>8);return (c^0xFFFFFFFF)>>>0;
}
function u16(n){return new Uint8Array([n&255,(n>>>8)&255]);}
function u32(n){return new Uint8Array([n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255]);}
function cat(parts){let len=0;for(const p of parts)len+=p.length;const out=new Uint8Array(len);let o=0;for(const p of parts){out.set(p,o);o+=p.length;}return out;}
function zipStore(files){
  const enc=new TextEncoder(), locals=[], centrals=[];let offset=0;
  for(const [name,text] of files){
    const nb=enc.encode(name), db=enc.encode(text), crc=crc32(db);
    const lh=cat([new Uint8Array([80,75,3,4]),u16(20),u16(0),u16(0),u16(0),u16(0),u32(crc),u32(db.length),u32(db.length),u16(nb.length),u16(0),nb,db]);
    locals.push(lh);
    const ch=cat([new Uint8Array([80,75,1,2]),u16(20),u16(20),u16(0),u16(0),u16(0),u16(0),u32(crc),u32(db.length),u32(db.length),u16(nb.length),u16(0),u16(0),u16(0),u16(0),u32(0),u32(offset),nb]);
    centrals.push(ch);offset+=lh.length;
  }
  const cd=cat(centrals), body=cat(locals);
  const end=cat([new Uint8Array([80,75,5,6]),u16(0),u16(0),u16(files.length),u16(files.length),u32(cd.length),u32(body.length),u16(0)]);
  return cat([body,cd,end]);
}
function xmlEsc(v){
  return String(v??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;");
}
function crc32(bytes){
  let table=crc32.table;
  if(!table){table=new Uint32Array(256);for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=(c&1)?(0xEDB88320^(c>>>1)):(c>>>1);table[n]=c>>>0;}crc32.table=table;}
  let c=0xFFFFFFFF;for(const b of bytes)c=table[(c^b)&255]^(c>>>8);return (c^0xFFFFFFFF)>>>0;
}
function u16(n){return new Uint8Array([n&255,(n>>>8)&255]);}
function u32(n){return new Uint8Array([n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255]);}
function cat(parts){let len=0;for(const p of parts)len+=p.length;const out=new Uint8Array(len);let o=0;for(const p of parts){out.set(p,o);o+=p.length;}return out;}
function zipStore(files){
  const enc=new TextEncoder(), locals=[], centrals=[];let offset=0;
  for(const [name,text] of files){
    const nb=enc.encode(name), db=enc.encode(text), crc=crc32(db);
    const lh=cat([new Uint8Array([80,75,3,4]),u16(20),u16(0),u16(0),u16(0),u16(0),u32(crc),u32(db.length),u32(db.length),u16(nb.length),u16(0),nb,db]);
    locals.push(lh);
    const ch=cat([new Uint8Array([80,75,1,2]),u16(20),u16(20),u16(0),u16(0),u16(0),u16(0),u32(crc),u32(db.length),u32(db.length),u16(nb.length),u16(0),u16(0),u16(0),u16(0),u32(0),u32(offset),nb]);
    centrals.push(ch);offset+=lh.length;
  }
  const cd=cat(centrals), body=cat(locals);
  const end=cat([new Uint8Array([80,75,5,6]),u16(0),u16(0),u16(files.length),u16(files.length),u32(cd.length),u32(body.length),u16(0)]);
  return cat([body,cd,end]);
}
function colName(n){
  let s="";n++;
  while(n){let r=(n-1)%26;s=String.fromCharCode(65+r)+s;n=Math.floor((n-1)/26)}
  return s;
}
function sheetXml(rows, opts={}){
  const widths=opts.widths||[];
  const maxCols=Math.max(1,...rows.map(r=>r.length));
  const maxRows=Math.max(1,rows.length);
  const merges=opts.merges||[];
  const pane=opts.freeze?`<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/><selection pane="bottomLeft" activeCell="A2" sqref="A2"/></sheetView></sheetViews>`:"<sheetViews><sheetView workbookViewId=\"0\" showGridLines=\"0\"/></sheetViews>";
  const cols=widths.length?`<cols>${widths.map((w,i)=>`<col min="${i+1}" max="${i+1}" width="${w}" customWidth="1"/>`).join("")}</cols>`:"";
  const data=rows.map((row,ri)=>{
    const cells=row.map((v,ci)=>{
      if(v&&typeof v==="object"&&v.formula){
        const cached = v.value!=null ? `<v>${xmlEsc(v.value)}</v>` : "";
        return `<c r="${colName(ci)}${ri+1}" t="str" s="${v.style||0}"><f>${xmlEsc(v.formula)}</f>${cached}</c>`;
      }
      if(v&&typeof v==="object"&&v.number!=null){
        const n=Number(v.number);
        return Number.isFinite(n)
          ? `<c r="${colName(ci)}${ri+1}" t="n" s="${v.style||0}"><v>${n}</v></c>`
          : `<c r="${colName(ci)}${ri+1}" t="inlineStr" s="${v.style||0}"><is><t xml:space="preserve"></t></is></c>`;
      }
      const val=String(v??"");
      const style=(ri===0&&opts.headerStyle)?opts.headerStyle:(v&&typeof v==="object"?v.style||0:0);
      const text=v&&typeof v==="object"?String(v.value??""):val;
      return `<c r="${colName(ci)}${ri+1}" t="inlineStr" s="${style}"><is><t xml:space="preserve">${xmlEsc(text)}</t></is></c>`;
    }).join("");
    return `<row r="${ri+1}">${cells}</row>`;
  }).join("");
  const filter=opts.filterCols?`<autoFilter ref="A1:${colName(opts.filterCols-1)}${maxRows}"/>`:"";
  const mergeXml=merges.length?`<mergeCells count="${merges.length}">${merges.map(x=>`<mergeCell ref="${x}"/>`).join("")}</mergeCells>`:"";
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">${pane}${cols}<sheetData>${data}</sheetData>${mergeXml}${filter}</worksheet>`;
}
function normalizeAmount(v){
  if(v==null||v==="") return "";
  if(typeof v==="number" && Number.isFinite(v)) return Math.round(v);
  let s=String(v).trim();
  if(!s) return "";
  // Accept common ID formats: 1.500.000 / 1,500,000 / Rp 1.500.000
  s=s.replace(/Rp\.?/gi,"").replace(/\s/g,"");
  if(/^\d{1,3}(\.\d{3})+(,\d+)?$/.test(s)) s=s.replace(/\./g,"").replace(",",".");
  else if(/^\d{1,3}(,\d{3})+(\.\d+)?$/.test(s)) s=s.replace(/,/g,"");
  else s=s.replace(/[^0-9.-]/g,"");
  const n=Number(s);
  return Number.isFinite(n)?Math.round(n):"";
}
function getCaseAmount(o){
  if(!o || typeof o!=="object") return "";
  const priority=[
    "amount","Amount","totalAmount","total_amount","outstandingAmount","outstanding_amount",
    "dueAmount","due_amount","billAmount","bill_amount","billingAmount","billing_amount",
    "paymentAmount","payment_amount","tagihan","nominal","principalAmount","principal_amount",
    "caseAmount","case_amount","case_amount_due","amountDue","amount_due","totalDue","total_due",
    "payableAmount","payable_amount","installmentAmount","installment_amount","due","outstanding",
    "remainingAmount","remaining_amount","totalPayment","total_payment","loanAmount","loan_amount"
  ];
  for(const k of priority){
    if(o[k]!=null && o[k]!=="") return normalizeAmount(o[k]);
  }
  // Also support nested API response objects.
  for(const k of ["data","case","detail","billing","bill","payment","loan"]){
    if(o[k] && typeof o[k]==="object"){
      const v=getCaseAmount(o[k]);
      if(v!=="") return v;
    }
  }
  return "";
}
function makeInitialWorkbookBytes(contactsInput, casesInput){
  const rows=Array.isArray(contactsInput)?contactsInput:[];
  const casesObj=casesInput||{};
  const myself=[], ec=[];
  for(const r of rows){
    const p=String(r["Phone Type"]??r.phoneType??"").trim().toUpperCase();
    const x={
      case:r["Case ID"]??r.case??"",
      name:r["Contact Name"]??r.name??"",
      amount:normalizeAmount(r.Amount??r.amount??""),
      mobile:r.Mobile??r.mobile??"",
      phoneId:r["Phone ID"]??r.phoneId??"",
      phoneType:p,
      relation:String(r.Relation??r.relation??"").trim().toUpperCase(),
      message:String(r["Pesan"]??r.message??""),
      status:String(r.Status??r.status??"SIAP"),
      sentTime:String(r["Waktu Kirim"]??r.time??""),
      note:String(r.Keterangan??r.note??"")
    };
    if(p==="MYSELF") myself.push(x); else ec.push(x);
  }
  const defaultMsg="BANTUSAKU Segera di bayar!";
  const ch=[["Case ID","Contact Name","Amount","Mobile","Phone ID","Phone Type","Relation","Pesan","Status","Waktu Kirim","Keterangan"]];
  const seen=new Set();
  if(myself.length){
    for(const x of myself){
      const key=`${x.case}|${x.mobile}|${x.phoneId}`;
      if(seen.has(key)) continue; seen.add(key);
      const amount=normalizeAmount(x.amount!==""?x.amount:getCaseAmount(casesObj[x.case]));
      ch.push([x.case,x.name,amount===""?"":{number:amount,style:5},x.mobile,x.phoneId,"MYSELF",x.relation||"R01",x.message||defaultMsg,x.status||"SIAP",x.sentTime||"",x.note||""]);
    }
  }else{
    for(const [cid,o] of Object.entries(casesObj)){
      const amount=getCaseAmount(o);
      ch.push([cid,clean(o?.user_name),amount===""?"":{number:amount,style:5},clean(o?.mobile),"","MYSELF","R01",defaultMsg,"SIAP","",""]);
    }
  }

  const ecSheet=[["Case ID","Contact Name","Amount","Mobile","Phone ID","Phone Type","Relation","Pesan","Status","Waktu Kirim","Keterangan"]];
  for(const x of ec){
    const rr=ecSheet.length+1;
    const formula=`IFERROR(SUBSTITUTE('SET UP TEMPLATE'!$E$2,"[NAMA CH]",INDEX('SMS CH'!$B:$B,MATCH(A${rr},'SMS CH'!$A:$A,0))),SUBSTITUTE('SET UP TEMPLATE'!$E$2,"[NAMA CH]",""))`;
    let cachedMessage=x.message||"";
    if(!cachedMessage){
      const match=ch.slice(1).find(row=>String(row[0])===String(x.case));
      const chName=match?String(match[1]??""):"";
      cachedMessage=`Sampaikan ke ${chName} suruh Bayar BANTUSAKU Segera!`;
    }
    const amount=normalizeAmount(x.amount!==""?x.amount:getCaseAmount(casesObj[x.case]));
    ecSheet.push([x.case,x.name,amount===""?"":{number:amount,style:5},x.mobile,x.phoneId,x.phoneType,x.relation,x.message?x.message:{formula,value:cachedMessage},x.status||"SIAP",x.sentTime||"",x.note||""]);
  }

  const setup=[
    ["","","","","TEMPLATE PESAN SMS EC","SUMBER NAMA CH","RUMUS "],
    ["","","","", "Sampaikan ke [NAMA CH] suruh Bayar BANTUSAKU Segera!",
      "Nama CH diambil dari SMS CH → Contact Name (kolom B), berdasarkan Case ID (kolom A).",
      {formula:"IFERROR(SUBSTITUTE('SET UP TEMPLATE'!$E$2,\"[NAMA CH]\",INDEX('SMS CH'!$B:$B,MATCH(A2,'SMS CH'!$A:$A,0))),SUBSTITUTE('SET UP TEMPLATE'!$E$2,\"[NAMA CH]\",\"\"))",value:"Sampaikan ke  suruh Bayar BANTUSAKU Segera!"}]
  ];
  const info=[
    ["TEMPLATE PENGIRIMAN SMS",""],
    ["",'phoneType: "USER_CONTACT"'],
    ["Cara penggunaan:",'phoneType: "MYSELF"'],
    ["1. Isi Case ID sesuai kasus yang memang menjadi kewenangan akun Anda.",""],
    ["2. Isi Nama dan Nomor HP yang terdaftar/berwenang digunakan.",""],
    ["3. Isi Pesan SMS.",""],
    ["4. Set Status menjadi SIAP setelah data diperiksa.",""],
    ["5. Pengiriman SMS Akan sesuai dengan Sheet pertama, contoh: default saat ini sheet sms ch dan otomatis akan sms ch di sistem, jika ingin sms ec pindahkan sheet sms ec ke urutan pertama.",""],
    ["6. Kolom Status/Waktu/Keterangan nantinya dapat diisi oleh aplikasi pengiriman.",""],
    ["",""],
    ["SMS EC - NAMA CH OTOMATIS",""],
    ["Kolom Pesan SMS EC mengambil Contact Name dari sheet SMS CH berdasarkan Case ID. Jadi nama yang disisipkan adalah nama CH yang ada di kolom Contact Name pada SMS CH.",""],
    ["Rumus ada di Set Up template untuk di Copy ke template sms ec",""]
  ];

  const files=[];
  files.push(["[Content_Types].xml",'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet3.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet4.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>']);
  files.push(["_rels/.rels",'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>']);
  files.push(["xl/workbook.xml",'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="SMS CH" sheetId="1" r:id="rId1"/><sheet name="SMS EC" sheetId="2" r:id="rId2"/><sheet name="SET UP TEMPLATE" sheetId="3" r:id="rId3"/><sheet name="Petunjuk" sheetId="4" r:id="rId4"/></sheets><calcPr calcMode="auto" fullCalcOnLoad="1"/></workbook>']);
  files.push(["xl/_rels/workbook.xml.rels",'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet3.xml"/><Relationship Id="rId4" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet4.xml"/><Relationship Id="rId5" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>']);
  files.push(["xl/styles.xml",'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="3"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font></fonts><fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="1F4E78"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="EAF2F8"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="2"><border/><border><left style="thin"/><right style="thin"/><top style="thin"/><bottom style="thin"/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="6"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf><xf numFmtId="0" fontId="0" fillId="0" borderId="1" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf><xf numFmtId="0" fontId="0" fillId="3" borderId="1" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf><xf numFmtId="0" fontId="1" fillId="0" borderId="1" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf><xf numFmtId="4" fontId="0" fillId="0" borderId="1" applyAlignment="1"><alignment horizontal="right" vertical="top"/></xf></cellXfs></styleSheet>']);
  files.push(["xl/worksheets/sheet1.xml",sheetXml(ch,{widths:[16,30,18,20,16,16,14,75,14,22,42],headerStyle:1,filterCols:11,freeze:true})]);
  files.push(["xl/worksheets/sheet2.xml",sheetXml(ecSheet,{widths:[16,30,18,20,16,16,14,75,14,22,42],headerStyle:1,filterCols:11,freeze:true})]);
  files.push(["xl/worksheets/sheet3.xml",sheetXml(setup,{widths:[3,3,3,3,65,70,100],headerStyle:4})]);
  files.push(["xl/worksheets/sheet4.xml",sheetXml(info,{widths:[85,80]})]);
  return zipStore(files);
}
function downloadWorkbook(name, contactsInput, casesInput){
  const bytes=makeInitialWorkbookBytes(contactsInput,casesInput);
  const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([bytes],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}));a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);
}
function downloadSimpleXlsx(name,rows,headers){
  return downloadWorkbook(name,rows.map(r=>{
    const o={};headers.forEach(h=>o[h]=r[h]??"");return o;
  }),{});
}

async function saveCheckpoint(extra={}){
  try{
    await chrome.storage.local.set({[CHECKPOINT_KEY]:{
      version:APP_VERSION,savedAt:Date.now(),cases,contacts,
      stage:extra.stage||"",page:extra.page||0,contactIndex:extra.contactIndex||0,
      totalPages:extra.totalPages||0,config:extra.config||settings
    }})
  }catch(e){log("CHECKPOINT GAGAL • "+e.message)}
}
async function loadCheckpoint(){try{const x=await chrome.storage.local.get(CHECKPOINT_KEY);return x[CHECKPOINT_KEY]||null}catch{return null}}
async function clearCheckpoint(){try{await chrome.storage.local.remove(CHECKPOINT_KEY)}catch{}}

function sleep(ms){return ms>0?new Promise(r=>setTimeout(r,ms)):Promise.resolve()}
async function runPool(items, concurrency, worker, shouldStop){
  let cursor=0;
  const runners=Array.from({length:Math.min(Math.max(1,concurrency),Math.max(1,items.length))},async()=>{
    while(true){
      if(shouldStop?.()) return;
      const idx=cursor++;
      if(idx>=items.length) return;
      await worker(items[idx],idx);
    }
  });
  await Promise.all(runners);
}

async function fetchCasePage(page,c){
  return apiWithRetry(CASE_ENDPOINT,{page,pageSize:c.pageSize,scene:"collector_case_detail",tenantId:+c.tenant},
    {attempts:3,label:`CASE page ${page}`,shouldStop:()=>stopScrape||scrapeAbort});
}
async function scrapeCasePages(c,startPage,totalPagesKnown=0){
  // Page 1 is fetched first when needed so the server-reported totalPages can determine the full queue.
  let totalPages=totalPagesKnown;
  let nextPage=Math.max(1,startPage);
  if(nextPage===1){
    const out=await fetchCasePage(1,c); if(!out.r.ok) throw new Error(`CASE page 1 gagal • HTTP ${out.r.status||"NETWORK"}`);
    const root=out.d?.data||{}, records=Array.isArray(root.data)?root.data:[];
    records.forEach(o=>{const id=clean(o?.id);if(id)cases[id]=o});
    totalPages=Number(root.totalPages)||0;
    addScrape("CASE ID","Page 1","OK",records.length);
    log(`CASE page=1 records=${records.length} unik=${Object.keys(cases).length}${totalPages?` totalPages=${totalPages}`:""}`);
    await saveCheckpoint({stage:"cases",page:2,totalPages,config:c});
    if(!records.length || records.length<c.pageSize || (totalPages&&totalPages<=1)) return totalPages||1;
    nextPage=2;
    await sleep(c.pageDelay);
  }
  if(!totalPages){
    // Fallback when the API omits totalPages: fetch forward in small waves until a short/empty page is observed.
    let page=nextPage;
    while(!stopScrape&&!scrapeAbort){
      const batch=Array.from({length:c.caseConcurrency},(_,i)=>page+i);
      let stopAfter=false;
      await runPool(batch,c.caseConcurrency,async pg=>{
        if(stopScrape||scrapeAbort)return;
        const out=await fetchCasePage(pg,c); const {r,d}=out;
        if(!r.ok){addScrape("CASE",`Page ${pg}`,"GAGAL",r.status||"NETWORK");throw new Error(`CASE page ${pg} gagal • HTTP ${r.status||"NETWORK"}`)}
        const root=d?.data||{},records=Array.isArray(root.data)?root.data:[];
        records.forEach(o=>{const id=clean(o?.id);if(id)cases[id]=o});
        addScrape("CASE ID",`Page ${pg}`,"OK",records.length);
        log(`CASE page=${pg} records=${records.length} unik=${Object.keys(cases).length}`);
        if(!records.length||records.length<c.pageSize)stopAfter=true;
      },()=>stopScrape||scrapeAbort);
      const last=page+c.caseConcurrency-1;
      await saveCheckpoint({stage:"cases",page:last+1,totalPages:0,config:c});
      if(stopAfter) return last;
      page=last+1; await sleep(c.pageDelay);
    }
    return page-1;
  }
  const cappedEnd=c.maxPages?Math.min(totalPages,c.maxPages):totalPages;
  const pages=[];for(let pg=nextPage;pg<=cappedEnd;pg++)pages.push(pg);
  await runPool(pages,c.caseConcurrency,async pg=>{
    const out=await fetchCasePage(pg,c); const {r,d}=out;
    if(!r.ok){addScrape("CASE",`Page ${pg}`,"GAGAL",r.status||"NETWORK");throw new Error(`CASE page ${pg} gagal • HTTP ${r.status||"NETWORK"}`)}
    const root=d?.data||{},records=Array.isArray(root.data)?root.data:[];
    records.forEach(o=>{const id=clean(o?.id);if(id)cases[id]=o});
    addScrape("CASE ID",`Page ${pg}`,"OK",records.length);
    log(`CASE page=${pg} records=${records.length} unik=${Object.keys(cases).length}`);
    if(pg===cappedEnd || pg%Math.max(1,c.caseConcurrency)===0) await saveCheckpoint({stage:"cases",page:pg+1,totalPages,config:c});
  },()=>stopScrape||scrapeAbort);
  return cappedEnd;
}

async function scrape(){
  await save(); if(!(await checkLogin()))return;
  stopScrape=false;scrapeAbort=false;$('startScrape').disabled=true;$('stopScrape').disabled=false;$('scrapeTable').innerHTML="";$('scrapeProgress').style.width="0%";
  cases={};contacts=[];let page=1,totalPages=0,resumeContactIndex=0;const c=cfg(); const started=Date.now();
  const cp=await loadCheckpoint();
  if(cp&&cp.version===APP_VERSION&&await appConfirm(`Ditemukan checkpoint scraper dari ${new Date(cp.savedAt).toLocaleString('id-ID')}.\n\nLanjutkan dari data yang tersimpan?`,`Checkpoint Scraper`,`LANJUTKAN`)){
    cases=cp.cases||{};contacts=cp.contacts||[];page=Math.max(1,Number(cp.page)||1);totalPages=Number(cp.totalPages)||0;resumeContactIndex=cp.stage==="contacts"?Math.max(0,Number(cp.contactIndex)||0):0;
    log(`RESUME CHECKPOINT • cases=${Object.keys(cases).length} contacts=${contacts.length} page=${page} contactIndex=${resumeContactIndex} totalPages=${totalPages||"auto"}`);
  }
  try{
    const maxPagesLabel=c.maxPages?String(c.maxPages):"ALL";
    $('scrapeStatus').textContent=`Mengambil Case ID • mode ${maxPagesLabel} • ${c.caseConcurrency} paralel`;
    const caseEnd=await scrapeCasePages(c,page,totalPages);
    if(stopScrape||scrapeAbort) throw new Error("Dihentikan oleh pengguna.");
    const ids=Object.keys(cases); if(!ids.length) throw new Error("Tidak ada Case ID yang ditemukan.");
    const contactItems=ids.map((caseid,n)=>({caseid,n})).slice(resumeContactIndex);
    const seen=new Set(contacts.map(x=>`${x.case}|${x.mobile}|${x.phoneId}|${x.phoneType}`));
    let done=resumeContactIndex;
    $('scrapeProgress').style.width=`${totalPages?Math.round(Math.min(100,caseEnd/totalPages*50)):50}%`;
    await runPool(contactItems,c.contactConcurrency,async item=>{
      const {caseid,n}=item;
      if(stopScrape||scrapeAbort)return;
      $('scrapeStatus').textContent=`Mengambil Contact • ${Math.min(ids.length,done+1)}/${ids.length} • ${c.contactConcurrency} paralel`;
      const out=await apiWithRetry(CONTACT_ENDPOINT,{myselfLabel:"all",caseId:/^\d+$/.test(caseid)?+caseid:caseid},{attempts:3,label:`CONTACT ${caseid}`,shouldStop:()=>stopScrape||scrapeAbort});
      const {r,d}=out;
      if(!r.ok){addScrape("CONTACT",`Case ${caseid}`,"GAGAL",r.status||"NETWORK");log(`CONTACT GAGAL • Case ${caseid} • HTTP ${r.status||"NETWORK"}`);return}
      const arr=Array.isArray(d?.data)?d.data:[];
      for(const o of arr){const item={case:o?.caseId??caseid,name:o?.contactName??"",mobile:o?.contactPhone??"",phoneId:o?.phoneId??"",phoneType:String(o?.contactType??"").toUpperCase(),relation:String(o?.relationship??"").toUpperCase()};const key=`${item.case}|${item.mobile}|${item.phoneId}|${item.phoneType}`;if(!seen.has(key)){seen.add(key);contacts.push(item)}}
      addScrape("CONTACT",`Case ${caseid}`,"OK",arr.length);
      done=Math.max(done,n+1);
      $('scrapeProgress').style.width=`${Math.min(100,50+Math.round(done/ids.length*50))}%`;
      if(done%Math.max(1,c.contactConcurrency)===0 || done===ids.length) await saveCheckpoint({stage:"contacts",page:caseEnd+1,contactIndex:done,totalPages,config:c});
    },()=>stopScrape||scrapeAbort);
    if(stopScrape||scrapeAbort){$('scrapeStatus').textContent="Dihentikan • checkpoint tersimpan";log(`SCRAPER DIHENTIKAN • cases=${Object.keys(cases).length} contacts=${contacts.length}`);return}
    $('caseCount').textContent=Object.keys(cases).length;$('contactCount').textContent=contacts.length;
    const elapsed=Math.max(1,(Date.now()-started)/1000),speed=(contacts.length/elapsed).toFixed(1);
    $('scrapeStatus').textContent=`Selesai • ${Object.keys(cases).length} Case ID • ${contacts.length} kontak • ${speed}/detik`;
    log(`SCRAPER SELESAI • cases=${Object.keys(cases).length} contacts=${contacts.length} • ${speed} contact/detik`);
    await clearCheckpoint(); downloadWorkbook(`SMS_${todayFileDate()}.xlsx`,contacts,cases);
  }catch(e){
    if(stopScrape||scrapeAbort){await saveCheckpoint({stage:"stopped",page,totalPages,contactIndex:resumeContactIndex,config:c});log("SCRAPER DIHENTIKAN • checkpoint tersimpan");}
    else {log("SCRAPER ERROR • "+(e.message||e));await saveCheckpoint({stage:"error",page,totalPages,contactIndex:resumeContactIndex,config:c});appAlert("Scraper berhenti: "+(e.message||e)+"\n\nCheckpoint sudah disimpan. Jalankan kembali untuk melanjutkan.")}
  }finally{$('startScrape').disabled=false;$('stopScrape').disabled=true}
}

function contactsRows(){return contacts.map(x=>({"Case ID":x.case,"Contact Name":x.name,"Amount":normalizeAmount(x.amount!==""?x.amount:getCaseAmount(cases[x.case])),"Mobile":x.mobile,"Phone ID":x.phoneId,"Phone Type":x.phoneType,"Relation":x.relation}))}
function makeSmsTemplate(){
  if(!contacts.length){appAlert("Jalankan scraper terlebih dahulu.");return}
  downloadWorkbook(`SMS_${todayFileDate()}.xlsx`,contacts,cases);
  log("Template/output Excel dibuat mengikuti format Tools awal: SMS CH, SMS EC, SET UP TEMPLATE, Petunjuk.")
}

function parseCsv(text){
  const rows=[];let row=[],cell="",q=false;
  for(let i=0;i<text.length;i++){const ch=text[i],nx=text[i+1];if(q){if(ch=='"'&&nx=='"'){cell+='"';i++}else if(ch=='"')q=false;else cell+=ch}else{if(ch=='"')q=true;else if(ch==','){row.push(cell);cell=""}else if(ch=='\n'){row.push(cell);rows.push(row);row=[];cell=""}else if(ch!='\r')cell+=ch}}row.push(cell);if(row.length>1||row[0])rows.push(row);return rows}
async function unzipEntries(buffer){
  const u8=new Uint8Array(buffer),dv=new DataView(buffer);let eocd=-1;
  for(let i=u8.length-22;i>=Math.max(0,u8.length-65557);i--){if(dv.getUint32(i,true)===0x06054b50){eocd=i;break}}
  if(eocd<0)throw Error("File XLSX tidak valid (ZIP directory tidak ditemukan).");
  const cdSize=dv.getUint32(eocd+12,true),cdOff=dv.getUint32(eocd+16,true),out={};let p=cdOff;const td=new TextDecoder("utf-8");
  while(p<cdOff+cdSize){
    if(dv.getUint32(p,true)!==0x02014b50)throw Error("Struktur XLSX tidak valid.");
    const method=dv.getUint16(p+10,true),csize=dv.getUint32(p+20,true),nl=dv.getUint16(p+28,true),el=dv.getUint16(p+30,true),cl=dv.getUint16(p+32,true),lo=dv.getUint32(p+42,true),name=td.decode(u8.slice(p+46,p+46+nl));
    const lp=lo;if(dv.getUint32(lp,true)!==0x04034b50)throw Error("Local ZIP entry tidak valid.");
    const lnl=dv.getUint16(lp+26,true),lel=dv.getUint16(lp+28,true),start=lp+30+lnl+lel,raw=u8.slice(start,start+csize);let data;
    if(method===0)data=raw;else if(method===8){const ds=new DecompressionStream("deflate-raw");data=new Uint8Array(await new Response(new Blob([raw]).stream().pipeThrough(ds)).arrayBuffer())}else throw Error(`Metode kompresi XLSX tidak didukung: ${method}`);
    out[name]=td.decode(data);p+=46+nl+el+cl;
  }return out;
}
function xmlDoc(text){return new DOMParser().parseFromString(text,"application/xml")}
function xlsxCellValue(c,shared){
  const type=c.getAttribute("t")||"",v=c.getElementsByTagNameNS("*","v")[0],is=c.getElementsByTagNameNS("*","is")[0];
  if(type==="inlineStr"&&is)return Array.from(is.getElementsByTagNameNS("*","t")).map(x=>x.textContent).join("");
  if(!v)return "";const raw=v.textContent||"";if(type==="s")return shared[Number(raw)]??"";if(type==="b")return raw==="1"?"TRUE":"FALSE";return raw;
}
async function parseXlsxSms(buffer, channelMode=smsChannelMode){
  const files=await unzipEntries(buffer),wb=xmlDoc(files["xl/workbook.xml"]||""),rel=xmlDoc(files["xl/_rels/workbook.xml.rels"]||"");
  const relMap={};Array.from(rel.getElementsByTagNameNS("*","Relationship")).forEach(x=>relMap[x.getAttribute("Id")]=x.getAttribute("Target"));
  const shared=[];if(files["xl/sharedStrings.xml"]){const d=xmlDoc(files["xl/sharedStrings.xml"]);Array.from(d.getElementsByTagNameNS("*","si")).forEach(si=>shared.push(Array.from(si.getElementsByTagNameNS("*","t")).map(x=>x.textContent).join("")))}
  const sheets=Array.from(wb.getElementsByTagNameNS("*","sheet"));if(!sheets.length)throw Error("Workbook XLSX tidak memiliki sheet.");
  const wanted=channelMode==="EC"?/^sms\s*ec$/i:/^sms\s*ch$/i;
  const preferred=sheets.find(x=>wanted.test(clean(x.getAttribute("name")||""))) || sheets.find(x=>/sms|template|import/i.test(x.getAttribute("name")||"")) || sheets[0];
  const rid=preferred.getAttributeNS("http://schemas.openxmlformats.org/officeDocument/2006/relationships","id")||preferred.getAttribute("r:id");let target=relMap[rid];
  if(!target)throw Error("Sheet XLSX tidak ditemukan.");target=target.replace(/^\//,"");if(!target.startsWith("xl/"))target="xl/"+target;
  const sd=xmlDoc(files[target]||""),rows=Array.from(sd.getElementsByTagNameNS("*","row"));if(!rows.length)throw Error("Sheet XLSX kosong.");
  const parsed=[];for(const row of rows){const cells=Array.from(row.getElementsByTagNameNS("*","c")),obj={};let max=-1;for(const c of cells){const m=(c.getAttribute("r")||"").match(/([A-Z]+)\d+/i);if(!m)continue;let col=0;for(const ch of m[1].toUpperCase())col=col*26+(ch.charCodeAt(0)-64);col--;max=Math.max(max,col);obj[col]=xlsxCellValue(c,shared)}parsed.push({row:Number(row.getAttribute("r")||parsed.length+1),cells:obj,max})}
  const headerRow=parsed.find(r=>Object.values(r.cells).map(clean).filter(Boolean).length>0);if(!headerRow)throw Error("Header XLSX tidak ditemukan.");
  const heads=[];for(let i=0;i<=headerRow.max;i++)heads[i]=clean(headerRow.cells[i]||"");const miss=REQUIRED.filter(h=>!heads.includes(h));
  if(miss.length)throw Error("Kolom kurang: "+miss.join(", ")+". Pastikan memakai template SMS XLSX BantuSaku.");
  return parsed.filter(r=>r.row>headerRow.row).map(r=>{const o={excel_row:r.row};heads.forEach((h,j)=>{if(h)o[h]=clean(r.cells[j]??"")});return o}).filter(o=>Object.keys(o).some(k=>k!=="excel_row"&&o[k]!==""));
}
async function loadSmsXlsx(buffer, channelMode=smsChannelMode){
  smsFileBuffer=buffer; smsChannelMode=channelMode;
  smsRows=await parseXlsxSms(buffer,channelMode);
  smsRows.forEach(x=>{x.Amount=normalizeAmount(x.Amount??x.amount??"");});
  renderSms();
  const label=channelMode==="EC"?"SMS EC":"SMS CH";
  log(`XLSX ${label} dimuat: ${smsRows.length} baris.`);
}
function renderSms(){
  const tb=$("smsTable");tb.innerHTML="";let sent=0,fail=0,ready=0;
  smsRows.forEach((x,i)=>{if(x.Status==="TERKIRIM")sent++;if(x.Status==="GAGAL")fail++;if(x.Status==="SIAP")ready++;
    const tr=document.createElement("tr");tr.className=x.Status==="TERKIRIM"?"sent":x.Status==="GAGAL"?"failed":"ready";
    const check=document.createElement("input");check.type="checkbox";check.dataset.i=i;check.disabled=x.Status!=="SIAP";const td0=document.createElement("td");td0.append(check);tr.appendChild(td0);
    ["excel_row","Case ID","Contact Name","Amount","Mobile","Phone Type","Relation","Pesan","Status"].forEach(k=>{const td=document.createElement("td");td.textContent=x[k]??"";tr.appendChild(td)});tb.appendChild(tr)});
  $("sentCount").textContent=sent;$("failCount").textContent=fail;$("smsStatus").textContent=`${smsRows.length} kontak • SIAP ${ready} • TERKIRIM ${sent} • GAGAL ${fail}`;
}
function validateRow(x){const e=[];if(!x["Case ID"])e.push("Case ID kosong");if(!x["Contact Name"])e.push("Nama kosong");if(!x.Mobile)e.push("Mobile kosong");if(!x["Phone Type"])e.push("Phone Type kosong");if(!x.Relation)e.push("Relation kosong");if(x["Phone Type"].toUpperCase()==="USER_CONTACT"&&!x["Phone ID"])e.push("Phone ID wajib untuk USER_CONTACT");if(!x.Pesan)e.push("Pesan kosong");return e}
function validateSms(){const bad=smsRows.map((x,i)=>({i,e:validateRow(x)})).filter(x=>x.e.length);$("smsStatus").textContent=bad.length?`Validasi: ${bad.length} baris bermasalah.`:"Validasi OK — semua data siap.";if(bad.length)appAlert(bad.slice(0,15).map(x=>`Baris ${smsRows[x.i].excel_row}: ${x.e.join("; ")}`).join("\n"));else appAlert("Semua data valid.");}

function selectedReady(){return [...document.querySelectorAll("#smsTable input[type=checkbox]:checked")].map(x=>+x.dataset.i).filter(i=>smsRows[i]?.Status==="SIAP")}
function smsPayload(x){const req={currentChannel:"SMS",caseId:/^\d+$/.test(x["Case ID"])?+x["Case ID"]:x["Case ID"],contentType:2,contactName:x["Contact Name"],content:x.Pesan,mobile:x.Mobile,phoneType:x["Phone Type"].toUpperCase(),relation:x.Relation.toUpperCase()};if(x["Phone ID"])req.phoneId=/^\d+$/.test(x["Phone ID"])?+x["Phone ID"]:x["Phone ID"];return {channel:"SMS",manualSendSmsReq:req}}
function smsKey(x){return [clean(x["Case ID"]),clean(x.Mobile),clean(x["Phone ID"]),clean(x["Phone Type"]).toUpperCase(),clean(x.Relation).toUpperCase(),clean(x.Pesan)].join("|")}
function findSmsDuplicates(indices){const seen=new Map(),dupes=[];for(const i of indices){const k=smsKey(smsRows[i]);if(seen.has(k))dupes.push([seen.get(k),i]);else seen.set(k,i)}return dupes}
async function sendSms(indices){
  await save();if(!(await checkLogin()))return;if(!indices.length){appAlert("Tidak ada baris SIAP yang dipilih.");return}
  const dupes=findSmsDuplicates(indices);if(dupes.length){appAlert(`Ditemukan ${dupes.length} data duplikat dalam batch.\n\nPengiriman dibatalkan agar tidak berisiko double-send.\n\nSilakan hapus/perbaiki duplikat lalu coba lagi.`);log(`SMS DIBATALKAN • ${dupes.length} duplikat terdeteksi`);return}
  const invalid=indices.filter(i=>validateRow(smsRows[i]).length);if(invalid.length){appAlert(`${invalid.length} baris tidak valid. Jalankan Validasi sebelum mengirim.`);return}
  stopSms=false;smsAbort=false;$('sendAll').disabled=true;$('sendOne').disabled=true;$('stopSms').disabled=false;
  for(let n=0;n<indices.length&&!stopSms&&!smsAbort;n++){
    const i=indices[n],x=smsRows[i],errs=validateRow(x);$('smsProgress').style.width=`${Math.round(n/indices.length*100)}%`;
    if(errs.length){x.Status="GAGAL";x.Keterangan=errs.join("; ");renderSms();continue}
    try{
      // Deliberately no automatic retry here: a network timeout can be ambiguous and retrying may send the same SMS twice.
      const {r,d}=await pageApiPost(SMS_ENDPOINT,smsPayload(x),{timeoutMs:30000});const sr=d?.data?.sendSmsResp||{};const ok=r.status>=200&&r.status<300&&String(d?.code||"")==="200"&&sr.status===true;
      if(ok){x.Status="TERKIRIM";x["Waktu Kirim"]=new Date().toISOString().slice(0,19).replace("T"," ");x.Keterangan=`HTTP ${r.status}; code=200; status=true${sr.remaining!=null?"; remaining="+sr.remaining:""}`;log(`SMS TERKIRIM • Case ${x["Case ID"]} • ${x.Mobile}`)}
      else{x.Status="GAGAL";x.Keterangan=`HTTP ${r.status||"NETWORK"}; code=${d?.code??""}; ${d?.message??d?._error??""}`.slice(0,1000);log(`SMS GAGAL • Case ${x["Case ID"]} • ${x.Keterangan}`)}
    }catch(e){x.Status="GAGAL";x.Keterangan=String(e.message||e).slice(0,1000);log(`SMS ERROR • Case ${x["Case ID"]} • ${e.message}`)}
    renderSms();await new Promise(x=>setTimeout(x,150));
  }
  $('smsProgress').style.width=`${Math.min(100,Math.round((indices.length-(stopSms||smsAbort?1:0))/indices.length*100))}%`;$('sendAll').disabled=false;$('sendOne').disabled=false;$('stopSms').disabled=true;$('smsStatus').textContent=(stopSms||smsAbort)?"SMS dihentikan.":"Pengiriman selesai.";log((stopSms||smsAbort)?"SMS DIHENTIKAN":"SMS SELESAI");/* Auto-download hasil SMS dinonaktifkan. Download manual tetap tersedia. */
}

async function showSendConfirmModal(count, mode="KIRIM SEMUA", text="Periksa kembali data dan nomor tujuan sebelum melanjutkan."){
  const modal=$("sendConfirmModal"); if(!modal)return false;
  $("confirmCount").textContent=String(count);
  $("confirmMode").textContent=mode;
  $("sendConfirmText").textContent=text;
  modal.hidden=false; modal.setAttribute("aria-hidden","false");
  const ok=$("sendConfirmOk"), cancel=$("sendConfirmCancel"), close=$("sendConfirmClose");
  return await new Promise(resolve=>{
    let done=false;
    const finish=v=>{if(done)return;done=true;modal.hidden=true;modal.setAttribute("aria-hidden","true");cleanup();resolve(v)};
    const cleanup=()=>{ok.removeEventListener("click",yes);cancel.removeEventListener("click",no);close.removeEventListener("click",no);modal.querySelector(".send-modal-backdrop")?.removeEventListener("click",no);document.removeEventListener("keydown",esc)};
    const yes=()=>finish(true), no=()=>finish(false), esc=e=>{if(e.key==="Escape")no()};
    ok.addEventListener("click",yes);cancel.addEventListener("click",no);close.addEventListener("click",no);modal.querySelector(".send-modal-backdrop")?.addEventListener("click",no);document.addEventListener("keydown",esc);
    setTimeout(()=>ok.focus(),0);
  });
}

async function bindInitialTargetTab(){
  try{
    const saved=await chrome.storage.session.get([TARGET_TAB_KEY]);
    const existing=Number(saved[TARGET_TAB_KEY]||0);
    if(existing){
      try{
        const old=await chrome.tabs.get(existing);
        if(isCcoTab(old)) return old;
      }catch(_){}
    }
    const tabs=await chrome.tabs.query({active:true,currentWindow:true});
    const tab=tabs[0];
    if(isCcoTab(tab)){
      await chrome.storage.session.set({[TARGET_TAB_KEY]:tab.id});
      return tab;
    }
    return null;
  }catch(_){ return null; }
}

const bind=(id,event,fn)=>{const el=$(id);if(el)el.addEventListener(event,fn)};
bind("activateLicense","click",activateLicense);
bind("clearLicense","click",clearLicense);
bind("activationAlertClose","click",hideActivationAlert);
bind("checkLogin","click",()=>checkLogin(false));
bind("startScrape","click",scrape);
bind("stopScrape","click",async()=>{stopScrape=true;scrapeAbort=true;$("scrapeStatus").textContent="Meminta penghentian...";try{const tab=await getActiveCcoTab();await abortPageRequests(tab.id)}catch{}});
bind("downloadContacts","click",()=>contacts.length?downloadWorkbook(`data_sms.xlsx`,contacts,cases):appAlert("Belum ada hasil scraper."));
bind("downloadCases","click",()=>Object.keys(cases).length?download(`bantusaku_cases_${Date.now()}.json`,JSON.stringify(cases,null,2),"application/json"):appAlert("Belum ada hasil scraper."));
bind("loadXlsx","click",async()=>{const f=$("smsFile")?.files?.[0];if(!f)return appAlert("Pilih file XLSX.");try{await loadSmsXlsx(await f.arrayBuffer(),$("smsChannel")?.value||"CH")}catch(e){appAlert("Gagal membaca XLSX: "+e.message)}});
bind("smsChannel","change",async()=>{
  smsChannelMode=$("smsChannel")?.value||"CH";
  const sendAllBtn=$("sendAll"); if(sendAllBtn) sendAllBtn.textContent=`✉ KIRIM SEMUA ${smsChannelMode==="EC"?"SMS EC":"SMS CH"}`;
  if(!smsFileBuffer)return;
  try{await loadSmsXlsx(smsFileBuffer,smsChannelMode)}catch(e){appAlert("Gagal memuat sheet "+(smsChannelMode==="EC"?"SMS EC":"SMS CH")+": "+e.message)}
});
bind("validateSms","click",validateSms);
bind("sendOne","click",async()=>{const a=selectedReady();if(a.length!==1)return appAlert("Pilih tepat 1 baris SIAP.");const x=smsRows[a[0]];if(await showSendConfirmModal(1,"KIRIM 1 SMS",`SMS akan dikirim ke ${x["Contact Name"]||"Kontak"} (${x.Mobile||"Nomor tidak tersedia"}).`))sendSms(a)});
bind("sendAll","click",async()=>{const a=smsRows.map((x,i)=>x.Status==="SIAP"?i:-1).filter(i=>i>=0);if(!a.length)return appAlert("Tidak ada SMS berstatus SIAP.");const dup=findSmsDuplicates(a);if(dup.length)return appAlert(`Ditemukan ${dup.length} data duplikat dalam batch.\n\nPengiriman dibatalkan agar tidak berisiko double-send.`);if(await showSendConfirmModal(a.length,`KIRIM SEMUA ${smsChannelMode==="EC"?"SMS EC":"SMS CH"}`,`Anda akan mengirim ${a.length} ${smsChannelMode==="EC"?"SMS EC":"SMS CH"} yang berstatus SIAP. Pastikan data dan nomor tujuan sudah benar.`))sendSms(a)});
bind("stopSms","click",async()=>{stopSms=true;smsAbort=true;$("smsStatus").textContent="Meminta penghentian SMS...";try{const tab=await getActiveCcoTab();await abortPageRequests(tab.id)}catch{}});
bind("downloadSms","click",()=>smsRows.length?downloadWorkbook(`SMS_${todayFileDate()}.xlsx`,smsRows,cases):appAlert("Belum ada data SMS."));
bind("clearLog","click",()=>{$("logBox").value=""});
document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));document.querySelectorAll(".panel").forEach(x=>x.classList.remove("active"));b.classList.add("active");$(b.dataset.tab).classList.add("active")});

(async()=>{
  smsChannelMode=$("smsChannel")?.value||"CH";
  const sendAllBtn=$("sendAll"); if(sendAllBtn) sendAllBtn.textContent=`✉ KIRIM SEMUA ${smsChannelMode==="EC"?"SMS EC":"SMS CH"}`;
  await bindInitialTargetTab();
  await load();
  const active=await initLicenseGate();
  if(active){
    try{
      const target=await getTargetTab();
      log(`SMS Tools V${APP_VERSION} siap • Tab sesi dikunci ke #${target.id}. Anda bebas berpindah ke tab lain.`);
    }catch(e){
      log("TAB SESI • "+(e.message||e));
    }
    setTimeout(()=>checkLogin(true),250);
    setInterval(async()=>{
      const ok=await refreshLicense(true);
      if(!ok) await appAlert("License tidak lagi aktif. Tools dikunci.");
    },LICENSE_CHECK_INTERVAL);
  }
})();
