const SECRET = new TextEncoder().encode("VQ-CHANGE-THIS-OWNER-SECRET-2026");
const PRODUCTS = new Set(["Scraper Tools V1", "BantuSaku Scraper Pro"]);

const $=id=>document.getElementById(id);
let deviceId="";

function b64urlDecode(s){
  s=s.replace(/-/g,"+").replace(/_/g,"/");
  s += "=".repeat((4-s.length%4)%4);
  const bin=atob(s); const a=new Uint8Array(bin.length);
  for(let i=0;i<bin.length;i++)a[i]=bin.charCodeAt(i);
  return a;
}
function b64urlEncode(a){
  let s=""; for(const x of new Uint8Array(a)) s+=String.fromCharCode(x);
  return btoa(s).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"");
}
async function hmac(){
  return crypto.subtle.importKey("raw",SECRET,{name:"HMAC",hash:"SHA-256"},false,["verify"]);
}
function hexDecode(s){
  if(!/^[0-9a-fA-F]+$/.test(s) || s.length % 2) throw new Error("signature hex tidak valid");
  const a=new Uint8Array(s.length/2);
  for(let i=0;i<a.length;i++) a[i]=parseInt(s.slice(i*2,i*2+2),16);
  return a;
}
async function verifyToken(token){
  try{
    token=String(token||"").replace(/\s+/g,"").trim(); if(!token.startsWith("VQ-")) return [false,"Format license tidak valid."];
    const body=token.slice(3), dot=body.lastIndexOf(".");
    if(dot<=0) return [false,"Format kode tidak valid."];
    const encoded=body.slice(0,dot), sig=body.slice(dot+1);
    const raw=b64urlDecode(encoded), key=await hmac();
    // Python license generator signs with HMAC-SHA256 and stores the digest as hex.
    const ok=await crypto.subtle.verify("HMAC",key,hexDecode(sig),raw);
    if(!ok) return [false,"Signature tidak valid."];
    const payload=JSON.parse(new TextDecoder().decode(raw));
    return [true,payload];
  }catch(e){return [false,"Format kode tidak valid."]}
}
async function makeDeviceId(){
  const s=await chrome.storage.local.get("deviceId");
  if(s.deviceId) return s.deviceId;
  const id=crypto.randomUUID().replaceAll("-","").toUpperCase();
  await chrome.storage.local.set({deviceId:id});
  return id;
}
function daysLeft(exp){
  const end=new Date(exp+"T00:00:00"), now=new Date();
  const a=new Date(now.getFullYear(),now.getMonth(),now.getDate());
  return Math.floor((end-a)/86400000);
}
async function getLicense(){
  const s=await chrome.storage.local.get(["license"]);
  return s.license||{};
}
async function licenseInfo(){
  const lic=await getLicense(), [ok,p]=await verifyToken(lic.license_blob||"");
  if(!ok) return {active:false,status:"BELUM AKTIF",expires:"-",days:null,key:lic.license_key||"-"};
  if(!PRODUCTS.has(p.product)) return {active:false,status:"PRODUK TIDAK COCOK",expires:p.expires||"-",days:null,key:lic.license_key||"-"};
  if(p.type) return {active:false,status:"BUKAN LICENSE KEY",expires:p.expires||"-",days:null,key:lic.license_key||"-"};
  const days=daysLeft(String(p.expires||"1900-01-01"));
  const same=!lic.device_id||lic.device_id===deviceId;
  const active=same&&days>=0;
  return {active,status:same?(active?"AKTIF":"EXPIRED"):"DEVICE TIDAK COCOK",expires:p.expires||"-",days,key:lic.license_key||"-"};
}
async function refreshLicense(){
  const i=await licenseInfo();
  $("licStatus").textContent=i.status; $("licExpiry").textContent=i.expires;
  $("licDays").textContent=i.days==null?"-":`${i.days} hari`;
  $("licenseBadge").textContent=i.status;
  $("licenseBadge").className="badge "+(i.active?"ok":"off");
  $("start").disabled=!i.active;
  return i.active;
}
async function activate(){
  const key=$("licenseKey").value.trim();
  const [ok,p]=await verifyToken(key);
  if(!ok){$("licenseMsg").textContent=p;return}
  if(!PRODUCTS.has(p.product)){$("licenseMsg").textContent="License bukan untuk Scraper Tools V1.";return}
  if(p.type){$("licenseMsg").textContent="Kode tersebut bukan License Key.";return}
  const days=daysLeft(String(p.expires||"1900-01-01"));
  if(days<0){$("licenseMsg").textContent=`License expired pada ${p.expires}.`;return}
  const current=await getLicense();
  if(current.device_id && current.device_id!==deviceId){
    const [tokOk,tp]=await verifyToken($("transferCode").value.trim());
    if(!tokOk){$("licenseMsg").textContent="License sudah terikat ke profil lain. Masukkan Transfer Code.";return}
    if(tp.type!=="TRANSFER" || !PRODUCTS.has(tp.product) || tp.license_id!==p.id || String(tp.old_device||"").toUpperCase()!==String(current.device_id).toUpperCase()){
      $("licenseMsg").textContent="Transfer Code tidak cocok.";return
    }
  }
  await chrome.storage.local.set({license:{license_key:key,license_blob:key,device_id:deviceId,activated_at:Date.now()}});
  $("licenseMsg").textContent=`Lisensi aktif sampai ${p.expires}.`;
  await refreshLicense();
}
async function clearLicense(){
  await chrome.storage.local.remove("license"); $("licenseKey").value=""; $("transferCode").value="";
  $("licenseMsg").textContent="Lisensi lokal dihapus."; await refreshLicense();
}
async function activeTab(){
  const tabs=await chrome.tabs.query({active:true,currentWindow:true});
  return tabs[0];
}
async function pingTab(){
  const tab=await activeTab();
  if(!tab?.id) return false;
  if(!/^https:\/\/cco-agent\.bantusaku\.id\//.test(tab.url||"")) return false;
  try{
    await chrome.tabs.sendMessage(tab.id,{type:"PING"});
    return true;
  }catch(_){return false}
}
async function startScrape(){
  if(!(await refreshLicense())) return;
  const tab=await activeTab();
  if(!tab?.id || !/^https:\/\/cco-agent\.bantusaku\.id\//.test(tab.url||"")){
    $("status").textContent="Buka cco-agent.bantusaku.id pada tab aktif terlebih dahulu.";return;
  }
  try{
    await chrome.tabs.sendMessage(tab.id,{type:"START_SCRAPE",options:{
      tenantId:$("tenantId").value,pageSize:$("pageSize").value,maxPages:$("maxPages").value,
      retry:$("retry").value,caseFilter:$("caseFilter").value
    }});
    $("start").disabled=true;$("stop").disabled=false;$("bar").style.width="0%";
    $("status").textContent="Scrape dimulai...";
  }catch(e){$("status").textContent="Session/tab belum siap. Refresh halaman lalu coba lagi."}
}
async function stopScrape(){
  const tab=await activeTab(); if(tab?.id) try{await chrome.tabs.sendMessage(tab.id,{type:"STOP_SCRAPE"})}catch(_){}
  $("stop").disabled=true;$("status").textContent="Meminta penghentian...";
}
chrome.runtime.onMessage.addListener(msg=>{
  if(msg.type==="SCRAPER_PROGRESS"){
    if(msg.phase==="CASE") $("status").textContent=`Case page ${msg.page}: ${msg.total} case terkumpul`;
    else {
      const pct=msg.total?Math.round(msg.index/msg.total*100):0;
      $("bar").style.width=pct+"%";
      $("status").textContent=`Case ${msg.index}/${msg.total} • ${msg.users||0} user • ${msg.contacts||0} contact`;
      $("caseCount").textContent=msg.index||0;$("userCount").textContent=msg.users||0;$("contactCount").textContent=msg.contacts||0;
    }
  }
  if(msg.type==="SCRAPER_DONE"){
    $("stop").disabled=true;$("start").disabled=false;$("bar").style.width="100%";
    $("caseCount").textContent=msg.cases;$("userCount").textContent=msg.users;$("contactCount").textContent=msg.contacts;
    $("status").textContent=`Selesai. File hasil masuk ke folder download "${msg.folder}".`;
  }
  if(msg.type==="SCRAPER_ERROR"){
    $("stop").disabled=true; refreshLicense(); $("status").textContent="ERROR: "+msg.message;
  }
});
(async()=>{
  deviceId=await makeDeviceId(); $("deviceId").textContent=deviceId;
  const saved=await getLicense(); $("licenseKey").value=saved.license_key||"";
  const ok=await refreshLicense();
  $("siteNotice").innerHTML=await pingTab() ? "Session tab terdeteksi. <b>Siap scrape.</b>" : "Buka dan login ke <b>cco-agent.bantusaku.id</b> pada tab Chrome aktif.";
})();
$("activate").onclick=activate; $("clearLicense").onclick=clearLicense; $("start").onclick=startScrape; $("stop").onclick=stopScrape;