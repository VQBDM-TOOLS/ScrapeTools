# BantuSaku Scraper Pro v1.6 — Chrome Extension parity patch

Perbaikan utama:
- Parser response API adaptif/recursive.
- Data User Info tidak lagi bergantung pada satu struktur `data`.
- Data EC/CH mencari array contact di seluruh response.
- Alias field contact: contactName/name/userName, contactPhone/phone/phoneNumber/mobileNumber, dll.
- Nama CH di Emergency Contact dicocokkan berdasarkan Case ID.
- Fallback Nama CH dan nomor dari data Case jika endpoint detail tidak mengembalikan field tertentu.
- Output hanya satu file Excel (CSV/JSONL terpisah sengaja tidak dibuat oleh extension).
- Perlindungan terhadap limit karakter Excel tetap aktif.
# Scraper Tools V1 — Chrome Extension

Versi 1.2.0 Chrome Extension dari program `vqbuild/bantusaku_scraper_pro.py`.

## Fitur
- Mengikuti header autentikasi dari request API pada tab login secara sementara di memory extension; tidak menyimpan Bearer Token ke storage.
- License Key offline dengan format VQ-...
- Binding lisensi ke profil Chrome extension.
- Case pagination dengan Page Size dan Max Pages.
- Filter Case ID.
- User Info.
- Contact.
- Complete Phone mengikuti endpoint yang sudah dipakai aplikasi desktop.
- Progress dan counter Case/User/Contact.
- Ekspor CSV dan JSONL melalui Chrome Downloads.

## Instalasi
1. Extract ZIP ini.
2. Buka `chrome://extensions`.
3. Aktifkan **Developer mode**.
4. Klik **Load unpacked**.
5. Pilih folder `bantusaku_scraper_extension`.
6. Buka `https://cco-agent.bantusaku.id/`, lalu login.
7. Klik icon extension dan buka Side Panel.
8. Masukkan License Key yang dibuat untuk produk **Scraper Tools V1**.
9. Tekan **Mulai Scrape**.

## Catatan lisensi
Validasi HMAC masih menggunakan secret yang sama dengan aplikasi desktop agar kompatibel dengan generator yang ada. Karena secret berada di extension client-side, mekanisme ini **tidak cocok untuk proteksi anti-pembajakan tingkat tinggi**. Untuk produksi, sebaiknya generator memegang private key dan extension hanya menyimpan public key untuk verifikasi tanda tangan asimetris.

Binding "device" di extension berbeda dari EXE: Chrome tidak memberi extension akses ke hardware ID PC. Karena itu extension membuat ID acak yang disimpan di `chrome.storage.local`, sehingga secara praktis terikat ke profil/installasi extension tersebut.

## Ekspor Excel — parity dengan program desktop
- Menghasilkan satu file `.xlsx` multi-sheet dengan struktur mengikuti template yang diberikan.
- Sheet: `Sheet`, `EC & CH`, `DATA NASABAH`, `EMERGENCY CONTACT`, `SUMMARY`, `RAW USER INFO`, `RAW CONTACT JSON`, `RAW CASE JSON`, `INFO`.
- Kolom `Nama CH` pada `EMERGENCY CONTACT` diisi dari `identity.userName` berdasarkan `caseId`.
- `DATA NASABAH` mengikuti program desktop: tepat satu baris per Case ID, memakai record User Info pertama untuk Case tersebut.
- Sheet audit/raw tetap berada di dalam workbook Excel, bukan sebagai file terpisah.
- CSV dan JSONL tetap dibuat sebagai backup.

## Ekspor
Extension hanya menghasilkan **satu file Excel `.xlsx`**. CSV dan JSONL terpisah sengaja dihilangkan agar output Chrome tetap satu file.

## Troubleshooting
- Jika muncul HTTP 401, reload extension lalu refresh halaman `cco-agent.bantusaku.id` agar request API login dapat terdeteksi. Setelah itu jalankan scraper dari tab yang sama.
- Pastikan tab aktif adalah domain `cco-agent.bantusaku.id`.
- Jika extension baru saja di-reload dari `chrome://extensions`, refresh tab situs tersebut.

## Perbaikan v1.1.0
- Memantau request API dari tab aktif untuk mengambil header autentikasi yang memang digunakan aplikasi.
- Header autentikasi hanya disimpan di memory service worker, bukan `chrome.storage`.
- Request scraper memakai header tersebut sehingga tidak lagi mengandalkan cookie saja.
- Jika aplikasi mengganti token, request API berikutnya akan memperbarui header yang tersimpan.
