(() => {
  if (window.__bantusakuScraperLoaded) return;
  window.__bantusakuScraperLoaded = true;

  const ENDPOINTS = {
    cases: "/api/v1/collection/im-cases/select-cases",
    user: "/api/v1/collection/user/select-user-info",
    contacts: "/api/v1/collection/contact/select-user-contact-listing",
    completePhone: "/api/v1/collection/contact/select-complete-phone"
  };

  let stopRequested = false;

  const clean = v => v == null ? "" : String(v).trim().replace(/^(['"])(.*)\1$/, "$2").trim();

  function flatten(obj, prefix="", out={}) {
    if (obj && typeof obj === "object" && !Array.isArray(obj)) {
      for (const [k,v] of Object.entries(obj)) {
        const key = prefix ? `${prefix}.${k}` : k;
        if (v && typeof v === "object") flatten(v, key, out);
        else out[key] = clean(v);
      }
    } else if (Array.isArray(obj)) {
      out[prefix || "value"] = JSON.stringify(obj);
    } else out[prefix || "value"] = clean(obj);
    return out;
  }

  function emit(type, data={}) {
    chrome.runtime.sendMessage({type, ...data}).catch(()=>{});
  }

  async function getAuthHeaders() {
    try {
      const r = await new Promise(resolve => {
        chrome.runtime.sendMessage({type:"GET_AUTH_HEADERS", tabId: null}, resolve);
      });
      return (r && r.ok && r.headers) ? r.headers : {};
    } catch (_) { return {}; }
  }

  async function request(path, payload, label, retry=3) {
    let last;
    for (let attempt=1; attempt<=retry; attempt++) {
      if (stopRequested) throw new Error("STOP_REQUESTED");
      try {
        const auth = await getAuthHeaders();
        const res = await fetch(path, {
          method:"POST",
          credentials:"include",
          headers: {
            "Content-Type":"application/json",
            "Accept":"application/json, text/plain, */*",
            "Country":"ID",
            "Language":"id",
            "Tenantid": String(payload?.tenantId ?? 154),
            "Timezone":"7",
            ...auth
          },
          body: JSON.stringify(payload)
        });
        const text = await res.text();
        let data;
        try { data = JSON.parse(text); } catch (_) { data = {raw:text}; }
        if (!res.ok) {
          const detail = text && text.length < 500 ? ` - ${text.replace(/\s+/g," ").trim()}` : "";
          throw new Error(`${label}: HTTP ${res.status}${detail}`);
        }
        return {status:res.status,data};
      } catch(e) {
        last=e;
        if (attempt<retry) await new Promise(r=>setTimeout(r, 700*attempt));
      }
    }
    throw last || new Error(`${label}: request gagal`);
  }

  function findArrays(node, out=[], path="", depth=0, seen=new Set()) {
    if (node == null || depth > 10) return out;
    if (typeof node !== "object" || seen.has(node)) return out;
    seen.add(node);
    if (Array.isArray(node)) {
      const objs=node.filter(x=>x && typeof x === "object" && !Array.isArray(x));
      if (objs.length) out.push({items:objs,path});
      for (let i=0;i<node.length && i<3;i++) findArrays(node[i],out,`${path}[${i}]`,depth+1,seen);
      return out;
    }
    for (const [k,v] of Object.entries(node)) findArrays(v,out,path?`${path}.${k}`:k,depth+1,seen);
    return out;
  }

  function recordsFrom(data) {
    // The desktop program knows the current API shape:
    // response.data = { data: [...], count, total, pageSize }
    // Keep that path first so an unrelated nested array can never be selected.
    if (data && typeof data === "object" && !Array.isArray(data)) {
      const root = data.data;
      if (Array.isArray(root)) return {records:root.filter(x=>x&&typeof x==="object"), meta:data};
      if (root && typeof root === "object" && !Array.isArray(root)) {
        for (const k of ["data","records","rows","list","items","results"]) {
          if (Array.isArray(root[k])) return {records:root[k].filter(x=>x&&typeof x==="object"), meta:root};
        }
      }
    }
    // Generic fallback for older/alternate response wrappers.
    const preferred=["data","records","rows","list","items","results","content","result","contacts","users"];
    const seen=new Set();
    function walk(node,meta,depth=0){
      if(node==null || depth>10) return null;
      if(Array.isArray(node)) return {records:node.filter(x=>x&&typeof x==="object"),meta:meta||{}};
      if(typeof node!=="object" || seen.has(node)) return null;
      seen.add(node);
      for(const k of preferred){
        if(Array.isArray(node[k])) return {records:node[k].filter(x=>x&&typeof x==="object"),meta:node};
      }
      for(const k of preferred){
        if(node[k] && typeof node[k]==="object"){
          const hit=walk(node[k],node,depth+1); if(hit && hit.records.length) return hit;
        }
      }
      const arrays=findArrays(node);
      arrays.sort((a,b)=>b.items.length-a.items.length);
      if(arrays.length) return {records:arrays[0].items,meta:node};
      return {records:[node],meta:node};
    }
    return walk(data,data,0)||{records:[],meta:{}};
  }

  function extractDataPayload(data){
    let cur=data;
    for(let i=0;i<10;i++){
      if(cur==null || typeof cur!=="object" || Array.isArray(cur)) break;
      if(Object.prototype.hasOwnProperty.call(cur,"data")) cur=cur.data;
      else if(Object.prototype.hasOwnProperty.call(cur,"result")) cur=cur.result;
      else if(Object.prototype.hasOwnProperty.call(cur,"userInfo")) cur=cur.userInfo;
      else break;
    }
    return cur;
  }

  function pick(obj, keys, fallback="") {
    if(!obj || typeof obj!=="object") return fallback;
    for(const k of keys){
      const v=obj[k];
      if(v!==undefined && v!==null && clean(v)!=="") return v;
    }
    return fallback;
  }

  function normalizeUserRecord(info, caseId, caseObj) {
    let rec=info;
    if(Array.isArray(rec)) rec=rec.find(x=>x&&typeof x==="object") || {};
    if(!rec || typeof rec!=="object") rec={};
    // Some API versions wrap the actual user object under user/info/userInfo.
    for(let i=0;i<6;i++){
      const nested=pick(rec,["user","info","userInfo","profile"],null);
      if(nested && typeof nested==="object" && !Array.isArray(nested)){ rec=nested; continue; }
      break;
    }
    const flat=flatten(rec); flat.caseId=caseId;
    const caseName=pick(caseObj,["user_name","userName","name"],"");
    const caseMobile=pick(caseObj,["mobile","mobileNumber","phone"],"");
    if(!flat["identity.userName"] && caseName) flat["identity.userName"]=clean(caseName);
    if(!flat["identity.mobileNumber"] && caseMobile) flat["identity.mobileNumber"]=clean(caseMobile);
    const cc=pick(caseObj,["caseCode","case_code"],"");
    if(!flat.caseCode && cc) flat.caseCode=clean(cc);
    return flat;
  }

  function normalizeContactRecord(original, caseId, caseObj) {
    const c={...(original||{})};
    c.caseId=pick(c,["caseId","case_id"],caseId) || caseId;
    c.contactName=pick(c,["contactName","name","userName","contact_name","phoneName"],"");
    c.contactPhone=pick(c,["contactPhone","phone","phoneNumber","mobileNumber","contact_phone"],"");
    c.contactType=pick(c,["contactType","phoneType","contact_type","type"],"");
    c.relationship=pick(c,["relationship","relationshipCode","relation","relationCode"],"");
    c.phoneId=pick(c,["phoneId","phone_id","id"],"");
    if(!c.contactName && c.contactType!=="USER_CONTACT") c.contactName=pick(caseObj,["user_name","userName"],"");
    return c;
  }
  function csv(rows) {
    rows = rows || [];
    const keys = [...new Set(rows.flatMap(r => Object.keys(r || {})))];
    if (!keys.length) return "data\r\n";
    const esc = v => {
      if (v == null) return "";
      let s = typeof v === "object" ? JSON.stringify(v) : String(v);
      return /[",\r\n]/.test(s) ? `"${s.replace(/"/g,'""')}"` : s;
    };
    return "\uFEFF" + [keys.map(esc).join(","), ...rows.map(r => keys.map(k=>esc(r?.[k])).join(","))].join("\r\n");
  }

  function stamp() {
    const d=new Date(), p=n=>String(n).padStart(2,"0");
    return `${d.getFullYear()}${p(d.getMonth()+1)}${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
  }

  async function download(name, text, mime="text/plain") {
    const blob = new Blob([text], {type:mime});
    const url = URL.createObjectURL(blob);
    const a=document.createElement("a");
    a.href=url; a.download=name; a.style.display="none";
    document.documentElement.appendChild(a); a.click(); a.remove();
    setTimeout(()=>URL.revokeObjectURL(url), 3000);
  }


  // ===== Excel XLSX export (template-compatible multi-sheet workbook) =====
  const CASE_COLUMNS = [
    "_case_id","agency_name","app_name","borrow_type","casePendingReplyFlag",
    "casePromiseRepaymentFlag","case_code","case_status","collector_name",
    "credit_type","due_date","group_name","hasCollectionLog","id",
    "last_user_reach_at","loan_amount","mobile","outstanding_amount",
    "overdue_days","overdue_installments","product_name","product_type",
    "queue_code","system_name","team_name","total_installments",
    "user_name","waived_amount"
  ];
  const CONTACT_COLUMNS = ["caseId","contactName","contactPhone","contactType","Nama CH","DPD","Ammount"];
  const USER_COLUMNS = [
    "caseId","bank.accountNumber","bank.bankName","bank.disbursementChannel",
    "employment.companyName","employment.companyPhone","employment.incomeRange",
    "employment.jobTitle","employment.workAddress","identity.address",
    "identity.birthDate","identity.educationLevel","identity.email",
    "identity.gender","identity.maritalStatus","identity.mobileNumber",
    "identity.userName","phoneType","userPic.livePhoto"
  ];
  const INFO_ROWS = [
    ["Fitur","Keterangan"],
    ["Scraper","Case + User Info + Contact + Complete Phone"],
    ["Format Excel","Mengikuti template: Sheet, EC & CH, DATA NASABAH, EMERGENCY CONTACT, SUMMARY"],
    ["SMS","Dihapus dari aplikasi"],
    ["Authentication","Bearer Token"],
    ["Output","Excel + audit sheets + automatic Chrome download"],
    ["Retry","Configurable with retry-safe delays"],
    ["Audit","Request/error log + completeness status"],
    ["Integrity","COMPLETE / PARTIAL / STOPPED status"]
  ];

  // Excel cell text limit is 32,767 UTF-16 code units.
  // Keep a safety margin because the RAW JSON sheets can contain very large responses.
  const EXCEL_TEXT_LIMIT = 30000;

  function cleanXmlText(value) {
    return String(value ?? "").replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\uFFFE\uFFFF]/g, "");
  }

  const xmlEsc = v => cleanXmlText(v)
    .replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")
    .replace(/"/g,"&quot;").replace(/\'/g,"&apos;");

  function excelCell(v) {
    const s = typeof v === "object" && v !== null ? JSON.stringify(v) : String(v ?? "");
    if (!s) return `<c t="inlineStr"><is><t></t></is></c>`;
    const safe = cleanXmlText(s);
    return `<c t="inlineStr"><is><t xml:space="preserve">${xmlEsc(safe)}</t></is></c>`;
  }

  function normalizeRowsForExcel(rows) {
    // Any string over the Excel limit is split into continuation rows.
    // This prevents Excel's "Repaired Records: String properties" warning
    // while preserving the complete JSON/text in the workbook.
    const out = [];
    for (const row of (rows || [])) {
      const normalized = Array.isArray(row) ? row.slice() : [row];
      let chunks = null;
      for (let i=0; i<normalized.length; i++) {
        if (typeof normalized[i] !== "string") continue;
        const value = normalized[i];
        if (value.length > EXCEL_TEXT_LIMIT) {
          chunks = [];
          for (let p=0; p<value.length; p += EXCEL_TEXT_LIMIT) chunks.push(value.slice(p,p+EXCEL_TEXT_LIMIT));
          break;
        }
      }
      if (!chunks) { out.push(normalized); continue; }
      // Put the first chunk in the original column and continuation chunks
      // in additional rows with the same leading identifiers.
      const targetIndex = normalized.findIndex(v => typeof v === "string" && v.length > EXCEL_TEXT_LIMIT);
      chunks.forEach((chunk, idx) => {
        const r = normalized.slice();
        r[targetIndex] = chunk;
        if (idx > 0 && r.length > 0) r[0] = `${r[0] ?? ""} (cont. ${idx+1})`;
        out.push(r);
      });
    }
    return out;
  }

  function sheetXml(rows, widths=[], autoFilter=true) {
    rows = normalizeRowsForExcel(rows || []);
    const maxCols = Math.max(1, ...rows.map(r => r.length));
    const colLetter = n => {
      let s="";
      while(n){ const m=(n-1)%26; s=String.fromCharCode(65+m)+s; n=Math.floor((n-1)/26); }
      return s;
    };
    let cols = "";
    if (widths.length) {
      cols = `<cols>${widths.map((w,i)=>`<col min="${i+1}" max="${i+1}" width="${Number(w)||12}" customWidth="1"/>`).join("")}</cols>`;
    }
    const body = rows.map((r,ri) => {
      const vals = Array.from({length:maxCols},(_,i)=>r[i] ?? "");
      return `<row r="${ri+1}">${vals.map(excelCell).join("")}</row>`;
    }).join("");
    const filter = autoFilter && rows.length
      ? `<autoFilter ref="A1:${colLetter(maxCols)}${rows.length}"/>` : "";
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
 xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheetViews><sheetView showGridLines="0" workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/><selection pane="bottomLeft" activeCell="A2" sqref="A2"/></sheetView></sheetViews>
${cols}<sheetData>${body}</sheetData>${filter}</worksheet>`;
  }

  function crc32(bytes) {
    let table = crc32._table;
    if (!table) {
      table = crc32._table = new Uint32Array(256);
      for(let n=0;n<256;n++){
        let c=n;
        for(let k=0;k<8;k++) c=(c&1)?(0xEDB88320^(c>>>1)):(c>>>1);
        table[n]=c>>>0;
      }
    }
    let c=0xFFFFFFFF;
    for(const b of bytes) c=table[(c^b)&255]^(c>>>8);
    return (c^0xFFFFFFFF)>>>0;
  }

  function u16(n){ return new Uint8Array([n&255,(n>>>8)&255]); }
  function u32(n){ return new Uint8Array([n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255]); }
  function concatBytes(parts) {
    const total=parts.reduce((n,a)=>n+a.length,0), out=new Uint8Array(total);
    let p=0; for(const a of parts){out.set(a,p);p+=a.length;} return out;
  }

  // Minimal ZIP writer using "stored" entries. Excel accepts this valid XLSX container.
  function makeZip(entries) {
    const local=[], central=[]; let offset=0;
    const enc=new TextEncoder();
    for(const [name,text] of entries){
      const nb=enc.encode(name), data=enc.encode(text), crc=crc32(data);
      const lh=concatBytes([
        u32(0x04034b50),u16(20),u16(0x0800),u16(0),u16(0),u16(0),
        u32(crc),u32(data.length),u32(data.length),u16(nb.length),u16(0),nb,data
      ]);
      local.push(lh);
      const ch=concatBytes([
        u32(0x02014b50),u16(20),u16(20),u16(0x0800),u16(0),u16(0),u16(0),
        u32(crc),u32(data.length),u32(data.length),u16(nb.length),u16(0),
        u16(0),u16(0),u16(0),u32(0),u32(offset),nb
      ]);
      central.push(ch); offset+=lh.length;
    }
    const centralBytes=concatBytes(central), localBytes=concatBytes(local);
    const end=concatBytes([
      u32(0x06054b50),u16(0),u16(0),u16(entries.length),u16(entries.length),
      u32(centralBytes.length),u32(localBytes.length),u16(0)
    ]);
    return concatBytes([localBytes,centralBytes,end]);
  }

  function buildXlsx(sheets) {
    const esc = xmlEsc;
    const workbookSheets = sheets.map((s,i)=>`<sheet name="${esc(s.name)}" sheetId="${i+1}" r:id="rId${i+1}"/>`).join("");
    const workbook = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
 xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheets>${workbookSheets}</sheets></workbook>`;
    const rels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
${sheets.map((s,i)=>`<Relationship Id="rId${i+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i+1}.xml"/>`).join("")}
<Relationship Id="rId${sheets.length+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>`;
    const rootRels=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>`;
    const ct = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
${sheets.map((s,i)=>`<Override PartName="/xl/worksheets/sheet${i+1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join("")}
<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
</Types>`;
    const styles=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<numFmts count="0"/><fonts count="1"><font><sz val="11"/><name val="Calibri"/></font></fonts>
<fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>
<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellXfs>
</styleSheet>`;
    const entries=[
      ["[Content_Types].xml",ct],
      ["_rels/.rels",rootRels],
      ["xl/workbook.xml",workbook],
      ["xl/_rels/workbook.xml.rels",rels],
      ["xl/styles.xml",styles]
    ];
    sheets.forEach((s,i)=>entries.push([`xl/worksheets/sheet${i+1}.xml`,sheetXml(s.rows,s.widths,s.autoFilter!==false)]));
    return makeZip(entries);
  }

  function rowFrom(obj, columns) {
    return columns.map(k => obj?.[k] == null ? "" : obj[k]);
  }

  function bytesToBase64(bytes){
    const arr=bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
    let binary="";
    const chunk=0x8000;
    for(let i=0;i<arr.length;i+=chunk) binary+=String.fromCharCode(...arr.subarray(i,i+chunk));
    return btoa(binary);
  }

  async function downloadXlsx(filename, sheets) {
    const bytes=buildXlsx(sheets);
    const base64=bytesToBase64(bytes);
    // Prefer the downloads API through the service worker so the report is
    // registered by Chrome's download manager and does not depend on a DOM click.
    if(base64.length<=45_000_000){
      const result=await new Promise(resolve=>chrome.runtime.sendMessage({
        type:"DOWNLOAD_BINARY", filename, base64,
        mime:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
      },resolve));
      if(result?.ok) return result;
    }
    // Fallback for unusually large files.
    const blob=new Blob([bytes],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});
    const url=URL.createObjectURL(blob);
    const a=document.createElement("a"); a.href=url; a.download=filename; a.style.display="none";
    document.documentElement.appendChild(a); a.click(); a.remove();
    setTimeout(()=>URL.revokeObjectURL(url),5000);
    return {ok:true,fallback:true};
  }

  async function run(opts) {
    stopRequested=false;
    const pageSize = Math.max(1, Number(opts.pageSize || 50));
    const maxPages = Math.max(0, Number(opts.maxPages || 0));
    const retry = Math.max(1, Number(opts.retry || 3));
    const tenantId = Number(opts.tenantId || 154);
    const requested = new Set(String(opts.caseFilter||"").split(/[,;\s]+/).map(clean).filter(Boolean));

    const cases = new Map(), users=[], contacts=[], summary=[], raw=[];
    let page=1, totalPages=null;

    emit("SCRAPER_STATUS",{level:"info",message:"Mengambil data Case..."});

    while (!stopRequested && (!maxPages || page<=maxPages)) {
      const {status,data} = await request(ENDPOINTS.cases,
        {page,pageSize,scene:"collector_case_detail",tenantId},
        `CASE PAGE ${page}`, retry);
      raw.push({type:"case",page,status,response:data});
      const {records,meta} = recordsFrom(data);
      for (const obj of records) {
        if (!obj || typeof obj!=="object") continue;
        const id=clean(obj.id ?? obj.caseId ?? obj.case_id);
        if (id) cases.set(id,obj);
      }
      const possible = ["totalPages","pageCount","totalPage","pages","total"];
      totalPages = null;
      for (const k of possible) {
        const v=meta?.[k];
        if (Number.isFinite(Number(v)) && Number(v)>0) { totalPages=Number(v); break; }
      }
      emit("SCRAPER_PROGRESS",{phase:"CASE",page,records:records.length,total:cases.size,totalPages});
      if (!records.length || (totalPages && page>=totalPages)) break;
      page++;
      await new Promise(r=>setTimeout(r,150));
    }

    let caseItems=[...cases.entries()];
    if (requested.size) caseItems=[...requested].sort().map(id=>[id,cases.get(id)||{id}]);

    for (let i=0;i<caseItems.length && !stopRequested;i++) {
      const [caseId,obj]=caseItems[i];
      const cid=/^\d+$/.test(caseId) ? Number(caseId) : caseId;
      let userStatus="BERHASIL", contactStatus="BERHASIL", contactCount=0;

      try {
        const {status,data}=await request(ENDPOINTS.user,{caseId:cid},`USER INFO ${caseId}`,retry);
        raw.push({type:"user_info",caseId,status,response:data});
        const info=extractDataPayload(data);
        const recs=recordsFrom(info).records;
        if (recs.length) {
          for (const rec of recs) users.push(normalizeUserRecord(rec,caseId,obj));
        } else {
          users.push(normalizeUserRecord(info,caseId,obj));
        }
      } catch(e) {
        userStatus="ERROR"; raw.push({type:"user_info",caseId,error:String(e)});
      }

      try {
        const {status,data}=await request(ENDPOINTS.contacts,{myselfLabel:"all",caseId:cid},`CONTACT ${caseId}`,retry);
        const arr=recordsFrom(data).records;
        raw.push({type:"contact",caseId,status,response:data});
        const seen=new Set();
        for (const original of arr) {
          if (!original || typeof original!=="object") continue;
          const c=normalizeContactRecord(original,caseId,obj);
          const masked=clean(c.contactPhone);
          const caseCode=clean(c.caseCode ?? obj?.caseCode ?? obj?.case_code);
          const phoneType=clean(c.phoneType ?? c.contactPhoneType ?? c.contactType ?? "MYSELF");
          const relationship=clean(c.relationship ?? c.relationshipCode ?? c.relation ?? "R01");
          const phoneId=(phoneType==="USER_CONTACT") ? (c.phoneId ?? c.id) : null;
          const completePayload={phoneType,caseId:cid,caseCode,reason:clean(c.reason||"other"),contactPhone:masked,relationship};
          if (phoneId!=null && String(phoneId).trim()) completePayload.phoneId=phoneId;
          const maskedFlag=Boolean(masked && (/[*]/.test(masked) || /x/i.test(masked)));
          if (maskedFlag && (phoneType!=="USER_CONTACT" || phoneId!=null)) {
            try {
              const {status:ps,data:pdata}=await request(ENDPOINTS.completePhone,completePayload,`COMPLETE PHONE ${caseId}`,retry);
              const full=clean(pick(pdata,["data","phone","phoneNumber","contactPhone","mobileNumber"],""));
              if (full) { c.contactPhoneComplete=full; c.contactPhoneFull=full; c.contactPhone=full; c.phoneMasked=masked; }
              else { c.contactPhoneComplete=""; c.contactPhoneFull=""; c.phoneMasked=masked; }
              raw.push({type:"complete_phone",caseId,phoneType,status:ps,request:completePayload,response:pdata});
            } catch(e) {
              c.contactPhoneComplete=""; c.contactPhoneFull=""; c.phoneMasked=masked;
              raw.push({type:"complete_phone",caseId,phoneType,error:String(e),request:completePayload});
            }
          } else if (masked) {
            c.contactPhoneComplete=masked; c.contactPhoneFull=masked; c.phoneMasked=masked;
          }
          const key=[clean(c.caseId??caseId),clean(c.contactPhone),clean(c.phoneId),clean(c.contactType)].join("|");
          if (seen.has(key)) continue;
          seen.add(key); contacts.push(c); contactCount++;
        }
      } catch(e) {
        contactStatus="ERROR"; raw.push({type:"contact",caseId,error:String(e)});
      }

      // Match desktop Excel SUMMARY behavior: contact processing determines
    // the exported status; a User Info failure alone does not change it.
    summary.push({
      caseId,
      status: contactStatus==="ERROR" ? "ERROR" : (contactStatus==="GAGAL" ? "GAGAL" : "BERHASIL"),
      contactCount
    });
      emit("SCRAPER_PROGRESS",{phase:"CASE_DETAIL",index:i+1,total:caseItems.length,caseId,users:users.length,contacts:contacts.length});
    }

    const s=stamp();
    const folder=`bantusaku_${s}`;
    const requestedCount=requested.size;
    const missingRequested=[...requested].filter(id=>!cases.has(id));
    const successfulUsers=caseItems.filter(([id])=>users.some(u=>clean(u.caseId)===clean(id))).length;
    const successfulContacts=caseItems.filter(([id])=>summary.find(x=>clean(x.caseId)===clean(id) && x.status==="BERHASIL")).length;
    const auditStatus=stopRequested ? "STOPPED" : (missingRequested.length || successfulUsers<caseItems.length ? "PARTIAL" : "COMPLETE");

    // Build the same multi-sheet structure as the supplied Excel template.
    const caseRows = [CASE_COLUMNS, ...caseItems.map(([id,o]) => {
      const flat=flatten(o); flat._case_id=id; return rowFrom(flat,CASE_COLUMNS);
    })];

    // Match the supplied workbook template exactly for EC & CH.
    // Nama CH comes from DATA NASABAH; DPD and Ammount come from Sheet.
    const caseById = new Map();
    for (const [id,o] of caseItems) {
      const flat=flatten(o);
      caseById.set(clean(id), flat);
    }

    // Build the Case ID -> User Info lookup BEFORE EC & CH uses it.
    // This fixes the JavaScript temporal-dead-zone error:
    // "Cannot access 'userByCase' before initialization".
    const userByCase = new Map();
    for (const u of users) {
      const cid = clean(u.caseId);
      if (cid && !userByCase.has(cid)) userByCase.set(cid, u);
    }

    const contactRows = [CONTACT_COLUMNS, ...contacts.map(c=>{
      const cid=clean(c.caseId);
      const co=caseById.get(cid)||{};
      const u=userByCase.get(cid)||{};
      return [
        c.caseId ?? "",
        c.contactName ?? "",
        c.contactPhone ?? "",
        c.contactType ?? "",
        u["identity.userName"] ?? u.userName ?? "",
        co.overdue_days ?? "",
        co.outstanding_amount ?? ""
      ];
    })];

    // IMPORTANT: DATA NASABAH in the desktop program is one row per Case ID.
    // The scraper may collect multiple User Info records internally, but the
    // Excel export uses only the first record for each case. Keep that exact
    // export behavior here; the raw User Info sheet remains the audit source.
    const userRows = [USER_COLUMNS,
      ...caseItems.map(([id]) => rowFrom(userByCase.get(clean(id)) || {}, USER_COLUMNS))
    ];

    const nameByCase = new Map();
    for (const [cid,u] of userByCase.entries()) {
      const nm=clean(u["identity.userName"] ?? u.userName);
      if(cid && nm && !nameByCase.has(cid)) nameByCase.set(cid,nm);
    }
    // Emergency Contact follows the supplied template: 7 columns.
    // EMERGENCY CONTACT hanya berisi kontak selain MYSELF / peminjam sendiri.
    // EC & CH tetap mempertahankan seluruh hasil kontak seperti sebelumnya.
    const emergencyRows = [["caseId","contactName","contactPhone","contactType","Nama CH","DPD","Ammount"],
      ...contacts.filter(c => {
        const type = clean(c.phoneType ?? c.contactPhoneType ?? c.contactType).toUpperCase();
        const relation = clean(c.relationship ?? c.relationshipCode ?? c.relation).toUpperCase();
        return type !== "MYSELF" && type !== "USER" && relation !== "MYSELF";
      }).map(c=>{
        const cid=clean(c.caseId);
        const co=caseById.get(cid)||{};
        return [
          c.caseId ?? "",
          c.contactName ?? "",
          c.contactPhone ?? "",
          c.contactType ?? "",
          nameByCase.get(cid) || "",
          co.overdue_days ?? "",
          co.outstanding_amount ?? ""
        ];
      })
    ];

    const summaryRows = [["Case ID","Status","Jumlah Kontak","Keterangan"],
      ...summary.map(x=>[x.caseId,x.status,x.contactCount,x.keterangan||""])
    ];

    const rawUserByCase = new Map();
    const rawContact = [];
    const rawCase = [];
    for (const x of raw) {
      if (x.type==="user_info" && x.caseId!=null && x.response!==undefined) rawUserByCase.set(String(x.caseId),x.response);
      if (x.type==="contact" && x.caseId!=null && x.response!==undefined) rawContact.push([x.caseId,JSON.stringify(x.response)]);
      if (x.type==="case") rawCase.push([x.page,x.status,JSON.stringify(x.response)]);
    }
    const rawUserRows=[["Case ID","JSON User Info Lengkap"],
      ...caseItems.map(([id])=>[id,rawUserByCase.has(String(id))?JSON.stringify(rawUserByCase.get(String(id))):""])
    ];
    const rawContactRows=[["Case ID","JSON Contact Lengkap"],...rawContact];
    const rawCaseRows=[["Page","HTTP Status","JSON Response Lengkap"],...rawCase];

    const widths = {
      case:[14,13,13,13,22,26,14,13,16,14,14,14,18,14,20,16,18,20,14,22,30,16,14,14,16,20,22,16],
      contact:[11.14,17.29,17.86,16.29,38.71,12,18],
      user:[14,20,15,26,24,25,24,21,24,18,18,22,30,18,22,20,22,14,120],
      emergency:[11.14,17.29,17.86,16.29,38.71,12,18],
      summary:[14,16,15,30],
      raw:[18,120],
      rawCase:[12,14,120],
      info:[24,90]
    };

    const xlsxSheets=[
      {name:"Sheet",rows:caseRows,widths:widths.case},
      {name:"EC & CH",rows:contactRows,widths:widths.contact},
      {name:"DATA NASABAH",rows:userRows,widths:widths.user},
      {name:"EMERGENCY CONTACT",rows:emergencyRows,widths:widths.emergency},
      {name:"SUMMARY",rows:summaryRows,widths:widths.summary}
    ];

    await downloadXlsx(`${folder}.xlsx`,xlsxSheets);

    emit("SCRAPER_DONE",{cases:caseItems.length,users:users.length,contacts:contacts.length,stopped:stopRequested,folder,xlsx:`${folder}.xlsx`,auditStatus,missingRequested:missingRequested.length});
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse)=>{
    if (msg?.type==="START_SCRAPE") {
      run(msg.options||{}).catch(e=>emit("SCRAPER_ERROR",{message:String(e?.message||e)}));
      sendResponse({ok:true}); return true;
    }
    if (msg?.type==="STOP_SCRAPE") { stopRequested=true; sendResponse({ok:true}); }
    if (msg?.type==="PING") sendResponse({ok:true,url:location.href});
  });
})();