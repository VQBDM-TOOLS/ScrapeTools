const SITE = "https://cco-agent.bantusaku.id/";

// Keep authentication headers in memory only. They are learned from API
// requests made by the currently open, logged-in tab and are never persisted.
const authByTab = new Map();

chrome.runtime.onInstalled.addListener(async () => {
  if (chrome.sidePanel?.setPanelBehavior) {
    await chrome.sidePanel.setPanelBehavior({openPanelOnActionClick: true});
  }
});

chrome.action.onClicked.addListener(async (tab) => {
  if (chrome.sidePanel?.open && tab?.windowId) {
    try { await chrome.sidePanel.open({windowId: tab.windowId}); } catch (_) {}
  }
});

function safeFilename(name) {
  return String(name || "bantusaku-report.xlsx").replace(/[<>:"/\\|?*\x00-\x1F]/g, "_").replace(/\.+$/g, "").slice(0,180) || "bantusaku-report.xlsx";
}

function isSiteApi(url) {
  return /^https:\/\/cco-agent\.bantusaku\.id\/api\//.test(url || "");
}

function isAuthHeader(name) {
  const n = String(name || "").toLowerCase();
  return n === "authorization" ||
    n === "x-access-token" ||
    n === "x-auth-token" ||
    n === "x-csrf-token" ||
    n === "x-xsrf-token";
}

if (chrome.webRequest?.onBeforeSendHeaders) {
  chrome.webRequest.onBeforeSendHeaders.addListener(
    (details) => {
      if (details.tabId == null || details.tabId < 0 || !isSiteApi(details.url)) return;
      const headers = {};
      for (const h of (details.requestHeaders || [])) {
        if (isAuthHeader(h.name) && h.value) headers[h.name] = h.value;
      }
      if (Object.keys(headers).length) authByTab.set(details.tabId, headers);
    },
    {urls: ["https://cco-agent.bantusaku.id/api/*"]},
    ["requestHeaders", "extraHeaders"]
  );
}

chrome.tabs.onRemoved.addListener((tabId) => authByTab.delete(tabId));

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  // A navigation can invalidate the previous session/token. Do not reuse
  // headers captured from the old document.
  if (changeInfo.url || changeInfo.status === "loading") {
    authByTab.delete(tabId);
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === "GET_AUTH_HEADERS") {
    const tabId = Number(msg.tabId ?? sender.tab?.id ?? -1);
    sendResponse({ok: true, headers: authByTab.get(tabId) || {}});
    return;
  }

  if (msg?.type === "CLEAR_AUTH_HEADERS") {
    const tabId = Number(msg.tabId ?? sender.tab?.id ?? -1);
    authByTab.delete(tabId);
    sendResponse({ok: true});
    return;
  }

  if (msg?.type === "DOWNLOAD_BINARY") {
    try {
      const b64=String(msg.base64||"");
      if(!b64 || b64.length>45_000_000) throw new Error("File terlalu besar untuk downloader extension.");
      const url=`data:${String(msg.mime||"application/octet-stream")};base64,${b64}`;
      chrome.downloads.download({url,filename:safeFilename(msg.filename),saveAs:false,conflictAction:"uniquify"})
        .then(id=>sendResponse({ok:true,id})).catch(e=>sendResponse({ok:false,error:String(e)}));
    } catch(e){ sendResponse({ok:false,error:String(e)}); }
    return true;
  }

  if (msg?.type === "DOWNLOAD_TEXT") {
    const bytes = new TextEncoder().encode(msg.text || "");
    const blob = new Blob([bytes], {type: msg.mime || "text/plain"});
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const id = await chrome.downloads.download({
          url: reader.result,
          filename: msg.filename || "bantusaku-export.txt",
          saveAs: true
        });
        sendResponse({ok:true,id});
      } catch (e) { sendResponse({ok:false,error:String(e)}); }
    };
    reader.readAsDataURL(blob);
    return true;
  }

  if (msg?.type === "GET_ACTIVE_TAB") {
    chrome.tabs.query({active:true,currentWindow:true}).then(tabs => {
      sendResponse({ok:true, tab: tabs[0] || null});
    });
    return true;
  }
});
