const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, X-Owner-Token, X-Admin-Session"
};

// ============================================================
// CONFIG
// ============================================================

const VERSION = "1.0.0";
const WIB_TIMEZONE = "Asia/Jakarta";
const ADMIN_SESSION_TTL_SECONDS = 8 * 60 * 60;

// ============================================================
// LIGHTWEIGHT RATE LIMITER
// ============================================================
// In-memory per Worker isolate. Tidak membutuhkan KV/Durable Object
// dan tidak mengubah database/client. Karena Cloudflare dapat menjalankan
// beberapa isolate, ini adalah lapisan tambahan, bukan WAF pengganti.

const RATE_BUCKETS = new Map();
const RATE_WINDOW_MS = 60_000;
const RATE_MAX_BUCKETS = 5000;

function clientIP(request) {
  return String(
    request.headers.get("CF-Connecting-IP") ||
    request.headers.get("X-Forwarded-For") ||
    "unknown"
  ).split(",")[0].trim().substring(0, 64);
}

function rateLimit(request, bucket, limit) {
  const now = Date.now();
  const key = bucket + ":" + clientIP(request);
  let item = RATE_BUCKETS.get(key);

  if (!item || now - item.start >= RATE_WINDOW_MS) {
    item = { start: now, count: 0 };
  }

  item.count++;
  RATE_BUCKETS.set(key, item);

  if (RATE_BUCKETS.size > RATE_MAX_BUCKETS) {
    for (const [k, v] of RATE_BUCKETS) {
      if (now - v.start >= RATE_WINDOW_MS) RATE_BUCKETS.delete(k);
      if (RATE_BUCKETS.size <= RATE_MAX_BUCKETS) break;
    }
  }

  if (item.count > limit) {
    const retryAfter = Math.max(1, Math.ceil((RATE_WINDOW_MS - (now - item.start)) / 1000));
    return new Response(
      JSON.stringify({ ok: false, valid: false, error: "RATE_LIMITED", retry_after_seconds: retryAfter }),
      {
        status: 429,
        headers: {
          "Content-Type": "application/json; charset=utf-8",
          "Cache-Control": "no-store",
          "Retry-After": String(retryAfter),
          ...CORS
        }
      }
    );
  }

  return null;
}

function rateLimitOwner(request) {
  return rateLimit(request, "owner", 60);
}

function rateLimitValidate(request) {
  return rateLimit(request, "validate", 60);
}

function rateLimitHeartbeat(request) {
  return rateLimit(request, "heartbeat", 180);
}
function rateLimitMessageStream(request) {
  // A stream normally lives for ~25 seconds and then reconnects.
  // Keep the limit generous enough for normal reconnects while preventing
  // aggressive reconnect loops from hammering the Worker.
  return rateLimit(request, "message_stream", 30);
}

// ============================================================
// TIME HELPERS
// ============================================================

// Database menyimpan waktu dalam UTC ISO.
// Contoh:
// 2026-09-02T03:30:00.000Z

function nowISO() {
  return new Date().toISOString();
}

function addDaysISO(days, baseTime = Date.now()) {
  return new Date(
    baseTime +
    Number(days) * 86400000
  ).toISOString();
}

function formatWIB(value) {

  if (!value) {
    return "-";
  }

  try {

    const date =
      new Date(value);

    if (
      Number.isNaN(
        date.getTime()
      )
    ) {
      return "-";
    }

    return new Intl.DateTimeFormat(
      "id-ID",
      {
        timeZone:
          WIB_TIMEZONE,

        day:
          "2-digit",

        month:
          "2-digit",

        year:
          "numeric",

        hour:
          "2-digit",

        minute:
          "2-digit",

        second:
          "2-digit",

        hour12:
          false
      }
    ).format(date) +
    " WIB";

  } catch {

    return "-";

  }
}

function isExpired(expiresAt) {

  if (!expiresAt) {
    return true;
  }

  const time =
    new Date(
      expiresAt
    ).getTime();

  if (
    !Number.isFinite(time)
  ) {
    return true;
  }

  return (
    time <= Date.now()
  );
}

// ============================================================
// RESPONSE HELPERS
// ============================================================

function json(
  data,
  status = 200
) {

  return new Response(
    JSON.stringify(data),
    {
      status,

      headers: {
        "Content-Type":
          "application/json; charset=utf-8",

        "Cache-Control": "no-store, no-cache, must-revalidate",
        "Pragma": "no-cache",

        ...CORS
      }
    }
  );

}

function html(body) {

  return new Response(
    body,
    {
      status: 200,

      headers: {
        "Content-Type":
          "text/html; charset=utf-8",

        ...CORS
      }
    }
  );

}

function normalize(value) {

  return String(
    value || ""
  )
    .trim()
    .toUpperCase();

}

async function getAdminSession(request, env) {
  const cookie = request.headers.get("Cookie") || "";
  const match = cookie.match(/(?:^|;\s*)bsk_admin_session=([^;]+)/);
  if (!match) return null;

  try {
    const secret = String(env.ADMIN_SESSION_SECRET || env.OWNER_TOKEN || "");
    if (!secret) return null;

    const [payloadB64, sigB64] = decodeURIComponent(match[1]).split(".");
    if (!payloadB64 || !sigB64) return null;

    const payloadText = atob(payloadB64.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((payloadB64.length + 3) % 4));
    const payload = JSON.parse(payloadText);
    if (!payload.exp || Number(payload.exp) <= Math.floor(Date.now() / 1000)) return null;
    if (!payload.username) return null;

    const key = await crypto.subtle.importKey(
      "raw",
      new TextEncoder().encode(secret),
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["verify"]
    );

    const data = new TextEncoder().encode(payloadB64);
    const sig = Uint8Array.from(
      atob(sigB64.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((sigB64.length + 3) % 4)),
      c => c.charCodeAt(0)
    );
    const validSignature = await crypto.subtle.verify("HMAC", key, sig, data);
    if (!validSignature) return null;

    if (env.DB) {
      const admin = await env.DB.prepare(
        `SELECT id, username, role, active FROM admin_users WHERE username = ? AND active = 1 LIMIT 1`
      ).bind(String(payload.username)).first();
      if (!admin) return null;
      return { ...payload, id: admin.id, username: admin.username, role: admin.role };
    }

    return payload;
  } catch {
    return null;
  }
}

async function ownerAuth(request, env) {
  const token = request.headers.get("X-Owner-Token");
  return !!(token && env.OWNER_TOKEN && token === env.OWNER_TOKEN);
}

async function adminAuth(request, env) {
  return !!(await getAdminSession(request, env));
}

async function ownerTokenAuth(request, env) {
  const token = request.headers.get("X-Owner-Token");
  return !!(token && env.OWNER_TOKEN && token === env.OWNER_TOKEN);
}

function base64url(bytes) {
  let binary = "";
  for (const b of bytes) binary += String.fromCharCode(b);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

function base64urlText(text) {
  return base64url(new TextEncoder().encode(text));
}

async function signAdminSession(username, role, env) {
  const secret = String(env.ADMIN_SESSION_SECRET || env.OWNER_TOKEN || "");
  if (!secret) throw new Error("ADMIN_SESSION_SECRET belum dikonfigurasi");

  const payload = {
    username,
    role: role || "admin",
    exp: Math.floor(Date.now() / 1000) + ADMIN_SESSION_TTL_SECONDS
  };
  const payloadB64 = base64urlText(JSON.stringify(payload));
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sig = new Uint8Array(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(payloadB64)));
  return payloadB64 + "." + base64url(sig);
}

async function hashAdminPassword(password) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const baseKey = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", salt, iterations: 100000, hash: "SHA-256" },
    baseKey,
    256
  );
  return "pbkdf2$100000$" + base64url(salt) + "$" + base64url(new Uint8Array(bits));
}

async function verifyAdminPassword(password, stored) {
  try {
    const parts = String(stored || "").split("$");
    if (parts.length !== 4 || parts[0] !== "pbkdf2") return false;
    const iterations = Number(parts[1]);
    const saltB64 = parts[2].replace(/-/g, "+").replace(/_/g, "/");
    const hashB64 = parts[3].replace(/-/g, "+").replace(/_/g, "/");
    if (!Number.isInteger(iterations) || iterations < 10000 || iterations > 10000000) return false;

    const salt = Uint8Array.from(atob(saltB64 + "===".slice((saltB64.length + 3) % 4)), c => c.charCodeAt(0));
    const expected = Uint8Array.from(atob(hashB64 + "===".slice((hashB64.length + 3) % 4)), c => c.charCodeAt(0));
    const baseKey = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
    const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", salt, iterations, hash: "SHA-256" }, baseKey, expected.length * 8);
    const actual = new Uint8Array(bits);
    if (actual.length !== expected.length) return false;
    let diff = 0;
    for (let i = 0; i < actual.length; i++) diff |= actual[i] ^ expected[i];
    return diff === 0;
  } catch {
    return false;
  }
}

let adminSchemaPromise = null;
async function ensureAdminSchema(env) {
  if (!env.DB) throw new Error("DB belum dikonfigurasi");
  if (!adminSchemaPromise) {
    adminSchemaPromise = (async () => {
      await env.DB.prepare(`
        CREATE TABLE IF NOT EXISTS admin_users (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          username TEXT NOT NULL UNIQUE,
          password_hash TEXT NOT NULL,
          role TEXT NOT NULL DEFAULT 'admin',
          active INTEGER NOT NULL DEFAULT 1,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        )
      `).run();
      await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_admin_users_username ON admin_users(username)`).run();
    })().catch(error => {
      adminSchemaPromise = null;
      throw error;
    });
  }
  await adminSchemaPromise;
}

function sessionCookie(token, maxAge = ADMIN_SESSION_TTL_SECONDS) {
  return `bsk_admin_session=${encodeURIComponent(token)}; Max-Age=${maxAge}; Path=/; HttpOnly; Secure; SameSite=Lax`;
}

// ============================================================
// LICENSE GENERATOR
// ============================================================

function generateLicense() {

  const chars =
    "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

  function part() {

    const bytes =
      crypto.getRandomValues(
        new Uint8Array(5)
      );

    return [...bytes]
      .map(
        b =>
          chars[
            b % chars.length
          ]
      )
      .join("");

  }

  return (
    "BSK-" +
    part() +
    "-" +
    part() +
    "-" +
    part() +
    "-" +
    part()
  );

}

// ============================================================
// OWNER PANEL
// ============================================================

const OWNER_HTML = `
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Tools License Owner</title>
<style>
:root{
  --bg:#f4f7fb;--surface:#fff;--surface-2:#f8fafc;--border:#e5e7eb;--text:#0f172a;--muted:#64748b;
  --navy:#0b1220;--primary:#2563eb;--primary-2:#1d4ed8;--success:#16a34a;--danger:#dc2626;--warning:#d97706;
  --shadow:0 14px 45px rgba(15,23,42,.08);--radius:18px
}
*{box-sizing:border-box}
html{scroll-behavior:smooth}
body{margin:0;background:radial-gradient(circle at top right,rgba(37,99,235,.08),transparent 28%),var(--bg);color:var(--text);font-family:Aptos,"Segoe UI Variable","Segoe UI",system-ui,-apple-system,BlinkMacSystemFont,Arial,sans-serif}
button,input,select{font:inherit}
button{border:0;cursor:pointer}
button:disabled{opacity:.55;cursor:not-allowed}
a{text-decoration:none;color:inherit}
.owner-page{max-width:1600px;margin:0 auto;padding:24px}
.auth-card{max-width:720px;margin:8vh auto 0;background:rgba(255,255,255,.95);border:1px solid var(--border);border-radius:24px;box-shadow:var(--shadow);padding:32px}
.auth-brand{display:flex;align-items:center;gap:14px;margin-bottom:22px}
.brand-mark{width:48px;height:48px;border-radius:15px;background:linear-gradient(135deg,#0f172a,#334155);color:#fff;display:grid;place-items:center;font-size:24px;box-shadow:0 10px 22px rgba(15,23,42,.18)}
.eyebrow{font-size:12px;font-weight:800;letter-spacing:.12em;text-transform:uppercase;color:var(--primary)}
.auth-card h1{margin:4px 0 8px;font-size:28px}
.auth-card p{margin:0;color:var(--muted)}
.field{display:flex;flex-direction:column;gap:7px}
.field label{font-size:12px;font-weight:800;color:#334155}
.field input,.field select,.search-input,.toolbar-select{width:100%;border:1px solid #d7dee9;background:#fff;color:var(--text);border-radius:12px;padding:12px 13px;outline:none;transition:.15s}
.field input:focus,.field select:focus,.search-input:focus,.toolbar-select:focus{border-color:#93c5fd;box-shadow:0 0 0 4px rgba(37,99,235,.1)}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:10px 14px;border-radius:11px;font-weight:800;transition:.15s}
.btn:hover{transform:translateY(-1px)}
.btn-primary{background:var(--primary);color:#fff}.btn-primary:hover{background:var(--primary-2)}
.btn-soft{background:#eef2ff;color:#1e3a8a}.btn-neutral{background:#e2e8f0;color:#0f172a}.btn-danger{background:#fee2e2;color:#991b1b}.btn-success{background:#dcfce7;color:#166534}.btn-warning{background:#fef3c7;color:#92400e}.btn-dark{background:#0f172a;color:#fff}
.hint{font-size:12px;color:var(--muted);line-height:1.6}
.header-bar{display:flex;align-items:center;justify-content:space-between;gap:16px;margin-bottom:18px}
.header-title{display:flex;align-items:center;gap:14px}.header-title h1{margin:0;font-size:24px}.header-title p{margin:4px 0 0;color:var(--muted);font-size:13px}
.status-pill{display:inline-flex;align-items:center;gap:7px;padding:7px 10px;border-radius:999px;background:#ecfdf5;color:#166534;font-size:12px;font-weight:800}
.dot{width:8px;height:8px;border-radius:50%;background:#22c55e;box-shadow:0 0 0 4px rgba(34,197,94,.15)}
.server-clock{padding:9px 12px;border:1px solid var(--border);border-radius:10px;background:#fff;font-size:12px;color:#475569}
.shell{display:grid;grid-template-columns:250px minmax(0,1fr);gap:18px;align-items:start}
.sidebar{position:sticky;top:18px;background:linear-gradient(180deg,#0f172a,#111827 70%,#0b1220);color:#e5e7eb;border-radius:22px;padding:16px;box-shadow:var(--shadow)}
.side-brand{padding:8px 10px 16px;border-bottom:1px solid rgba(255,255,255,.1);margin-bottom:12px}
.side-brand strong{display:block;color:#fff;font-size:15px}.side-brand span{display:block;color:#94a3b8;font-size:11px;margin-top:4px}
.nav-btn{width:100%;display:flex;align-items:center;gap:10px;text-align:left;background:transparent;color:#cbd5e1;padding:11px 12px;border-radius:11px;font-weight:800;margin:3px 0}
.nav-btn:hover{background:rgba(255,255,255,.06);color:#fff}
.nav-btn.active{background:linear-gradient(135deg,#2563eb,#1d4ed8);color:#fff;box-shadow:0 10px 22px rgba(37,99,235,.28)}
.sidebar-footer{border-top:1px solid rgba(255,255,255,.1);margin-top:14px;padding:14px 10px 4px;color:#94a3b8;font-size:11px;line-height:1.6}
.main{min-width:0}
.section{display:none}.section.active{display:block}
.hero{background:linear-gradient(135deg,#0f172a,#1e293b 62%,#334155);color:#fff;border-radius:22px;padding:24px;box-shadow:var(--shadow);margin-bottom:18px}
.hero-top{display:flex;justify-content:space-between;align-items:flex-start;gap:15px}.hero h2{margin:0;font-size:22px}.hero p{margin:7px 0 0;color:#cbd5e1;font-size:13px;max-width:720px}
.hero-actions{display:flex;gap:8px;flex-wrap:wrap}
.kpis{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:12px;margin-bottom:18px}
.kpi{background:#fff;border:1px solid var(--border);border-radius:16px;padding:16px;box-shadow:0 8px 24px rgba(15,23,42,.05)}
.kpi .label{font-size:11px;color:var(--muted);font-weight:800;text-transform:uppercase;letter-spacing:.05em}.kpi .value{font-size:26px;font-weight:900;margin-top:7px}.kpi .meta{font-size:11px;color:var(--muted);margin-top:4px}
.grid-2{display:grid;grid-template-columns:1.25fr .75fr;gap:16px}
.card{background:var(--surface);border:1px solid var(--border);border-radius:18px;padding:18px;box-shadow:0 8px 28px rgba(15,23,42,.05);margin-bottom:16px}
.card-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:14px}.card-head h3{margin:0;font-size:16px}.card-head p{margin:4px 0 0;font-size:12px;color:var(--muted)}
.progress{height:10px;background:#e2e8f0;border-radius:999px;overflow:hidden}.progress>span{display:block;height:100%;border-radius:999px;background:linear-gradient(90deg,#2563eb,#60a5fa)}
.health-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:10px}.health-item{border:1px solid var(--border);border-radius:12px;padding:12px;background:var(--surface-2)}.health-item strong{display:block;font-size:18px}.health-item span{font-size:11px;color:var(--muted)}
.activity-item{display:flex;gap:10px;padding:10px 0;border-bottom:1px solid var(--border)}.activity-item:last-child{border-bottom:0}.activity-icon{width:34px;height:34px;border-radius:10px;background:#eff6ff;color:#1d4ed8;display:grid;place-items:center;flex:0 0 auto}.activity-body{min-width:0}.activity-body strong{font-size:12px}.activity-body div{font-size:11px;color:var(--muted);margin-top:2px;line-height:1.5}
.toolbar{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:12px}.toolbar .search-wrap{flex:1 1 280px;position:relative}.search-input{padding-left:38px}.search-icon{position:absolute;left:13px;top:50%;transform:translateY(-50%);font-size:14px;color:#94a3b8}
.toolbar-select{width:auto;min-width:145px}.table-wrap{overflow-x:auto;overflow-y:hidden;max-width:100%;border:1px solid var(--border);border-radius:14px}
table{width:100%;border-collapse:separate;border-spacing:0;min-width:1080px;font-size:12px}
th,td{padding:12px 10px;border-bottom:1px solid var(--border);text-align:left;vertical-align:top;background:#fff}
th{background:#f8fafc;color:#475569;font-size:10px;text-transform:uppercase;letter-spacing:.06em;font-weight:900;position:sticky;top:0;z-index:1}
tbody tr:hover td{background:#fbfdff} tbody tr:last-child td{border-bottom:0}
.check{width:16px;height:16px}
.mono{font-family:"SFMono-Regular",Consolas,"Liberation Mono",monospace}
.badge{display:inline-flex;align-items:center;padding:5px 8px;border-radius:999px;font-size:10px;font-weight:900;white-space:nowrap}
.badge-active{background:#dcfce7;color:#166534}.badge-expired{background:#fef3c7;color:#92400e}.badge-banned{background:#fee2e2;color:#991b1b}.badge-neutral{background:#e2e8f0;color:#334155}
.presence{display:inline-flex;align-items:center;gap:5px;padding:4px 7px;border-radius:999px;font-size:10px;font-weight:900;white-space:nowrap}.presence-online{background:#dcfce7;color:#166534}.presence-idle{background:#fef3c7;color:#92400e}.presence-offline{background:#fee2e2;color:#991b1b}.presence-never{background:#e2e8f0;color:#475569}
.row-actions{display:flex;gap:5px;flex-wrap:wrap;min-width:280px}.row-actions .btn{padding:7px 9px;font-size:10px}
.selection-bar{display:none;align-items:center;justify-content:space-between;gap:10px;background:#eff6ff;border:1px solid #bfdbfe;color:#1e3a8a;border-radius:12px;padding:10px 12px;margin-bottom:10px}.selection-bar.show{display:flex}
.create-grid{display:grid;grid-template-columns:2fr 1fr 1fr;gap:10px}.form-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px}
.license-result{display:none;margin-top:12px;padding:13px;background:#eff6ff;border:1px solid #bfdbfe;border-radius:12px}.license-key{font:900 18px "SFMono-Regular",Consolas,monospace;letter-spacing:.7px;word-break:break-all;margin-top:6px}
.summary-line{display:flex;gap:10px;flex-wrap:wrap}.summary-chip{padding:8px 10px;border:1px solid var(--border);border-radius:10px;background:#fff;font-size:11px}.summary-chip strong{font-size:14px}
.admin-grid{display:grid;grid-template-columns:1.2fr 1fr .7fr auto;gap:10px;align-items:end}.admin-status{display:inline-flex;align-items:center;gap:6px;padding:6px 8px;border-radius:999px;font-size:10px;font-weight:900}.admin-on{background:#dcfce7;color:#166534}.admin-off{background:#e2e8f0;color:#475569}
.audit-filters{display:flex;gap:8px;flex-wrap:wrap}.audit-filter{min-width:150px}
.msg{display:none;margin-bottom:16px;padding:12px 14px;border-radius:12px;font-size:12px;font-weight:800}.msg-success{display:block;background:#dcfce7;color:#166534}.msg-error{display:block;background:#fee2e2;color:#991b1b}
.toast{position:fixed;right:22px;bottom:22px;z-index:50;max-width:360px;display:none;padding:12px 14px;border-radius:12px;background:#0f172a;color:#fff;box-shadow:0 15px 35px rgba(15,23,42,.25);font-size:12px;font-weight:800}.toast.show{display:block;animation:toastIn .18s ease}.muted{color:var(--muted)}.small{font-size:11px;color:var(--muted)}
.empty{padding:30px;text-align:center;color:var(--muted)}
@keyframes toastIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
@media(max-width:1250px){.kpis{grid-template-columns:repeat(3,1fr)}.shell{grid-template-columns:210px minmax(0,1fr)}}
@media(max-width:950px){.shell{grid-template-columns:1fr}.sidebar{position:static}.nav-row{display:grid;grid-template-columns:repeat(4,1fr);gap:6px}.nav-btn{justify-content:center;text-align:center}.side-brand,.sidebar-footer{display:none}.grid-2{grid-template-columns:1fr}.create-grid,.admin-grid{grid-template-columns:1fr}.hero-top{flex-direction:column}}
@media(max-width:620px){.owner-page{padding:12px}.auth-card{padding:22px}.kpis{grid-template-columns:repeat(2,1fr)}.nav-row{grid-template-columns:repeat(2,1fr)}.header-bar{align-items:flex-start;flex-direction:column}}

/* V4.3.9 typography refresh */
h1,h2,h3,h4,h5,h6{font-family:"Aptos Display",Aptos,"Segoe UI Variable","Segoe UI",Arial,sans-serif;letter-spacing:-.012em}
button,input,select,textarea{font-family:Aptos,"Segoe UI Variable","Segoe UI",system-ui,-apple-system,BlinkMacSystemFont,Arial,sans-serif}
label,.label,.eyebrow,.badge,.status-pill,.nav-btn,.btn{letter-spacing:.005em}
.small,.hint,.muted,.meta,p{letter-spacing:.002em}
textarea{width:100%;resize:vertical;min-height:110px;font:inherit;padding:11px 13px;border:1px solid #dbe3ef;border-radius:12px;background:#fff;color:#172033;outline:none}textarea:focus{border-color:#8fb4ff;box-shadow:0 0 0 3px rgba(59,130,246,.10)}
</style>
</head>
<body>
<div class="owner-page" id="ownerApp">
  <div id="message" class="msg"></div>

  <section class="auth-card" id="authCard">
    <div class="auth-brand">
      <div class="brand-mark">👑</div>
      <div>
        <div class="eyebrow">Owner Control Center</div>
        <h1>Tools License Manager</h1>
        <p>Panel Owner.</p>
      </div>
    </div>
    <div class="field">
      <label>Token Login</label>
      <input id="token" type="password" autocomplete="off" placeholder="Masukkan OWNER_TOKEN">
    </div>
    <div class="form-actions">
      <button class="btn btn-dark" onclick="connectOwner()">🔐 Connect Owner</button>
      <button class="btn btn-neutral" onclick="clearToken()">Reset</button>
    </div>
    <p class="hint" style="margin-top:12px">Extension Tools.</p>
  </section>

  <div id="workspace" style="display:none">
    <div class="header-bar">
      <div class="header-title">
        <div class="brand-mark">👑</div>
        <div>
          <h1>Tools License Owner</h1>
          <p>Owner Control Center · Version ${VERSION}</p>
        </div>
      </div>
      <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
        <span class="status-pill"><span class="dot"></span> Owner Connected</span>
        <span class="server-clock" id="serverClock">🕐 Server WIB: memuat...</span>
      </div>
    </div>

    <div class="shell">
      <aside class="sidebar">
        <div class="side-brand">
          <strong>OWNER CONTROL</strong>
          <span>Operational workspace</span>
        </div>
        <div class="nav-row">
          <button class="nav-btn active" data-tab="overview" onclick="showTab('overview',this)">📊 <span>Overview</span></button>
          <button class="nav-btn" data-tab="licenses" onclick="showTab('licenses',this)">🔑 <span>Licenses</span></button>
          <button class="nav-btn" data-tab="admins" onclick="showTab('admins',this)">👥 <span>Admins</span></button>
          <button class="nav-btn" data-tab="audit" onclick="showTab('audit',this)">🧾 <span>Audit</span></button>
          <button class="nav-btn" data-tab="messages" onclick="showTab('messages',this)">📢 <span>Pesan Client</span></button>
        </div>
        <div class="sidebar-footer">
          <div id="syncInfo">Belum sinkron.</div>
          <div style="margin-top:8px">HATI HATI ADA ORANG PUYENG.</div>
        </div>
      </aside>

      <main class="main">
        <section class="section active" id="tab-overview">
          <div class="hero">
            <div class="hero-top">
              <div>
                <h2>Operational Overview</h2>
                <p>Ringkasan kondisi license dan aktivitas sistem secara real-time berdasarkan data server.</p>
              </div>
              <div class="hero-actions">
                <button class="btn btn-primary" onclick="showTab('licenses',document.querySelector('[data-tab=licenses]'))">➕ Kelola License</button>
                <button class="btn btn-neutral" onclick="refreshAll()">↻ Refresh Data</button>
              </div>
            </div>
          </div>

          <div class="kpis">
            <div class="kpi"><div class="label">Total License</div><div class="value" id="kpiTotal">0</div><div class="meta">Semua record license</div></div>
            <div class="kpi"><div class="label">Active</div><div class="value" id="kpiActive">0</div><div class="meta">License aktif</div></div>
            <div class="kpi"><div class="label">Expired</div><div class="value" id="kpiExpired">0</div><div class="meta">Masa aktif berakhir</div></div>
            <div class="kpi"><div class="label">Banned</div><div class="value" id="kpiBanned">0</div><div class="meta">Dibatasi Owner</div></div>
            <div class="kpi"><div class="label">Unactivated</div><div class="value" id="kpiUnactivated">0</div><div class="meta">Belum terikat device</div></div>
            <div class="kpi"><div class="label">Online</div><div class="value" id="kpiOnline">0</div><div class="meta">Aktivitas ≤ 90 detik</div></div>
          </div>

          <div class="grid-2">
            <div class="card">
              <div class="card-head"><div><h3>License Health</h3><p>Komposisi license berdasarkan status.</p></div><div id="healthRate" class="badge badge-neutral">0% active</div></div>
              <div class="progress"><span id="healthProgress" style="width:0%"></span></div>
              <div class="health-grid" style="margin-top:12px">
                <div class="health-item"><strong id="healthActive">0</strong><span>Active</span></div>
                <div class="health-item"><strong id="healthExpired">0</strong><span>Expired</span></div>
                <div class="health-item"><strong id="healthBanned">0</strong><span>Banned</span></div>
                <div class="health-item"><strong id="healthUnactivated">0</strong><span>Unactivated</span></div>
              </div>
            </div>
            <div class="card">
              <div class="card-head"><div><h3>Admin Coverage</h3><p>Ringkasan akun pengelola.</p></div></div>
              <div class="summary-line">
                <div class="summary-chip"><span>Total</span><br><strong id="adminTotal">0</strong></div>
                <div class="summary-chip"><span>Aktif</span><br><strong id="adminActive">0</strong></div>
                <div class="summary-chip"><span>Viewer</span><br><strong id="adminViewer">0</strong></div>
                <div class="summary-chip"><span>Admin</span><br><strong id="adminRoleCount">0</strong></div>
              </div>
              <div style="margin-top:14px">
                <button class="btn btn-soft" onclick="showTab('admins',document.querySelector('[data-tab=admins]'))">👥 Kelola Admin</button>
              </div>
            </div>
          </div>

          <div class="card">
            <div class="card-head"><div><h3>Recent Owner Activity</h3><p>Perubahan terbaru dari Owner dan Admin.</p></div><button class="btn btn-neutral" onclick="showTab('audit',document.querySelector('[data-tab=audit]'))">Lihat Semua</button></div>
            <div id="recentActivity"><div class="empty">Belum ada data.</div></div>
          </div>
        </section>

        <section class="section" id="tab-licenses">
          <div class="card">
            <div class="card-head">
              <div><h3>Create License</h3><p>Buat license baru dengan masa aktif yang terkontrol.</p></div>
            </div>
            <div class="create-grid">
              <div class="field"><label>Nama Customer</label><input id="customer" placeholder="Contoh: Budi"></div>
              <div class="field"><label>Masa Aktif (hari)</label><input id="days" type="number" value="30" min="1" max="3650"></div>
              <div class="field"><label>Preset</label><select id="preset" onchange="applyPreset()"><option value="30">30 hari</option><option value="90">90 hari</option><option value="180">180 hari</option><option value="365">1 tahun</option><option value="0">Custom</option></select></div>
            </div>
            <div class="form-actions">
              <button class="btn btn-primary" onclick="createLicense()">＋ CREATE LICENSE</button>
              <button class="btn btn-neutral" onclick="clearCreateForm()">Bersihkan</button>
            </div>
            <div id="licenseResult" class="license-result">
              <div class="small">License berhasil dibuat</div>
              <div id="newLicense" class="license-key"></div>
              <div class="form-actions">
                <button class="btn btn-soft" onclick="copyLicense()">📋 Copy License</button>
                <button class="btn btn-neutral" onclick="document.getElementById('licenseResult').style.display='none'">Tutup</button>
              </div>
            </div>
          </div>

          <div class="card">
            <div class="card-head">
              <div><h3>License Registry</h3><p>Kelola seluruh license tanpa nested vertical scroll.</p></div>
              <div style="display:flex;gap:8px;flex-wrap:wrap">
                <button class="btn btn-neutral" onclick="loadLicenses()">↻ Refresh</button>
                <button class="btn btn-soft" onclick="exportLicensesCSV()">⇩ Export CSV</button>
              </div>
            </div>
            <div class="toolbar">
              <div class="search-wrap"><span class="search-icon">⌕</span><input id="licenseSearch" class="search-input" placeholder="Cari license, customer, device..." oninput="renderLicenses()"></div>
              <select id="statusFilter" class="toolbar-select" onchange="renderLicenses()"><option value="">Semua Status</option><option value="active">Active</option><option value="expired">Expired</option><option value="banned">Banned</option></select>
              <select id="activityFilter" class="toolbar-select" onchange="renderLicenses()"><option value="">Semua Aktivitas</option><option value="online">Online</option><option value="idle">Idle</option><option value="offline">Offline</option><option value="never">Belum Online</option></select>
            </div>
            <div id="selectionBar" class="selection-bar">
              <div><strong id="selectedCount">0</strong> license dipilih</div>
              <div style="display:flex;gap:7px;flex-wrap:wrap">
                <button class="btn btn-neutral" onclick="bulkReset()">Reset Device</button>
                <button class="btn btn-warning" onclick="bulkBan()">Ban</button>
                <button class="btn btn-success" onclick="bulkUnban()">Aktifkan</button>
                <button class="btn btn-neutral" onclick="clearSelection()">Batal</button>
              </div>
            </div>
            <div class="table-wrap">
              <table>
                <thead><tr>
                  <th><input id="selectAll" class="check" type="checkbox" onchange="toggleSelectAll(this.checked)"></th>
                  <th>ID</th><th>License</th><th>Customer</th><th>Status</th><th>Expired</th><th>Device</th><th>Aktivasi</th><th>Aktivitas</th><th>Action</th>
                </tr></thead>
                <tbody id="licenses"><tr><td colspan="9" class="empty">Belum dimuat.</td></tr></tbody>
              </table>
            </div>
          </div>
        </section>

        <section class="section" id="tab-messages">
          <div class="card">
            <div class="card-head"><div><h3>Pesan ke Client</h3><p>Kirim informasi dari Owner ke tool yang sedang online atau simpan untuk client yang akan online berikutnya.</p></div></div>
            <div class="create-grid">
              <div class="field"><label>Target</label><select id="messageTarget" onchange="toggleMessageTarget()"><option value="online">🟢 Semua Client Online</option><option value="all">🌐 Semua Client</option><option value="license">🔑 License Tertentu</option></select></div>
              <div class="field" id="messageLicenseField" style="display:none"><label>License Target</label><select id="messageLicense"></select></div>
              <div class="field"><label>Tipe Pesan</label><select id="messageType"><option value="info">ℹ️ Informasi</option><option value="update">🔄 Update</option><option value="warning">⚠️ Peringatan</option><option value="urgent">🚨 Urgent</option></select></div>
              <div class="field"><label>Judul</label><input id="messageTitle" maxlength="120" placeholder="Contoh: Maintenance Tools"></div>
            </div>
            <div class="field"><label>Isi Pesan</label><textarea id="messageBody" maxlength="2000" rows="5" placeholder="Tulis pesan yang akan tampil pada client..."></textarea></div>
            <div class="create-grid" style="margin-top:12px">
              <div class="field"><label>Masa Tampil</label><select id="messageDuration"><option value="3600">1 jam</option><option value="21600">6 jam</option><option value="86400" selected>24 jam</option><option value="604800">7 hari</option><option value="0">Tanpa expiry</option></select></div>
              <div class="field"><label>Tampilan</label><select id="messageSticky"><option value="0">Notifikasi biasa</option><option value="1">Sticky / wajib terlihat</option></select></div>
            </div>
            <div class="form-actions"><button class="btn btn-primary" onclick="sendClientMessage()">📢 KIRIM PESAN</button><button class="btn btn-neutral" onclick="clearMessageForm()">Bersihkan</button></div>
          </div>
          <div class="card">
            <div class="card-head"><div><h3>Riwayat Pesan</h3><p>Pesan tersimpan yang pernah dikirim Owner. Pesan nonaktif tidak akan diterima client.</p></div><button class="btn btn-neutral" onclick="loadMessages()">↻ Refresh</button></div>
            <div class="table-wrap"><table><thead><tr><th>Waktu</th><th>Target</th><th>Tipe</th><th>Pesan</th><th>Status</th><th>Action</th></tr></thead><tbody id="messageRows"><tr><td colspan="6" class="empty">Belum dimuat.</td></tr></tbody></table></div>
          </div>
        </section>

        <section class="section" id="tab-admins">
          <div class="card">
            <div class="card-head"><div><h3>Admin Management</h3><p>Owner dapat membuat, mengubah role/status, reset password, dan menghapus admin.</p></div><button class="btn btn-neutral" onclick="loadAdmins()">↻ Refresh</button></div>
            <div class="admin-grid">
              <div class="field"><label>Username Baru</label><input id="newAdminUsername" placeholder="admin2"></div>
              <div class="field"><label>Password Baru</label><input id="newAdminPassword" type="password" placeholder="Minimal 10 karakter"></div>
              <div class="field"><label>Role</label><select id="newAdminRole"><option value="admin">Admin</option><option value="viewer">Viewer</option></select></div>
              <button class="btn btn-primary" onclick="createAdmin()">＋ Tambah Admin</button>
            </div>
          </div>
          <div class="card">
            <div class="table-wrap">
              <table>
                <thead><tr><th>ID</th><th>Username</th><th>Role</th><th>Status</th><th>Dibuat</th><th>Update</th><th>Action</th></tr></thead>
                <tbody id="admins"><tr><td colspan="7" class="empty">Belum dimuat.</td></tr></tbody>
              </table>
            </div>
          </div>
        </section>

        <section class="section" id="tab-audit">
          <div class="card">
            <div class="card-head">
              <div><h3>Audit & Change History</h3><p>Riwayat perubahan persisten dari Owner, Admin, dan aktivitas sistem.</p></div>
              <button class="btn btn-soft" onclick="exportAuditCSV()">⇩ Export Audit</button>
            </div>
            <div class="toolbar audit-filters">
              <select id="auditActorFilter" class="toolbar-select audit-filter" onchange="renderAudit()"><option value="">Semua Actor</option></select>
              <select id="auditActionFilter" class="toolbar-select audit-filter" onchange="renderAudit()"><option value="">Semua Aksi</option></select>
              <div class="search-wrap" style="flex:1 1 260px;position:relative"><span class="search-icon">⌕</span><input id="auditSearch" class="search-input" placeholder="Cari actor, customer, target..." oninput="renderAudit()"></div>
              <button class="btn btn-neutral" onclick="loadAudit(true)">↻ Refresh</button>
            </div>
            <div class="table-wrap">
              <table>
                <thead><tr><th>Waktu WIB</th><th>Actor</th><th>Aksi</th><th>Target</th><th>Customer</th><th>Detail</th></tr></thead>
                <tbody id="auditLogs"><tr><td colspan="6" class="empty">Belum dimuat.</td></tr></tbody>
              </table>
            </div>
          </div>
        </section>

        <div class="card" style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap">
          <div class="small">Auto refresh</div>
          <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
            <label class="small" style="display:flex;align-items:center;gap:6px"><input id="autoRefresh" type="checkbox" checked onchange="toggleAutoRefresh()"> Aktif</label>
            <select id="refreshInterval" class="toolbar-select" onchange="toggleAutoRefresh()"><option value="30000">30 detik</option><option value="60000">60 detik</option><option value="120000">2 menit</option></select>
            <button class="btn btn-danger" onclick="disconnectOwner()">Logout Owner</button>
          </div>
        </div>
      </main>
    </div>
  </div>
</div>
<div id="toast" class="toast"></div>

<script>
const ownerState={licenses:[],admins:[],audit:[],messages:[],selected:new Set(),filtered:[],serverOffset:0,refreshTimer:null,connected:false};

function showMessage(text,type){const el=document.getElementById("message");if(!el)return;el.textContent=text;el.className="msg "+(type==="error"?"msg-error":"msg-success");el.style.display="block";clearTimeout(window._msgTimer);window._msgTimer=setTimeout(()=>{el.style.display="none"},4200);}
function toast(text){const el=document.getElementById("toast");if(!el)return;el.textContent=text;el.className="toast show";clearTimeout(window._toastTimer);window._toastTimer=setTimeout(()=>el.className="toast",2600);}
function escapeHtml(v){return String(v??"").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;");}
function tokenValue(){return(document.getElementById("token")?.value||"").trim();}
function clearToken(){document.getElementById("token").value="";document.getElementById("token").focus();}
function apiError(data,status){return(data&&(data.error||data.message))||("HTTP "+status);}
async function api(path,options={}){const headers={...(options.headers||{})};const token=tokenValue();if(token)headers["X-Owner-Token"]=token;const c=new AbortController();const t=setTimeout(()=>c.abort(),15000);let r;try{r=await fetch(path+(path.includes("?")?"&":"?")+"_="+Date.now(),{...options,headers,credentials:"same-origin",cache:"no-store",signal:c.signal});}catch(e){if(e&&e.name==="AbortError")throw new Error("Server tidak merespons dalam 15 detik.");throw e;}finally{clearTimeout(t)}let d;try{d=await r.json()}catch{throw new Error("Response server tidak valid.")}if(!r.ok)throw new Error(apiError(d,r.status));return d}
function formatDate(v){if(!v)return"-";const d=new Date(v);if(Number.isNaN(d.getTime()))return"-";return new Intl.DateTimeFormat("id-ID",{timeZone:"Asia/Jakarta",day:"2-digit",month:"2-digit",year:"numeric",hour:"2-digit",minute:"2-digit",second:"2-digit",hour12:false}).format(d)+" WIB"}
function remainingText(v){if(!v)return"-";const t=new Date(v).getTime();if(!Number.isFinite(t))return"-";const diff=t-(Date.now()+ownerState.serverOffset);if(diff<=0)return"EXPIRED";const total=Math.floor(diff/1000),days=Math.floor(total/86400),hours=Math.floor(total%86400/3600),mins=Math.floor(total%3600/60);return days+"h "+hours+"j "+mins+"m"}
function statusBadge(status){const s=String(status||"").toLowerCase();if(s==="active")return'<span class="badge badge-active">ACTIVE</span>';if(s==="banned"||s==="revoked")return'<span class="badge badge-banned">BANNED</span>';if(s==="expired")return'<span class="badge badge-expired">EXPIRED</span>';return'<span class="badge badge-neutral">'+escapeHtml(status||"-")+"</span>"}
function activityInfo(v,tool,version){if(!v)return'<span class="presence presence-never">⚪ BELUM ONLINE</span>';const t=new Date(v).getTime();if(!Number.isFinite(t))return'<span class="presence presence-never">⚪ BELUM ONLINE</span>';const age=Math.max(0,Date.now()-t);let cls=age<=90000?"presence-online":age<=300000?"presence-idle":"presence-offline";let label=age<=90000?"🟢 ONLINE":age<=300000?"🟡 IDLE":"🔴 OFFLINE";return'<span class="presence '+cls+'">'+label+"</span><br><span class='small'>"+escapeHtml(formatDate(v))+"</span><br><span class='small'>"+(tool?escapeHtml(tool):"-")+(version?" v"+escapeHtml(version):"")+"</span>"}
function normalizeStatus(l){let s=String(l?.status||"").toLowerCase();if(s==="active"&&l?.expires_at&&new Date(l.expires_at).getTime()<=Date.now()+ownerState.serverOffset)return"expired";return s}
function activityClass(v){if(!v)return"never";const age=Date.now()-new Date(v).getTime();if(!Number.isFinite(age))return"never";if(age<=90000)return"online";if(age<=300000)return"idle";return"offline"}

async function connectOwner(){if(!tokenValue())return showMessage("OWNER_TOKEN wajib diisi.","error");try{showMessage("Menghubungkan ke server...","success");await loadLicenses();await loadAdmins();await loadAudit();document.getElementById("authCard").style.display="none";document.getElementById("workspace").style.display="block";ownerState.connected=true;startAutoRefresh();toast("Owner berhasil terhubung");}catch(e){showMessage("Gagal terhubung: "+(e.message||String(e)),"error");}}
async function disconnectOwner(){stopAutoRefresh();ownerState.connected=false;ownerState.licenses=[];ownerState.admins=[];ownerState.audit=[];ownerState.messages=[];ownerState.selected.clear();document.getElementById("workspace").style.display="none";document.getElementById("authCard").style.display="block";clearToken();toast("Session Owner ditutup");}
function showTab(name,btn){document.querySelectorAll(".section").forEach(x=>x.classList.remove("active"));document.getElementById("tab-"+name)?.classList.add("active");document.querySelectorAll(".nav-btn").forEach(x=>x.classList.remove("active"));(btn||document.querySelector('[data-tab="'+name+'"]'))?.classList.add("active");if(name==="overview")renderOverview();if(name==="licenses")renderLicenses();if(name==="admins")loadAdmins();if(name==="audit")loadAudit(true);if(name==="messages"){loadMessages();populateMessageLicenses()}}
async function refreshAll(){try{await Promise.all([loadLicenses(),loadAdmins(),loadAudit(false)]);renderOverview();toast("Data berhasil diperbarui");}catch(e){showMessage("Refresh gagal: "+(e.message||String(e)),"error")}}
async function syncServerClock(){try{const before=Date.now();const r=await fetch("/server-time",{cache:"no-store"});const d=await r.json();const after=Date.now();const server=new Date(d.utc).getTime();if(Number.isFinite(server))ownerState.serverOffset=server-Math.floor((before+after)/2);updateServerClock()}catch{const el=document.getElementById("serverClock");if(el)el.textContent="🕐 Server WIB: tidak tersambung"}}
function updateServerClock(){const el=document.getElementById("serverClock");if(!el)return;const d=new Date(Date.now()+ownerState.serverOffset);el.textContent="🕐 Server WIB: "+new Intl.DateTimeFormat("id-ID",{timeZone:"Asia/Jakarta",day:"2-digit",month:"2-digit",year:"numeric",hour:"2-digit",minute:"2-digit",second:"2-digit",hour12:false}).format(d)+" WIB"}
function startAutoRefresh(){stopAutoRefresh();if(!document.getElementById("autoRefresh")?.checked)return;const ms=Number(document.getElementById("refreshInterval")?.value||30000);ownerState.refreshTimer=setInterval(()=>{if(ownerState.connected)refreshAll().catch(()=>{})},ms)}
function stopAutoRefresh(){if(ownerState.refreshTimer)clearInterval(ownerState.refreshTimer);ownerState.refreshTimer=null}
function toggleAutoRefresh(){startAutoRefresh()}

async function loadLicenses(){const data=await api("/owner/list");ownerState.licenses=Array.isArray(data.licenses)?data.licenses:[];if(data.server_time){const server=new Date(data.server_time).getTime();if(Number.isFinite(server))ownerState.serverOffset=server-Date.now()}renderOverview();renderLicenses();document.getElementById("syncInfo").textContent="Last sync: "+formatDate(data.server_time||new Date().toISOString());}
function renderOverview(){const rows=ownerState.licenses||[];const stats={total:rows.length,active:0,expired:0,banned:0,unactivated:0,online:0};rows.forEach(l=>{const s=normalizeStatus(l);if(s==="active")stats.active++;else if(s==="expired")stats.expired++;else if(s==="banned"||s==="revoked")stats.banned++;if(!l.hardware_id)stats.unactivated++;if(activityClass(l.last_seen_at)==="online")stats.online++});const set=(id,v)=>{const e=document.getElementById(id);if(e)e.textContent=String(v)};set("kpiTotal",stats.total);set("kpiActive",stats.active);set("kpiExpired",stats.expired);set("kpiBanned",stats.banned);set("kpiUnactivated",stats.unactivated);set("kpiOnline",stats.online);set("healthActive",stats.active);set("healthExpired",stats.expired);set("healthBanned",stats.banned);set("healthUnactivated",stats.unactivated);const rate=stats.total?Math.round(stats.active/stats.total*100):0;set("healthRate",rate+"% active");const bar=document.getElementById("healthProgress");if(bar)bar.style.width=rate+"%";set("adminTotal",ownerState.admins.length);set("adminActive",ownerState.admins.filter(a=>Number(a.active)===1).length);set("adminViewer",ownerState.admins.filter(a=>String(a.role)==="viewer").length);set("adminRoleCount",ownerState.admins.filter(a=>String(a.role)==="admin").length);const recent=document.getElementById("recentActivity");if(recent){const logs=Array.isArray(ownerState.audit)?ownerState.audit.slice(0,5):[];recent.innerHTML=logs.length?logs.map(l=>{const target=l.customer_name||((l.target_type||"")+" #"+(l.target_id??"-"));return'<div class="activity-item"><div class="activity-icon">📝</div><div class="activity-body"><strong>'+escapeHtml(auditLabel(l.action))+' · '+escapeHtml(l.actor||"-")+'</strong><div>'+escapeHtml(target)+' · '+escapeHtml(formatDate(l.created_at))+'</div></div></div>'}).join(""):'<div class="empty">Belum ada aktivitas.</div>'}}

function renderLicenses(){const tbody=document.getElementById("licenses");if(!tbody)return;const q=(document.getElementById("licenseSearch")?.value||"").trim().toLowerCase();const sf=(document.getElementById("statusFilter")?.value||"").toLowerCase();const af=(document.getElementById("activityFilter")?.value||"").toLowerCase();let rows=ownerState.licenses.filter(l=>{const st=normalizeStatus(l);const a=activityClass(l.last_seen_at);const hay=[l.id,l.license_key,l.customer_name,l.hardware_id,l.status].join(" ").toLowerCase();return(!q||hay.includes(q))&&(!sf||st===sf)&&(!af||a===af)});ownerState.filtered=rows;if(!rows.length){tbody.innerHTML='<tr><td colspan="9" class="empty">Tidak ada license yang cocok dengan filter.</td></tr>';updateSelectionUI();return}tbody.innerHTML=rows.map(l=>{const checked=ownerState.selected.has(Number(l.id))?" checked":"";const st=normalizeStatus(l);const hardware=l.hardware_id?'<span class="badge badge-active">TERIKAT</span><br><span class="small mono">'+escapeHtml(String(l.hardware_id).length<=18?l.hardware_id:String(l.hardware_id).slice(0,8)+"…"+String(l.hardware_id).slice(-8))+"</span>":'<span class="badge badge-neutral">BELUM AKTIVASI</span>';const key=escapeHtml(l.license_key||"");return'<tr><td><input class="check row-check" type="checkbox" value="'+Number(l.id)+'"'+checked+' onchange="setSelected('+Number(l.id)+',this.checked)"></td><td>'+escapeHtml(l.id)+'</td><td><div class="mono"><strong>'+key+'</strong></div><button class="btn btn-soft" style="margin-top:6px" data-license-key="'+key+'" onclick="copyText(this.dataset.licenseKey)">Copy</button></td><td><strong>'+escapeHtml(l.customer_name||"-")+'</strong><br><span class="small">'+escapeHtml(formatDate(l.created_at))+'</span></td><td>'+statusBadge(st)+'</td><td>'+escapeHtml(formatDate(l.expires_at))+'<br><span class="small mono" data-expiry="'+escapeHtml(l.expires_at||"")+'">'+escapeHtml(remainingText(l.expires_at))+'</span></td><td>'+hardware+'</td><td>'+escapeHtml(formatDate(l.activated_at))+'</td><td>'+activityInfo(l.last_seen_at,l.last_tool,l.last_version)+'</td><td><div class="row-actions"><button class="btn btn-warning" onclick="resetHardware('+Number(l.id)+')">RESET PC</button><button class="btn btn-primary" onclick="extendLicense('+Number(l.id)+')">PERPANJANG</button><button class="btn btn-soft" onclick="editExpiry('+Number(l.id)+')">EDIT EXPIRED</button><button class="btn btn-danger" onclick="banLicense('+Number(l.id)+')">BAN</button><button class="btn btn-success" onclick="unbanLicense('+Number(l.id)+')">AKTIFKAN</button><button class="btn btn-danger" onclick="deleteLicense('+Number(l.id)+')">DELETE</button></div></td></tr>'}).join("");updateSelectionUI()}
function setSelected(id,checked){id=Number(id);if(checked)ownerState.selected.add(id);else ownerState.selected.delete(id);updateSelectionUI()}
function toggleSelectAll(checked){(ownerState.filtered||[]).forEach(l=>{const id=Number(l.id);if(checked)ownerState.selected.add(id);else ownerState.selected.delete(id)});renderLicenses()}
function clearSelection(){ownerState.selected.clear();document.getElementById("selectAll").checked=false;renderLicenses()}
function updateSelectionUI(){const count=ownerState.selected.size;const bar=document.getElementById("selectionBar");if(bar)bar.classList.toggle("show",count>0);const sc=document.getElementById("selectedCount");if(sc)sc.textContent=String(count);const master=document.getElementById("selectAll");if(master){const visible=(ownerState.filtered||[]).map(l=>Number(l.id));master.checked=visible.length>0&&visible.every(id=>ownerState.selected.has(id));master.indeterminate=visible.some(id=>ownerState.selected.has(id))&&!master.checked}}

async function performBulk(action,label){const ids=[...ownerState.selected];if(!ids.length)return;const max=20;if(ids.length>max)return showMessage("Bulk action maksimal 20 license per operasi.","error");if(!confirm(label+" untuk "+ids.length+" license?"))return;let ok=0,fail=0;for(const id of ids){try{await api("/owner/"+action+"/"+Number(id),{method:"POST"});ok++}catch{fail++}}ownerState.selected.clear();await loadLicenses();showMessage(label+" selesai. Berhasil: "+ok+" · Gagal: "+fail,fail?"error":"success")}
function bulkReset(){performBulk("reset","Reset Device")}
function bulkBan(){performBulk("ban","Ban License")}
function bulkUnban(){performBulk("unban","Aktifkan License")}

function applyPreset(){const v=Number(document.getElementById("preset").value);if(v>0)document.getElementById("days").value=v}
function clearCreateForm(){document.getElementById("customer").value="";document.getElementById("days").value="30";document.getElementById("preset").value="30";document.getElementById("licenseResult").style.display="none"}
async function createLicense(){const customer=(document.getElementById("customer")?.value||"").trim();const days=Number(document.getElementById("days")?.value);if(!customer)return showMessage("Nama customer wajib diisi.","error");if(!Number.isInteger(days)||days<1||days>3650)return showMessage("Masa aktif harus 1-3650 hari.","error");try{const d=await api("/owner/create",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({customer_name:customer,days})});document.getElementById("newLicense").textContent=d.license_key||"-";document.getElementById("licenseResult").style.display="block";showMessage("License berhasil dibuat.","success");clearCreateForm();await loadLicenses()}catch(e){showMessage(e.message||String(e),"error")}}
function copyText(value){navigator.clipboard?.writeText(String(value||"")).then(()=>toast("Berhasil disalin")).catch(()=>showMessage("Gagal menyalin ke clipboard.","error"))}
function copyLicense(){copyText(document.getElementById("newLicense")?.textContent||"")}

async function extendLicense(id){const input=prompt("Berapa hari masa aktif ingin ditambahkan?","30");if(input===null)return;const days=Number(input);if(!Number.isInteger(days)||days<1||days>3650)return showMessage("Jumlah hari harus 1-3650 hari.","error");if(!confirm("Perpanjang license selama "+days+" hari?"))return;try{const d=await api("/owner/extend/"+Number(id),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({days})});showMessage("License diperpanjang sampai "+formatDate(d.expires_at),"success");await loadLicenses()}catch(e){showMessage(e.message||String(e),"error")}}
function expiryLocalValue(v){if(!v)return"";const d=new Date(v);if(Number.isNaN(d.getTime()))return"";const p=new Intl.DateTimeFormat("en-CA",{timeZone:"Asia/Jakarta",year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",hour12:false}).formatToParts(d).reduce((o,x)=>(o[x.type]=x.value,o),{});return p.year+"-"+p.month+"-"+p.day+" "+p.hour+":"+p.minute}
async function editExpiry(id){const license=ownerState.licenses.find(x=>Number(x.id)===Number(id));const input=prompt("Ubah expired WIB. Format YYYY-MM-DD HH:mm.",expiryLocalValue(license?.expires_at));if(input===null)return;const m=/^(\\d{4})-(\\d{2})-(\\d{2})[ T](\\d{2}):(\\d{2})(?::(\\d{2}))?$/.exec(input.trim());if(!m)return showMessage("Format tanggal tidak valid.","error");const dt=new Date(m[1]+"-"+m[2]+"-"+m[3]+"T"+m[4]+":"+m[5]+":"+(m[6]||"00")+"+07:00");if(Number.isNaN(dt.getTime()))return showMessage("Tanggal expired tidak valid.","error");try{const d=await api("/owner/edit-expiry/"+Number(id),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({expires_at:dt.toISOString()})});showMessage("Expired berhasil diubah sampai "+formatDate(d.expires_at),"success");await loadLicenses()}catch(e){showMessage(e.message||String(e),"error")}}
async function resetHardware(id){if(!confirm("Reset Device ID license ini?\\n\\nLicense bisa diaktivasi kembali pada perangkat lain."))return;try{await api("/owner/reset/"+Number(id),{method:"POST"});showMessage("Device berhasil di-reset.","success");await loadLicenses()}catch(e){showMessage(e.message||String(e),"error")}}
async function banLicense(id){if(!confirm("Ban license ini sementara?"))return;try{await api("/owner/ban/"+Number(id),{method:"POST"});showMessage("License berhasil di-ban.","success");await loadLicenses()}catch(e){showMessage(e.message||String(e),"error")}}
async function unbanLicense(id){if(!confirm("Aktifkan kembali license ini?"))return;try{await api("/owner/unban/"+Number(id),{method:"POST"});showMessage("License berhasil diaktifkan.","success");await loadLicenses()}catch(e){showMessage(e.message||String(e),"error")}}
async function deleteLicense(id){if(!confirm("⚠️ Hapus license ini permanen?"))return;const c=prompt("Ketik DELETE untuk mengonfirmasi:");if(c!=="DELETE")return toast("Penghapusan dibatalkan");try{await api("/owner/delete/"+Number(id),{method:"DELETE"});showMessage("License berhasil dihapus permanen.","success");ownerState.selected.delete(Number(id));await loadLicenses()}catch(e){showMessage(e.message||String(e),"error")}}
function updateCountdowns(){document.querySelectorAll("[data-expiry]").forEach(el=>el.textContent=remainingText(el.getAttribute("data-expiry")))}

async function loadAdmins(){try{const d=await api("/owner/admin/list");ownerState.admins=Array.isArray(d.admins)?d.admins:[];renderAdmins();renderOverview()}catch(e){showMessage("Gagal memuat admin: "+(e.message||String(e)),"error")}}
function renderAdmins(){const tbody=document.getElementById("admins");if(!tbody)return;if(!ownerState.admins.length){tbody.innerHTML='<tr><td colspan="7" class="empty">Belum ada admin.</td></tr>';return}tbody.innerHTML=ownerState.admins.map(a=>{const active=Number(a.active)===1;const role=escapeHtml(String(a.role||"admin"));return'<tr><td>'+escapeHtml(a.id)+'</td><td><strong>'+escapeHtml(a.username)+'</strong></td><td><span class="badge badge-neutral">'+escapeHtml(String(a.role||"admin").toUpperCase())+'</span></td><td><span class="admin-status '+(active?"admin-on":"admin-off")+'">'+(active?"● AKTIF":"○ NONAKTIF")+'</span></td><td>'+escapeHtml(formatDate(a.created_at))+'</td><td>'+escapeHtml(formatDate(a.updated_at))+'</td><td><div class="row-actions"><button class="btn btn-neutral" onclick="toggleAdminStatus('+Number(a.id)+','+(active?"false":"true")+')">'+(active?"NONAKTIFKAN":"AKTIFKAN")+'</button><button class="btn btn-soft" data-role="'+role+'" onclick="changeAdminRole('+Number(a.id)+',this.dataset.role)">ROLE</button><button class="btn btn-warning" onclick="resetAdminPassword('+Number(a.id)+')">RESET PASSWORD</button><button class="btn btn-danger" onclick="deleteAdmin('+Number(a.id)+')">DELETE</button></div></td></tr>'}).join("")}
async function createAdmin(){const username=(document.getElementById("newAdminUsername")?.value||"").trim();const password=document.getElementById("newAdminPassword")?.value||"";const role=document.getElementById("newAdminRole")?.value||"admin";if(!username||password.length<10)return showMessage("Username wajib diisi dan password minimal 10 karakter.","error");try{const d=await api("/owner/admin/create",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({username,password,role})});document.getElementById("newAdminUsername").value="";document.getElementById("newAdminPassword").value="";showMessage("Admin "+d.username+" berhasil dibuat.","success");await loadAdmins();await loadAudit(false)}catch(e){showMessage(e.message||String(e),"error")}}
async function toggleAdminStatus(id,active){if(!confirm((active?"Aktifkan":"Nonaktifkan")+" admin ini?"))return;try{await api("/owner/admin/update/"+Number(id),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({active:!!active})});showMessage("Status admin diperbarui.","success");await loadAdmins();await loadAudit(false)}catch(e){showMessage(e.message||String(e),"error")}}
async function changeAdminRole(id,current){const role=prompt("Masukkan role: admin atau viewer",current||"admin");if(role===null)return;if(!["admin","viewer"].includes(role.trim().toLowerCase()))return showMessage("Role harus admin atau viewer.","error");try{await api("/owner/admin/update/"+Number(id),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({role:role.trim().toLowerCase()})});showMessage("Role admin diperbarui.","success");await loadAdmins();await loadAudit(false)}catch(e){showMessage(e.message||String(e),"error")}}
async function resetAdminPassword(id){const pw=prompt("Masukkan password baru (minimal 10 karakter):");if(pw===null)return;if(pw.length<10)return showMessage("Password minimal 10 karakter.","error");if(!confirm("Reset password admin ini?"))return;try{await api("/owner/admin/update/"+Number(id),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({password:pw})});showMessage("Password admin berhasil di-reset.","success");await loadAudit(false)}catch(e){showMessage(e.message||String(e),"error")}}
async function deleteAdmin(id){if(!confirm("Hapus akun admin ini?\\n\\nOwner tetap dapat membuat akun baru."))return;try{await api("/owner/admin/delete/"+Number(id),{method:"DELETE"});showMessage("Admin berhasil dihapus.","success");await loadAdmins();await loadAudit(false)}catch(e){showMessage(e.message||String(e),"error")}}

function auditLabel(action){const m={LICENSE_CREATE:"Buat License",LICENSE_EXTEND:"Perpanjang License",LICENSE_EXPIRY_EDIT:"Edit Expired",LICENSE_RESET:"Reset Device",LICENSE_BAN:"Ban License",LICENSE_UNBAN:"Aktifkan License",LICENSE_DELETE:"Hapus License",LICENSE_ACTIVATE:"Aktivasi License",ADMIN_CREATE:"Buat Admin",ADMIN_UPDATE:"Update Admin",ADMIN_DELETE:"Hapus Admin",ADMIN_BOOTSTRAP:"Buat Admin Pertama",ADMIN_LOGIN:"Login Admin",ADMIN_LOGOUT:"Logout Admin",MESSAGE_SEND:"Kirim Pesan Client",MESSAGE_DEACTIVATE:"Nonaktifkan Pesan Client",MESSAGE_DELETE:"Hapus Pesan Client"};return m[action]||action||"-"}
function auditDetail(v){try{const o=typeof v==="string"?JSON.parse(v):v;return Object.entries(o||{}).map(([k,x])=>escapeHtml(k)+": "+escapeHtml(x)).join(" · ")||"-"}catch{return escapeHtml(v||"-")}}
async function loadAudit(showMsg){try{const d=await api("/owner/audit-logs?limit=200");ownerState.audit=Array.isArray(d.logs)?d.logs:[];populateAuditFilters();renderAudit();renderOverview();if(showMsg)toast("Audit diperbarui")}catch(e){showMessage("Gagal memuat audit: "+(e.message||String(e)),"error")}}
function populateAuditFilters(){const actor=document.getElementById("auditActorFilter"),action=document.getElementById("auditActionFilter");if(actor){const cur=actor.value;const actors=[...new Set(ownerState.audit.map(x=>String(x.actor||"")).filter(Boolean))].sort();actor.innerHTML='<option value="">Semua Actor</option>'+actors.map(x=>'<option value="'+escapeHtml(x)+'">'+escapeHtml(x)+'</option>').join("");if(actors.includes(cur))actor.value=cur}if(action){const cur=action.value;const actions=[...new Set(ownerState.audit.map(x=>String(x.action||"")).filter(Boolean))].sort();action.innerHTML='<option value="">Semua Aksi</option>'+actions.map(x=>'<option value="'+escapeHtml(x)+'">'+escapeHtml(auditLabel(x))+'</option>').join("");if(actions.includes(cur))action.value=cur}}
function renderAudit(){const actor=document.getElementById("auditActorFilter")?.value||"";const action=document.getElementById("auditActionFilter")?.value||"";const q=(document.getElementById("auditSearch")?.value||"").trim().toLowerCase();const rows=ownerState.audit.filter(l=>{const hay=[l.actor,l.customer_name,l.target_type,l.target_id,l.action,l.details].join(" ").toLowerCase();return(!actor||String(l.actor)===actor)&&(!action||String(l.action)===action)&&(!q||hay.includes(q))});const tbody=document.getElementById("auditLogs");if(!tbody)return;if(!rows.length){tbody.innerHTML='<tr><td colspan="6" class="empty">Tidak ada log yang cocok.</td></tr>';return}tbody.innerHTML=rows.map(l=>'<tr><td>'+escapeHtml(formatDate(l.created_at))+'</td><td><strong>'+escapeHtml(l.actor||"-")+'</strong><br><span class="badge badge-neutral">'+escapeHtml(String(l.role||"-").toUpperCase())+'</span></td><td><span class="badge badge-active">'+escapeHtml(auditLabel(l.action))+'</span></td><td>'+escapeHtml((l.target_type||"-")+" #"+(l.target_id??"-"))+'</td><td>'+escapeHtml(l.customer_name||"-")+'</td><td style="min-width:320px;white-space:normal;line-height:1.5">'+auditDetail(l.details)+'</td></tr>').join("")}
function toCsv(rows,headers){const enc=v=>'"'+String(v??"").replaceAll('"','""')+'"';return headers.map(enc).join(",")+"\\n"+rows.map(r=>headers.map(h=>enc(r[h])).join(",")).join("\\n")}
function downloadCsv(name,content){const blob=new Blob([content],{type:"text/csv;charset=utf-8"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
function populateMessageLicenses(){const sel=document.getElementById("messageLicense");if(!sel)return;sel.innerHTML='<option value="">Pilih license...</option>'+(ownerState.licenses||[]).map(l=>'<option value="'+Number(l.id)+'">'+escapeHtml(l.customer_name||"-")+' · '+escapeHtml(l.license_key||"")+'</option>').join("")}
function toggleMessageTarget(){const t=document.getElementById("messageTarget")?.value;const f=document.getElementById("messageLicenseField");if(f)f.style.display=t==="license"?"block":"none";if(t==="license")populateMessageLicenses()}
function clearMessageForm(){["messageTitle","messageBody"].forEach(id=>{const e=document.getElementById(id);if(e)e.value=""});const t=document.getElementById("messageTarget");if(t)t.value="online";const type=document.getElementById("messageType");if(type)type.value="info";const duration=document.getElementById("messageDuration");if(duration)duration.value="86400";const sticky=document.getElementById("messageSticky");if(sticky)sticky.value="0";toggleMessageTarget()}
function messageTargetLabel(m){return m.target_type==="license"?(m.customer_name||("License #"+m.target_license_id)):m.target_type==="online"?"Semua Online":"Semua Client"}
function messageTypeLabel(t){return ({info:"ℹ️ Informasi",update:"🔄 Update",warning:"⚠️ Peringatan",urgent:"🚨 Urgent"}[t]||t||"-")}
function renderMessages(){const tbody=document.getElementById("messageRows");if(!tbody)return;const rows=ownerState.messages||[];if(!rows.length){tbody.innerHTML='<tr><td colspan="6" class="empty">Belum ada pesan.</td></tr>';return}tbody.innerHTML=rows.map(m=>{const active=Number(m.active)===1;return '<tr><td>'+escapeHtml(formatDate(m.created_at))+'</td><td>'+escapeHtml(messageTargetLabel(m))+'</td><td>'+escapeHtml(messageTypeLabel(m.type))+'</td><td style="min-width:320px;white-space:normal"><strong>'+escapeHtml(m.title||"Pesan")+'</strong><br>'+escapeHtml(m.body||"")+'</td><td>'+(active?'<span class="badge badge-active">AKTIF</span>':'<span class="badge badge-expired">NONAKTIF</span>')+(Number(m.sticky)===1?'<br><span class="small">📌 Sticky</span>':'')+'</td><td><div class="row-actions">'+(active?'<button class="btn btn-warning" onclick="deactivateClientMessage('+Number(m.id)+')">NONAKTIFKAN</button>':'')+(Number(m.sticky)===1?'<button class="btn btn-neutral" disabled title="Pesan sticky tidak dapat dihapus">🔒 TIDAK DAPAT DIHAPUS</button>':'<button class="btn btn-danger" onclick="deleteClientMessage('+Number(m.id)+')">HAPUS</button>')+'</div></td></tr>'}).join("")}
async function loadMessages(){try{const d=await api("/owner/messages");ownerState.messages=Array.isArray(d.messages)?d.messages:[];renderMessages()}catch(e){showMessage("Gagal memuat pesan: "+(e.message||String(e)),"error")}}
async function sendClientMessage(){const target=document.getElementById("messageTarget")?.value||"online",licenseId=Number(document.getElementById("messageLicense")?.value||0),type=document.getElementById("messageType")?.value||"info",title=(document.getElementById("messageTitle")?.value||"").trim(),body=(document.getElementById("messageBody")?.value||"").trim(),duration=Number(document.getElementById("messageDuration")?.value||86400),sticky=Number(document.getElementById("messageSticky")?.value||0);if(!title)return showMessage("Judul pesan wajib diisi.","error");if(!body)return showMessage("Isi pesan wajib diisi.","error");if(target==="license"&&!licenseId)return showMessage("Pilih license target terlebih dahulu.","error");if(!confirm("Kirim pesan ke "+(target==="online"?"semua client online":target==="all"?"semua client":"license terpilih")+"?"))return;try{const d=await api("/owner/messages",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({target_type:target,target_license_id:target==="license"?licenseId:null,type,title,body,duration_seconds:duration,sticky})});showMessage("Pesan berhasil dikirim. Online saat ini: "+Number(d.online_count||0),"success");clearMessageForm();await loadMessages();await loadAudit(false)}catch(e){showMessage(e.message||String(e),"error")}}
async function deactivateClientMessage(id){if(!confirm("Nonaktifkan pesan ini? Pesan akan langsung berhenti ditampilkan/dikirim ke client, tetapi tetap tersimpan di riwayat."))return;try{await api("/owner/messages/"+Number(id)+"/deactivate",{method:"POST"});showMessage("Pesan berhasil dinonaktifkan.","success");await loadMessages()}catch(e){showMessage(e.message||String(e),"error")}}
async function deleteClientMessage(id){if(!confirm("HAPUS PERMANEN pesan ini? Record akan dihapus dari riwayat dan tidak dapat dikembalikan."))return;const c=prompt("Ketik DELETE untuk mengonfirmasi penghapusan permanen:");if(c!=="DELETE")return toast("Penghapusan dibatalkan");try{await api("/owner/messages/"+Number(id),{method:"DELETE"});showMessage("Pesan berhasil dihapus permanen dari riwayat.","success");await loadMessages();await loadAudit(false)}catch(e){showMessage(e.message||String(e),"error")}}

function exportLicensesCSV(){const rows=ownerState.filtered||ownerState.licenses;const headers=["id","license_key","customer_name","status","expires_at","hardware_id","activated_at","last_seen_at","last_tool","last_version"];downloadCsv("licenses_owner.csv",toCsv(rows,headers));toast("CSV license berhasil dibuat")}
function exportAuditCSV(){const headers=["created_at","actor","role","action","target_type","target_id","customer_name","details","ip_address"];downloadCsv("audit_owner.csv",toCsv(ownerState.audit,headers));toast("CSV audit berhasil dibuat")}

document.addEventListener("keydown",e=>{if(e.key==="Enter"&&document.activeElement?.id==="token")connectOwner()});
setInterval(updateServerClock,1000);setInterval(updateCountdowns,1000);syncServerClock();
</script>
</body>
</html>`;

const ADMIN_KEY_ICON = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA2NCA2NCI+PGRlZnM+PGxpbmVhckdyYWRpZW50IGlkPSJnIiB4MT0iMCIgeTE9IjAiIHgyPSIxIiB5Mj0iMSI+PHN0b3Agb2Zmc2V0PSIwIiBzdG9wLWNvbG9yPSIjOTNjNWZkIi8+PHN0b3Agb2Zmc2V0PSIxIiBzdG9wLWNvbG9yPSIjMjU2M2ViIi8+PC9saW5lYXJHcmFkaWVudD48L2RlZnM+PHJlY3Qgd2lkdGg9IjY0IiBoZWlnaHQ9IjY0IiByeD0iMTYiIGZpbGw9IiMwZjE3MmEiLz48cGF0aCBkPSJNMzggMTJhMTMgMTMgMCAwIDAtOS44MyAyMS41TDE2IDQ1LjY3VjUzaDcuMzN2LTUuMzNoNS4zNHYtNS4zNEgzNGw1LjUtNS41QTEzIDEzIDAgMSAwIDM4IDEyWm0wIDdhNiA2IDAgMSAxIDAgMTIgNiA2IDAgMCAxIDAtMTJaIiBmaWxsPSJ1cmwoI2cpIi8+PC9zdmc+";

const ADMIN_HTML = `
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Tools License Admin</title>
<style>
:root{--bg:#f4f7fb;--surface:#fff;--surface-2:#f8fafc;--border:#e5e7eb;--text:#0f172a;--muted:#64748b;--navy:#0b1220;--primary:#2563eb;--primary-2:#1d4ed8;--success:#16a34a;--danger:#dc2626;--warning:#d97706;--shadow:0 14px 45px rgba(15,23,42,.08);--radius:18px}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:radial-gradient(circle at top right,rgba(37,99,235,.08),transparent 28%),var(--bg);color:var(--text);font-family:Aptos,"Segoe UI Variable","Segoe UI",system-ui,-apple-system,BlinkMacSystemFont,Arial,sans-serif;font-size:14px;line-height:1.55;-webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility}button,input,select{font:inherit}button{border:0;cursor:pointer}button:disabled{opacity:.55;cursor:not-allowed}
.admin-page{max-width:1600px;margin:0 auto;padding:24px}.auth-card{max-width:720px;margin:8vh auto 0;background:rgba(255,255,255,.95);border:1px solid var(--border);border-radius:24px;box-shadow:var(--shadow);padding:32px}.auth-brand{display:flex;align-items:center;gap:14px;margin-bottom:22px}.brand-mark{width:48px;height:48px;border-radius:15px;background:linear-gradient(135deg,#0f172a,#334155);color:#fff;display:grid;place-items:center;font-size:24px;box-shadow:0 10px 22px rgba(15,23,42,.18)}.brand-mark img,.nav-btn img,.activity-icon img,.login-key-icon{display:block;object-fit:contain}.brand-mark img{width:100%;height:100%;border-radius:inherit}.nav-btn img{width:20px;height:20px;flex:0 0 auto;border-radius:6px}.login-key-icon{width:18px;height:18px;border-radius:5px}.eyebrow{font-size:12px;font-weight:800;letter-spacing:.12em;text-transform:uppercase;color:var(--primary)}
.auth-card h1{margin:4px 0 8px;font-size:28px}.auth-card p{margin:0;color:var(--muted)}.field{display:flex;flex-direction:column;gap:7px}.field label{font-size:12px;font-weight:800;color:#334155}.field input,.field select,.search-input,.toolbar-select{width:100%;border:1px solid #d7dee9;background:#fff;color:var(--text);border-radius:12px;padding:12px 13px;outline:none;transition:.15s}.field input:focus,.field select:focus,.search-input:focus,.toolbar-select:focus{border-color:#93c5fd;box-shadow:0 0 0 4px rgba(37,99,235,.1)}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:10px 14px;border-radius:11px;font-weight:800;transition:.15s}.btn:hover{transform:translateY(-1px)}.btn-primary{background:var(--primary);color:#fff}.btn-primary:hover{background:var(--primary-2)}.btn-soft{background:#eef2ff;color:#1e3a8a}.btn-neutral{background:#e2e8f0;color:#0f172a}.btn-danger{background:#fee2e2;color:#991b1b}.btn-success{background:#dcfce7;color:#166534}.btn-warning{background:#fef3c7;color:#92400e}.btn-dark{background:#0f172a;color:#fff}
.hint{font-size:12px;color:var(--muted);line-height:1.6}.header-bar{display:flex;align-items:center;justify-content:space-between;gap:16px;margin-bottom:18px}.header-title{display:flex;align-items:center;gap:14px}.header-title h1{margin:0;font-size:24px}.header-title p{margin:4px 0 0;color:var(--muted);font-size:13px}.status-pill{display:inline-flex;align-items:center;gap:7px;padding:7px 10px;border-radius:999px;background:#ecfdf5;color:#166534;font-size:12px;font-weight:800}.dot{width:8px;height:8px;border-radius:50%;background:#22c55e;box-shadow:0 0 0 4px rgba(34,197,94,.15)}.server-clock{padding:9px 12px;border:1px solid var(--border);border-radius:10px;background:#fff;font-size:12px;color:#475569}
.shell{display:grid;grid-template-columns:250px minmax(0,1fr);gap:18px;align-items:start}.sidebar{position:sticky;top:18px;background:linear-gradient(180deg,#0f172a,#111827 70%,#0b1220);color:#e5e7eb;border-radius:22px;padding:16px;box-shadow:var(--shadow)}.side-brand{padding:8px 10px 16px;border-bottom:1px solid rgba(255,255,255,.1);margin-bottom:12px}.side-brand strong{display:block;color:#fff;font-size:15px}.side-brand span{display:block;color:#94a3b8;font-size:11px;margin-top:4px}.nav-btn{width:100%;display:flex;align-items:center;gap:10px;text-align:left;background:transparent;color:#cbd5e1;padding:12px 12px;border-radius:11px;font-weight:800;font-size:13px;margin:3px 0}.nav-btn:hover{background:rgba(255,255,255,.06);color:#fff}.nav-btn.active{background:linear-gradient(135deg,#2563eb,#1d4ed8);color:#fff;box-shadow:0 10px 22px rgba(37,99,235,.28)}.sidebar-footer{border-top:1px solid rgba(255,255,255,.1);margin-top:14px;padding:14px 10px 4px;color:#94a3b8;font-size:11px;line-height:1.6}.main{min-width:0}.section{display:none}.section.active{display:block}
.hero{background:linear-gradient(135deg,#0f172a,#1e293b 62%,#334155);color:#fff;border-radius:22px;padding:24px;box-shadow:var(--shadow);margin-bottom:18px}.hero-top{display:flex;justify-content:space-between;align-items:flex-start;gap:15px}.hero h2{margin:0;font-size:22px}.hero p{margin:7px 0 0;color:#cbd5e1;font-size:13px;max-width:720px}.hero-actions{display:flex;gap:8px;flex-wrap:wrap}.kpis{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:12px;margin-bottom:18px}.kpi{background:#fff;border:1px solid var(--border);border-radius:16px;padding:16px;box-shadow:0 8px 24px rgba(15,23,42,.05)}.kpi .label{font-size:11px;color:var(--muted);font-weight:800;text-transform:uppercase;letter-spacing:.05em}.kpi .value{font-size:26px;font-weight:900;margin-top:7px}.kpi .meta{font-size:11px;color:var(--muted);margin-top:4px}.grid-2{display:grid;grid-template-columns:1.25fr .75fr;gap:16px}.card{background:var(--surface);border:1px solid var(--border);border-radius:18px;padding:18px;box-shadow:0 8px 28px rgba(15,23,42,.05);margin-bottom:16px}.card-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:14px}.card-head h3{margin:0;font-size:16px}.card-head p{margin:4px 0 0;font-size:12px;color:var(--muted)}
.progress{height:10px;background:#e2e8f0;border-radius:999px;overflow:hidden}.progress>span{display:block;height:100%;border-radius:999px;background:linear-gradient(90deg,#2563eb,#60a5fa)}.health-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:10px}.health-item{border:1px solid var(--border);border-radius:12px;padding:12px;background:var(--surface-2)}.health-item strong{display:block;font-size:18px}.health-item span{font-size:11px;color:var(--muted)}
.toolbar{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:12px}.toolbar .search-wrap{flex:1 1 280px;position:relative}.search-input{padding-left:38px}.search-icon{position:absolute;left:13px;top:50%;transform:translateY(-50%);font-size:14px;color:#94a3b8}.toolbar-select{width:auto;min-width:145px}.table-wrap{overflow-x:auto;overflow-y:hidden;max-width:100%;border:1px solid var(--border);border-radius:14px}table{width:100%;border-collapse:separate;border-spacing:0;min-width:1040px;font-size:13px}th,td{padding:12px 10px;border-bottom:1px solid var(--border);text-align:left;vertical-align:top;background:#fff}th{background:#f8fafc;color:#475569;font-size:10px;text-transform:uppercase;letter-spacing:.06em;font-weight:900;position:sticky;top:0;z-index:1}tbody tr:hover td{background:#fbfdff}tbody tr:last-child td{border-bottom:0}.mono{font-family:"SFMono-Regular",Consolas,"Liberation Mono",monospace}.badge{display:inline-flex;align-items:center;padding:5px 8px;border-radius:999px;font-size:10px;font-weight:900;white-space:nowrap}.badge-active{background:#dcfce7;color:#166534}.badge-expired{background:#fef3c7;color:#92400e}.badge-banned{background:#fee2e2;color:#991b1b}.badge-neutral{background:#e2e8f0;color:#334155}.presence{display:inline-flex;align-items:center;gap:5px;padding:4px 7px;border-radius:999px;font-size:10px;font-weight:900;white-space:nowrap}.presence-online{background:#dcfce7;color:#166534}.presence-idle{background:#fef3c7;color:#92400e}.presence-offline{background:#fee2e2;color:#991b1b}.presence-never{background:#e2e8f0;color:#475569}.row-actions{display:flex;gap:5px;flex-wrap:wrap;min-width:280px}.row-actions .btn{padding:7px 9px;font-size:10px}.create-grid{display:grid;grid-template-columns:2fr 1fr 1fr;gap:10px}.form-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px}.license-result{display:none;margin-top:12px;padding:13px;background:#eff6ff;border:1px solid #bfdbfe;border-radius:12px}.license-key{font:900 18px "SFMono-Regular",Consolas,monospace;letter-spacing:.7px;word-break:break-all;margin-top:6px}.summary-line{display:flex;gap:10px;flex-wrap:wrap}.summary-chip{padding:8px 10px;border:1px solid var(--border);border-radius:10px;background:#fff;font-size:11px}.summary-chip strong{font-size:14px}.audit-filters{display:flex;gap:8px;flex-wrap:wrap}.audit-filter{min-width:150px}.msg{display:none;margin-bottom:16px;padding:12px 14px;border-radius:12px;font-size:12px;font-weight:800}.msg-success{display:block;background:#dcfce7;color:#166534}.msg-error{display:block;background:#fee2e2;color:#991b1b}.toast{position:fixed;right:22px;bottom:22px;z-index:50;max-width:360px;display:none;padding:12px 14px;border-radius:12px;background:#0f172a;color:#fff;box-shadow:0 15px 35px rgba(15,23,42,.25);font-size:12px;font-weight:800}.toast.show{display:block;animation:toastIn .18s ease}.muted{color:var(--muted)}.empty{text-align:center!important;color:var(--muted);padding:28px!important}.admin-only-note{padding:10px 12px;border-radius:10px;background:#eff6ff;color:#1e3a8a;font-size:12px}.role-pill{display:inline-flex;align-items:center;padding:6px 9px;border-radius:999px;background:#e0e7ff;color:#3730a3;font-size:10px;font-weight:900}.stat-strip{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}.stat-box{border:1px solid var(--border);border-radius:12px;padding:12px;background:#fff}.stat-box strong{font-size:20px;display:block}.stat-box span{font-size:11px;color:var(--muted)}
@keyframes toastIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
@media(max-width:1100px){.kpis{grid-template-columns:repeat(3,minmax(0,1fr))}.grid-2{grid-template-columns:1fr}.shell{grid-template-columns:1fr}.sidebar{position:static}.nav-btn{width:auto;display:inline-flex;margin:2px}.sidebar{padding:12px}.side-nav{display:flex;gap:5px;flex-wrap:wrap}.sidebar-footer{display:none}}
@media(max-width:700px){.admin-page{padding:12px}.kpis{grid-template-columns:repeat(2,minmax(0,1fr))}.create-grid,.stat-strip{grid-template-columns:1fr}.header-bar{align-items:flex-start;flex-direction:column}.hero-top{flex-direction:column}.header-title h1{font-size:20px}.auth-card{padding:22px;margin-top:4vh}.toolbar-select{width:100%}}

/* V4.3.9 typography refresh */
h1,h2,h3,h4,h5,h6{font-family:"Aptos Display",Aptos,"Segoe UI Variable","Segoe UI",Arial,sans-serif;letter-spacing:-.012em}
button,input,select,textarea{font-family:Aptos,"Segoe UI Variable","Segoe UI",system-ui,-apple-system,BlinkMacSystemFont,Arial,sans-serif}
label,.label,.eyebrow,.badge,.status-pill,.nav-btn,.btn{letter-spacing:.005em}
.small,.hint,.muted,.meta,p{letter-spacing:.002em}
</style>
</head>
<body>
<div class="admin-page">
  <div class="auth-card" id="loginCard">
    <div class="auth-brand"><div class="brand-mark"><img src="${ADMIN_KEY_ICON}" alt="Key"></div><div><div class="eyebrow">Secure workspace</div><h1>Tools License Admin</h1><p>Control panel untuk pengelolaan license dan pemantauan aktivitas.</p></div></div>
    <div class="field"><label>Username</label><input id="adminUsername" autocomplete="username" placeholder="Masukkan username admin"></div>
    <div class="field" style="margin-top:12px"><label>Password</label><input id="adminPassword" type="password" autocomplete="current-password" placeholder="Masukkan password"></div>
    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:16px"><button class="btn btn-dark" onclick="adminLogin()"><img class="login-key-icon" src="${ADMIN_KEY_ICON}" alt="Key"> Login Admin</button><span class="role-pill">ADMIN ACCESS</span></div>
    <div class="admin-only-note" style="margin-top:14px">Gunakan akun yang diberikan Owner. Aktivitas penting dipantau oleh sistem.</div>
  </div>

  <div id="app" style="display:none">
    <div class="header-bar">
      <div class="header-title"><div class="brand-mark" style="width:44px;height:44px;border-radius:14px"><img src="${ADMIN_KEY_ICON}" alt="Key"></div><div><h1>Admin Control Center</h1><p>Kelola license, monitor aktivitas.</p></div></div>
      <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap"><span class="status-pill"><span class="dot"></span>Admin Online</span><span class="role-pill" id="rolePill">ADMIN</span><span class="server-clock" id="serverClock">🕐 Server WIB: memuat...</span></div>
    </div>
    <div id="message" class="msg"></div>
    <div class="shell">
      <aside class="sidebar">
        <div class="side-brand"><div style="display:flex;align-items:center;gap:9px;margin-bottom:8px"><img src="${ADMIN_KEY_ICON}" alt="Key" style="width:22px;height:22px;border-radius:6px"><strong style="margin:0">Tools License</strong></div><span>Admin Workspace v${VERSION}</span></div>
        <div class="side-nav">
          <button class="nav-btn active" data-tab="overview" onclick="showTab('overview',this)"><img src="${ADMIN_KEY_ICON}" alt="Key"><span>Overview</span></button>
          <button class="nav-btn" data-tab="licenses" onclick="showTab('licenses',this)"><img src="${ADMIN_KEY_ICON}" alt="Key"><span>License Registry</span></button>
        </div>
        <div class="sidebar-footer"><strong id="loggedUser">-</strong><br>Signed in as Admin<br><br><button class="btn btn-neutral" style="width:100%" onclick="adminLogout()">↪ Logout</button></div>
      </aside>

      <main class="main">
        <section class="section active" id="tab-overview">
          <div class="hero"><div class="hero-top"><div><h2>Selamat datang, <span id="welcomeUser">Admin</span></h2><p>Ringkasan operasional license dan aktivitas terbaru.</p></div><div class="hero-actions"><button class="btn btn-neutral" onclick="refreshAll()">↻ Refresh Data</button><button class="btn btn-soft" onclick="showTab('licenses',document.querySelector('[data-tab=licenses]'))">+ Buat License</button></div></div></div>
          <div class="kpis"><div class="kpi"><div class="label">Total License</div><div class="value" id="kpiTotal">0</div><div class="meta">Semua record</div></div><div class="kpi"><div class="label">Active</div><div class="value" id="kpiActive">0</div><div class="meta">Status aktif</div></div><div class="kpi"><div class="label">Expired</div><div class="value" id="kpiExpired">0</div><div class="meta">Masa aktif habis</div></div><div class="kpi"><div class="label">Banned</div><div class="value" id="kpiBanned">0</div><div class="meta">Diblokir Owner/Admin</div></div><div class="kpi"><div class="label">Unactivated</div><div class="value" id="kpiUnactivated">0</div><div class="meta">Belum terikat device</div></div><div class="kpi"><div class="label">Online</div><div class="value" id="kpiOnline">0</div><div class="meta">Aktif dalam 90 detik</div></div></div>
          <div class="grid-2">
            <div class="card"><div class="card-head"><div><h3>License Health</h3><p>Distribusi status license saat ini.</p></div></div><div class="health-grid"><div class="health-item"><strong id="healthActive">0</strong><span>Active</span></div><div class="health-item"><strong id="healthExpired">0</strong><span>Expired</span></div><div class="health-item"><strong id="healthBanned">0</strong><span>Banned</span></div><div class="health-item"><strong id="healthUnactivated">0</strong><span>Belum aktivasi</span></div></div><div style="margin-top:14px"><div style="display:flex;justify-content:space-between;font-size:11px;font-weight:800;color:#475569;margin-bottom:7px"><span>Activation coverage</span><span id="activationPct">0%</span></div><div class="progress"><span id="activationBar" style="width:0%"></span></div></div></div>
            <div class="card"><div class="card-head"><div><h3>Quick Stats</h3><p>Ringkasan penggunaan admin.</p></div></div><div class="stat-strip"><div class="stat-box"><strong id="auditCount">0</strong><span>Aktivitas tercatat</span></div><div class="stat-box"><strong id="recentActive">0</strong><span>Online/Idle</span></div><div class="stat-box"><strong id="expiringSoon">0</strong><span>Exp. ≤ 7 hari</span></div></div><div style="margin-top:14px" class="hint">Status online berdasarkan <span class="mono">last_seen_at</span> yang dikirim oleh client.</div></div>
          </div>

        </section>

        <section class="section" id="tab-licenses">
          <div class="hero"><div class="hero-top"><div><h2>License Registry</h2><p>Pusat pengelolaan license untuk akun Admin. Gunakan pencarian dan filter agar proses operasional lebih cepat.</p></div><div class="hero-actions"><button class="btn btn-neutral" onclick="loadLicenses()">↻ Refresh</button><button class="btn btn-soft" onclick="exportLicensesCSV()">⇩ Export CSV</button></div></div></div>
          <div class="card">
            <div class="card-head"><div><h3>Create License</h3><p>Buat license baru untuk customer.</p></div><span class="badge badge-neutral">1–3650 hari</span></div>
            <div class="create-grid"><div class="field"><label>Nama Customer</label><input id="customer" placeholder="Contoh: Budi"></div><div class="field"><label>Masa Aktif</label><input id="days" type="number" value="30" min="1" max="3650"></div><div class="field"><label>Preset</label><select id="daysPreset" onchange="applyPreset()"><option value="">Pilih preset</option><option value="7">7 hari</option><option value="30">30 hari</option><option value="90">90 hari</option><option value="180">180 hari</option><option value="365">365 hari</option></select></div></div>
            <div class="form-actions"><button class="btn btn-primary" onclick="createLicense()">+ CREATE LICENSE</button><button class="btn btn-neutral" onclick="clearCreateForm()">Reset Form</button></div>
            <div id="licenseResult" class="license-result"><div class="hint">License berhasil dibuat</div><div id="newLicense" class="license-key"></div><div class="form-actions"><button class="btn btn-soft" onclick="copyLicense()">⧉ Copy License</button></div></div>
          </div>
          <div class="card"><div class="card-head"><div><h3>License List</h3><p id="licenseSummary">0 license</p></div></div>
            <div class="toolbar"><div class="search-wrap"><span class="search-icon">⌕</span><input class="search-input" id="licenseSearch" placeholder="Cari license, customer, device..." oninput="renderLicenses()"></div><select class="toolbar-select" id="statusFilter" onchange="renderLicenses()"><option value="">Semua status</option><option value="active">Active</option><option value="expired">Expired</option><option value="banned">Banned</option></select><select class="toolbar-select" id="activityFilter" onchange="renderLicenses()"><option value="">Semua aktivitas</option><option value="online">Online</option><option value="idle">Idle</option><option value="offline">Offline</option><option value="never">Belum online</option></select></div>
            <div class="table-wrap"><table><thead><tr><th>ID</th><th>License</th><th>Customer</th><th>Status</th><th>Expired</th><th>Device</th><th>Aktivasi</th><th>Aktivitas</th><th>Action</th></tr></thead><tbody id="licenses"><tr><td colspan="9" class="empty">Belum dimuat.</td></tr></tbody></table></div>
          </div>
        </section>

        
      </main>
    </div>
  </div>
</div>
<div id="toast" class="toast"></div>
<script>
const ADMIN_KEY_ICON_CLIENT="${ADMIN_KEY_ICON}";
const adminState={licenses:[],audit:[],connected:false,refreshTimer:null};
let serverOffset=0;
function esc(v){return String(v??"").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;")}
function showMessage(text,type){const e=document.getElementById("message");if(!e)return;e.textContent=text;e.className="msg "+(type==="error"?"msg-error":"msg-success");}
function toast(text){const e=document.getElementById("toast");if(!e)return;e.textContent=text;e.className="toast show";clearTimeout(window.__toast);window.__toast=setTimeout(()=>e.className="toast",2400)}
function api(path,options={}){const controller=new AbortController();const timeoutId=setTimeout(()=>controller.abort(),15000);return fetch(path+(path.includes("?")?"&":"?")+"_="+Date.now(),{...options,credentials:"same-origin",cache:"no-store",signal:controller.signal}).then(async r=>{let d;try{d=await r.json()}catch{throw new Error("Response server tidak valid.")}if(!r.ok)throw new Error(d.error||d.message||("HTTP "+r.status));return d}).catch(e=>{if(e&&e.name==="AbortError")throw new Error("Server tidak merespons dalam 15 detik.");throw e}).finally(()=>clearTimeout(timeoutId))}
let adminLoginInFlight=false;
async function adminLogin(){
  if(adminLoginInFlight)return;
  const username=(document.getElementById("adminUsername")?.value||"").trim();
  const password=document.getElementById("adminPassword")?.value||"";
  const btn=document.querySelector('#loginCard button[onclick="adminLogin()"]');
  if(!username||!password)return showMessage("Username dan password wajib diisi.","error");
  adminLoginInFlight=true;
  if(btn){btn.disabled=true;btn.dataset.originalText=btn.textContent;btn.textContent="Menghubungkan...";}
  try{
    const r=await fetch("/owner/login",{method:"POST",headers:{"Content-Type":"application/json"},credentials:"same-origin",cache:"no-store",body:JSON.stringify({username,password})});
    let d={};try{d=await r.json()}catch{throw new Error("Response login tidak valid.")}
    if(!r.ok){
      if(r.status===401){
        if(d?.error==="INVALID_USERNAME")throw new Error("Akun Admin tidak ditemukan. Periksa username atau gunakan Owner > Kelola Admin.");
        if(d?.error==="ADMIN_INACTIVE")throw new Error("Akun Admin sedang nonaktif. Aktifkan kembali dari Owner > Kelola Admin.");
        if(d?.error==="INVALID_PASSWORD")throw new Error("Password Admin tidak sesuai. Gunakan Owner > Kelola Admin > RESET PASSWORD.");
        if(d?.error==="INVALID_LOGIN")throw new Error("Username/password salah atau akun Admin tidak aktif.");
      }
      if(r.status===429)throw new Error("Terlalu banyak percobaan login. Tunggu sebentar lalu coba lagi.");
      throw new Error(d?.error||d?.message||("Login gagal (HTTP "+r.status+")"));
    }
    document.getElementById("adminPassword").value="";
    document.getElementById("loggedUser").textContent=d.username||username;
    document.getElementById("welcomeUser").textContent=d.username||username;
    document.getElementById("rolePill").textContent=String(d.role||"admin").toUpperCase();
    document.getElementById("loginCard").style.display="none";
    document.getElementById("app").style.display="block";
    adminState.connected=true;
    showMessage("Login admin berhasil.","success");
    await refreshAll();
    startAutoRefresh();
    toast("Session admin aktif")
  }catch(e){showMessage(e.message||String(e),"error")}
  finally{
    adminLoginInFlight=false;
    if(btn){btn.disabled=false;btn.textContent=btn.dataset.originalText||"Login Admin";}
  }
}
async function adminLogout(){stopAutoRefresh();try{await fetch("/owner/logout",{method:"POST",credentials:"same-origin",cache:"no-store"})}finally{adminState.connected=false;adminState.licenses=[];adminState.audit=[];document.getElementById("app").style.display="none";document.getElementById("loginCard").style.display="block";showMessage("Session admin ditutup.","success")}}
function showTab(tab,btn){document.querySelectorAll(".section").forEach(e=>e.classList.remove("active"));document.getElementById("tab-"+tab)?.classList.add("active");document.querySelectorAll(".nav-btn").forEach(e=>e.classList.remove("active"));(btn||document.querySelector('[data-tab="'+tab+'"]'))?.classList.add("active");if(tab==="licenses")renderLicenses()}
async function refreshAll(){await Promise.allSettled([loadLicenses(),loadAuditLogs(false),syncServerClock()]);renderOverview();if(document.getElementById("tab-licenses")?.classList.contains("active"))renderLicenses();}
function startAutoRefresh(){stopAutoRefresh();adminState.refreshTimer=setInterval(()=>{if(adminState.connected)refreshAll()},60000)}function stopAutoRefresh(){if(adminState.refreshTimer){clearInterval(adminState.refreshTimer);adminState.refreshTimer=null}}
async function syncServerClock(){try{const b=Date.now(),r=await fetch("/server-time",{cache:"no-store"}),d=await r.json(),a=Date.now(),t=new Date(d.utc).getTime();if(Number.isFinite(t))serverOffset=t-Math.floor((b+a)/2);updateServerClock()}catch{const e=document.getElementById("serverClock");if(e)e.textContent="🕐 Server WIB: tidak tersambung"}}
function updateServerClock(){const e=document.getElementById("serverClock");if(!e)return;const d=new Date(Date.now()+serverOffset);e.textContent="🕐 Server WIB: "+new Intl.DateTimeFormat("id-ID",{timeZone:"Asia/Jakarta",day:"2-digit",month:"2-digit",year:"numeric",hour:"2-digit",minute:"2-digit",second:"2-digit",hour12:false}).format(d)+" WIB"}
function formatDate(v){if(!v)return"-";const d=new Date(v);if(Number.isNaN(d.getTime()))return"-";return new Intl.DateTimeFormat("id-ID",{timeZone:"Asia/Jakarta",day:"2-digit",month:"2-digit",year:"numeric",hour:"2-digit",minute:"2-digit",second:"2-digit",hour12:false}).format(d)+" WIB"}
function remainingText(v){if(!v)return"-";const t=new Date(v).getTime();if(!Number.isFinite(t))return"-";const diff=t-(Date.now()+serverOffset);if(diff<=0)return"EXPIRED";const total=Math.floor(diff/1000),days=Math.floor(total/86400),hours=Math.floor((total%86400)/3600),mins=Math.floor((total%3600)/60),secs=total%60;return days+"h "+hours+"j "+mins+"m "+secs+"d"}
function updateCountdowns(){document.querySelectorAll("[data-expiry]").forEach(e=>e.textContent=remainingText(e.getAttribute("data-expiry")))}
function statusClass(status){const s=String(status||"").toLowerCase();return s==="active"?"badge-active":s==="banned"||s==="revoked"?"badge-banned":"badge-expired"}
function activityInfo(lastSeen){if(!lastSeen)return{cls:"presence-never",label:"⚪ BELUM ONLINE"};const t=new Date(lastSeen).getTime();if(!Number.isFinite(t))return{cls:"presence-never",label:"⚪ BELUM ONLINE"};const age=Math.max(0,Date.now()-t);if(age<=90000)return{cls:"presence-online",label:"🟢 ONLINE"};if(age<=300000)return{cls:"presence-idle",label:"🟡 IDLE"};return{cls:"presence-offline",label:"🔴 OFFLINE"}}
async function loadLicenses(){try{const d=await api("/admin/list");adminState.licenses=Array.isArray(d.licenses)?d.licenses:[];renderLicenses();renderOverview()}catch(e){if(String(e.message||e).includes("UNAUTHORIZED")){await adminLogout();return}showMessage("Gagal memuat license: "+(e.message||String(e)),"error")}}
function filteredLicenses(){const q=(document.getElementById("licenseSearch")?.value||"").trim().toLowerCase(),status=document.getElementById("statusFilter")?.value||"",act=document.getElementById("activityFilter")?.value||"";return adminState.licenses.filter(l=>{const ai=activityInfo(l.last_seen_at);const cls=ai.cls.replace("presence-","");const hay=[l.license_key,l.customer_name,l.hardware_id,l.status,l.id].join(" ").toLowerCase();return(!q||hay.includes(q))&&(!status||String(l.status||"").toLowerCase()===status)&&(!act||cls===act)})}
function renderLicenses(){const tbody=document.getElementById("licenses");if(!tbody)return;const rows=filteredLicenses();document.getElementById("licenseSummary").textContent=rows.length+" license tampil / "+adminState.licenses.length+" total";if(!rows.length){tbody.innerHTML='<tr><td colspan="9" class="empty">Tidak ada license yang cocok.</td></tr>';return}tbody.innerHTML=rows.map(l=>{const id=Number(l.id),a=activityInfo(l.last_seen_at),hardware=l.hardware_id?'<span class="badge badge-neutral">TERIKAT</span><br><span class="muted mono">'+esc(l.hardware_id.length>20?l.hardware_id.slice(0,8)+"..."+l.hardware_id.slice(-8):l.hardware_id)+'</span>':'<span class="muted">Belum aktivasi</span>';return '<tr><td>'+esc(l.id)+'</td><td><strong class="mono">'+esc(l.license_key)+'</strong><br><button class="btn btn-soft" style="margin-top:6px;padding:5px 8px;font-size:10px" onclick="copyText('+JSON.stringify(String(l.license_key||""))+')">⧉ Copy</button></td><td><strong>'+esc(l.customer_name||"-")+'</strong></td><td><span class="badge '+statusClass(l.status)+'">'+esc(String(l.status||"-").toUpperCase())+'</span></td><td>'+esc(formatDate(l.expires_at))+'<br><span class="muted mono" data-expiry="'+esc(l.expires_at||"")+'">'+remainingText(l.expires_at)+'</span></td><td>'+hardware+'</td><td>'+esc(formatDate(l.activated_at))+'</td><td><span class="'+a.cls+' presence">'+a.label+'</span><br><small>'+esc(formatDate(l.last_seen_at))+'</small><br><small class="muted">'+esc(l.last_tool||"-")+(l.last_version?" v"+esc(l.last_version):"")+'</small></td><td><div class="row-actions"><button class="btn btn-primary" onclick="extendLicense('+id+')">PERPANJANG</button><button class="btn btn-warning" onclick="resetHardware('+id+')">RESET PC</button><button class="btn btn-danger" onclick="banLicense('+id+')">BAN</button><button class="btn btn-success" onclick="unbanLicense('+id+')">AKTIFKAN</button></div></td></tr>'}).join("")}
async function createLicense(){const customer=(document.getElementById("customer")?.value||"").trim(),days=Number(document.getElementById("days")?.value);if(!customer)return showMessage("Nama customer wajib diisi.","error");if(!Number.isInteger(days)||days<1||days>3650)return showMessage("Masa aktif harus 1-3650 hari.","error");try{const d=await api("/admin/create",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({customer_name:customer,days})});document.getElementById("newLicense").textContent=d.license_key||"-";document.getElementById("licenseResult").style.display="block";document.getElementById("customer").value="";showMessage("License berhasil dibuat.","success");await loadLicenses();await loadAudit(false)}catch(e){showMessage(e.message||String(e),"error")}}
function clearCreateForm(){document.getElementById("customer").value="";document.getElementById("days").value=30;document.getElementById("daysPreset").value="";document.getElementById("licenseResult").style.display="none"}
function applyPreset(){const v=document.getElementById("daysPreset")?.value;if(v)document.getElementById("days").value=v}
async function extendLicense(id){const input=prompt("Berapa hari masa aktif ingin ditambahkan?","30");if(input===null)return;const days=Number(input);if(!Number.isInteger(days)||days<1||days>3650)return showMessage("Jumlah hari harus 1-3650 hari.","error");if(!confirm("Perpanjang license selama "+days+" hari?"))return;try{const d=await api("/admin/extend/"+Number(id),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({days})});showMessage("Berhasil diperpanjang sampai "+formatDate(d.expires_at),"success");await loadLicenses();await loadAudit(false)}catch(e){showMessage(e.message||String(e),"error")}}
async function resetHardware(id){if(!confirm("Reset Device ID license ini?\\n\\nLicense dapat diaktivasi kembali pada perangkat lain."))return;try{await api("/admin/reset/"+Number(id),{method:"POST"});showMessage("Device berhasil di-reset.","success");await loadLicenses();await loadAudit(false)}catch(e){showMessage(e.message||String(e),"error")}}
async function banLicense(id){if(!confirm("BAN license ini sementara?\\n\\nLicense dapat diaktifkan kembali."))return;try{await api("/admin/ban/"+Number(id),{method:"POST"});showMessage("License berhasil di-ban.","success");await loadLicenses();await loadAudit(false)}catch(e){showMessage(e.message||String(e),"error")}}
async function unbanLicense(id){if(!confirm("Aktifkan kembali license ini?"))return;try{await api("/admin/unban/"+Number(id),{method:"POST"});showMessage("License berhasil diaktifkan kembali.","success");await loadLicenses();await loadAudit(false)}catch(e){showMessage(e.message||String(e),"error")}}
function copyText(v){navigator.clipboard.writeText(String(v||"")).then(()=>toast("Berhasil dicopy")).catch(()=>showMessage("Gagal menyalin license.","error"))}
function copyLicense(){copyText(document.getElementById("newLicense")?.textContent||"")}
function auditLabel(a){const m={LICENSE_CREATE:"Buat License",LICENSE_EXTEND:"Perpanjang License",LICENSE_EXPIRY_EDIT:"Edit Expired",LICENSE_RESET:"Reset Device",LICENSE_BAN:"Ban License",LICENSE_UNBAN:"Aktifkan License",LICENSE_DELETE:"Hapus License",LICENSE_ACTIVATE:"Aktivasi License",ADMIN_CREATE:"Buat Admin",ADMIN_UPDATE:"Update Admin",ADMIN_DELETE:"Hapus Admin",ADMIN_BOOTSTRAP:"Buat Admin Pertama",ADMIN_LOGIN:"Login Admin",ADMIN_LOGOUT:"Logout Admin"};return m[a]||a||"-"}
function auditDetail(v){try{const o=typeof v==="string"?JSON.parse(v):v;return Object.entries(o||{}).map(([k,x])=>esc(k)+": "+esc(x)).join(" · ")||"-"}catch{return esc(v||"-")}}
async function loadAuditLogs(notify){try{const d=await api("/admin/audit-logs?limit=100");adminState.audit=Array.isArray(d.logs)?d.logs:[];populateAuditFilters();renderAuditLogs();renderOverview();if(notify)toast("Audit diperbarui")}catch(e){showMessage("Gagal memuat audit: "+(e.message||String(e)),"error")}}
function populateAuditFilters(){const sel=document.getElementById("auditActionFilter");if(!sel)return;const cur=sel.value;const actions=[...new Set(adminState.audit.map(x=>String(x.action||"")).filter(Boolean))].sort();sel.innerHTML='<option value="">Semua aksi</option>'+actions.map(x=>'<option value="'+esc(x)+'">'+esc(auditLabel(x))+'</option>').join("");if(actions.includes(cur))sel.value=cur}
function renderAuditLogs(){const tbody=document.getElementById("auditLogs");if(!tbody)return;const q=(document.getElementById("auditSearch")?.value||"").trim().toLowerCase(),action=document.getElementById("auditActionFilter")?.value||"";const rows=adminState.audit.filter(l=>{const hay=[l.actor,l.role,l.action,l.target_type,l.target_id,l.customer_name,l.details].join(" ").toLowerCase();return(!q||hay.includes(q))&&(!action||String(l.action)===action)});if(!rows.length){tbody.innerHTML='<tr><td colspan="6" class="empty">Tidak ada log yang cocok.</td></tr>';return}tbody.innerHTML=rows.map(l=>'<tr><td>'+esc(formatDate(l.created_at))+'</td><td><strong>'+esc(l.actor||"-")+'</strong><br><span class="badge badge-neutral">'+esc(String(l.role||"-").toUpperCase())+'</span></td><td><span class="badge badge-active">'+esc(auditLabel(l.action))+'</span></td><td>'+esc((l.target_type||"-")+" #"+(l.target_id??"-"))+'</td><td>'+esc(l.customer_name||"-")+'</td><td style="min-width:320px;white-space:normal;line-height:1.5">'+auditDetail(l.details)+'</td></tr>').join("")}
function renderOverview(){const rows=adminState.licenses,total=rows.length;const active=rows.filter(l=>String(l.status).toLowerCase()==="active").length,expired=rows.filter(l=>String(l.status).toLowerCase()==="expired").length,banned=rows.filter(l=>["banned","revoked"].includes(String(l.status).toLowerCase())).length,unactivated=rows.filter(l=>!l.hardware_id).length,online=rows.filter(l=>["presence-online","presence-idle"].includes(activityInfo(l.last_seen_at).cls)).length;const soon=rows.filter(l=>{const t=new Date(l.expires_at).getTime();return Number.isFinite(t)&&t>Date.now()&&t-(Date.now()+serverOffset)<=7*86400000}).length;document.getElementById("kpiTotal").textContent=total;document.getElementById("kpiActive").textContent=active;document.getElementById("kpiExpired").textContent=expired;document.getElementById("kpiBanned").textContent=banned;document.getElementById("kpiUnactivated").textContent=unactivated;document.getElementById("kpiOnline").textContent=online;document.getElementById("healthActive").textContent=active;document.getElementById("healthExpired").textContent=expired;document.getElementById("healthBanned").textContent=banned;document.getElementById("healthUnactivated").textContent=unactivated;document.getElementById("recentActive").textContent=online;document.getElementById("expiringSoon").textContent=soon;document.getElementById("auditCount").textContent=adminState.audit.length;const pct=total?Math.round(((total-unactivated)/total)*100):0;document.getElementById("activationPct").textContent=pct+"%";document.getElementById("activationBar").style.width=pct+"%";}
function toCsv(rows,headers){const enc=v=>'"'+String(v??"").replaceAll('"','""')+'"';return headers.map(enc).join(",")+"\\n"+rows.map(r=>headers.map(h=>enc(r[h])).join(",")).join("\\n")}
function downloadCsv(name,content){const blob=new Blob([content],{type:"text/csv;charset=utf-8"}),a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
function exportLicensesCSV(){const rows=filteredLicenses();const headers=["id","license_key","customer_name","status","expires_at","hardware_id","activated_at","last_seen_at","last_tool","last_version"];downloadCsv("licenses_admin.csv",toCsv(rows,headers));toast("CSV license berhasil dibuat")}
function exportAuditCSV(){const headers=["created_at","actor","role","action","target_type","target_id","customer_name","details","ip_address"];downloadCsv("audit_admin.csv",toCsv(adminState.audit,headers));toast("CSV audit berhasil dibuat")}
document.addEventListener("keydown",e=>{if(e.key==="Enter"&&document.activeElement?.id==="adminPassword")adminLogin()});setInterval(updateServerClock,1000);setInterval(updateCountdowns,1000);syncServerClock();
</script>
</body>
</html>`;


// ============================================================
// AUDIT LOG / ACTIVITY HISTORY
// ============================================================
// Mencatat perubahan penting Owner/Admin secara persisten di D1.
// Password, token, dan license key lengkap TIDAK pernah disimpan di log.
let auditSchemaPromise = null;

async function ensureAuditSchema(env) {
  if (!env.DB) return;
  if (!auditSchemaPromise) {
    auditSchemaPromise = (async () => {
      await env.DB.prepare(`
        CREATE TABLE IF NOT EXISTS audit_logs (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          actor TEXT NOT NULL,
          role TEXT NOT NULL,
          action TEXT NOT NULL,
          target_type TEXT,
          target_id INTEGER,
          customer_name TEXT,
          details TEXT,
          ip_address TEXT,
          created_at TEXT NOT NULL
        )
      `).run();
      await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON audit_logs(created_at DESC)`).run();
      await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_audit_logs_target ON audit_logs(target_type, target_id)`).run();
      await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_audit_logs_actor ON audit_logs(actor)`).run();
    })().catch(error => {
      auditSchemaPromise = null;
      throw error;
    });
  }
  await auditSchemaPromise;
}

function auditClientIP(request) {
  return String(
    request.headers.get("CF-Connecting-IP") ||
    request.headers.get("X-Forwarded-For") ||
    "unknown"
  ).split(",")[0].trim().substring(0, 64);
}

function maskLicenseKey(value) {
  const s = String(value || "");
  if (s.length <= 10) return s ? "••••" : "-";
  return s.substring(0, 8) + "••••" + s.substring(s.length - 5);
}

async function auditActor(request, env) {
  if (await ownerTokenAuth(request, env)) return { actor: "OWNER", role: "owner" };
  const session = await getAdminSession(request, env);
  if (session) return { actor: String(session.username || "ADMIN"), role: String(session.role || "admin") };
  return { actor: "SYSTEM", role: "system" };
}

async function writeAuditLog(env, request, action, targetType = null, targetId = null, customerName = null, details = {}) {
  try {
    await ensureAuditSchema(env);
    const who = await auditActor(request, env);
    await env.DB.prepare(`
      INSERT INTO audit_logs
      (actor, role, action, target_type, target_id, customer_name, details, ip_address, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      who.actor,
      who.role,
      String(action).substring(0, 80),
      targetType ? String(targetType).substring(0, 40) : null,
      Number.isInteger(Number(targetId)) ? Number(targetId) : null,
      customerName ? String(customerName).substring(0, 100) : null,
      JSON.stringify(details || {}).substring(0, 4000),
      auditClientIP(request),
      nowISO()
    ).run();
  } catch (error) {
    console.error("AUDIT_LOG_ERROR", error);
  }
}

function auditActionLabel(action) {
  const labels = {
    LICENSE_CREATE: "Buat License",
    LICENSE_EXTEND: "Perpanjang License",
    LICENSE_RESET: "Reset Device",
    LICENSE_BAN: "Ban License",
    LICENSE_UNBAN: "Aktifkan License",
    LICENSE_DELETE: "Hapus License",
    LICENSE_ACTIVATE: "Aktivasi License",
    ADMIN_CREATE: "Buat Admin",
    ADMIN_DELETE: "Hapus Admin",
    ADMIN_BOOTSTRAP: "Buat Admin Pertama",
    ADMIN_LOGIN: "Login Admin",
    ADMIN_LOGOUT: "Logout Admin"
  };
  return labels[action] || action;
}

let presenceSchemaPromise = null;

async function ensurePresenceSchema(env) {

  if (!env.DB) return;

  if (!presenceSchemaPromise) {

    presenceSchemaPromise = (async () => {

      const info = await env.DB
        .prepare("PRAGMA table_info(licenses)")
        .all();

      const existing = new Set(
        (info.results || []).map(row => String(row.name))
      );

      const columns = [
        ["last_seen_at", "TEXT"],
        ["last_tool", "TEXT"],
        ["last_version", "TEXT"]
      ];

      for (const [name, type] of columns) {
        if (!existing.has(name)) {
          await env.DB
            .prepare(`ALTER TABLE licenses ADD COLUMN ${name} ${type}`)
            .run();
        }
      }

      await env.DB
        .prepare(`
          CREATE INDEX IF NOT EXISTS idx_licenses_last_seen_at
          ON licenses(last_seen_at)
        `)
        .run();

    })().catch(error => {
      presenceSchemaPromise = null;
      throw error;
    });

  }

  await presenceSchemaPromise;
}

// ============================================================
// PRESENCE SCHEMA CHECK (READ-ONLY)
// ============================================================
// Dipakai oleh /owner/list agar login Owner TIDAK pernah tertahan
// oleh ALTER TABLE. Jika kolom belum ada, daftar license tetap bisa
// dimuat dan kolom aktivitas akan kosong sampai client melakukan
// /validate atau /heartbeat.

async function getPresenceColumns(db) {

  try {

    const info = await db
      .prepare("PRAGMA table_info(licenses)")
      .all();

    const existing = new Set(
      (info.results || []).map(row => String(row.name || ""))
    );

    return {
      lastSeen: existing.has("last_seen_at"),
      tool: existing.has("last_tool"),
      version: existing.has("last_version")
    };

  } catch (error) {

    console.error("PRESENCE_SCHEMA_CHECK_ERROR", error);

    return {
      lastSeen: false,
      tool: false,
      version: false
    };

  }
}

// ============================================================
// CLIENT MESSAGE / BROADCAST
// ============================================================
let messageSchemaPromise = null;
async function ensureMessageSchema(env) {
  if (!env.DB) throw new Error("DB belum dikonfigurasi");
  if (!messageSchemaPromise) {
    messageSchemaPromise = (async () => {
      await env.DB.prepare(`CREATE TABLE IF NOT EXISTS client_messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        target_type TEXT NOT NULL DEFAULT 'online',
        target_license_id INTEGER,
        type TEXT NOT NULL DEFAULT 'info',
        title TEXT NOT NULL,
        body TEXT NOT NULL,
        sticky INTEGER NOT NULL DEFAULT 0,
        active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL,
        expires_at TEXT
      )`).run();
      await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_client_messages_active ON client_messages(active, created_at)`).run();
      await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_client_messages_target ON client_messages(target_type, target_license_id)`).run();
    })().catch(error => { messageSchemaPromise = null; throw error; });
  }
  await messageSchemaPromise;
}
function normalizeMessageType(v){const t=String(v||"info").toLowerCase();return ["info","update","warning","urgent"].includes(t)?t:"info"}
async function getClientMessages(env, licenseId, limit=20, deactivateExpired=true){
  await ensureMessageSchema(env);
  const now=nowISO();
  if (deactivateExpired) await env.DB.prepare(`UPDATE client_messages SET active=0 WHERE active=1 AND expires_at IS NOT NULL AND expires_at <= ?`).bind(now).run();
  const result=await env.DB.prepare(`SELECT id,target_type,target_license_id,type,title,body,sticky,created_at,expires_at FROM client_messages WHERE active=1 AND (target_type='all' OR target_type='online' OR (target_type='license' AND target_license_id=?)) AND (expires_at IS NULL OR expires_at > ?) ORDER BY id DESC LIMIT ?`).bind(Number(licenseId),now,limit).all();
  return result.results || [];
}

function messageSnapshot(messages) {
  return JSON.stringify((messages || []).map(m => ({
    id: Number(m.id),
    active: Number(m.active ?? 1),
    sticky: Number(m.sticky || 0),
    type: String(m.type || "info"),
    title: String(m.title || ""),
    body: String(m.body || ""),
    created_at: String(m.created_at || ""),
    expires_at: m.expires_at || null
  })));
}

function sseFrame(event, data, id) {
  const lines = [];
  if (id !== undefined && id !== null) lines.push(`id: ${id}`);
  if (event) lines.push(`event: ${event}`);
  const payload = JSON.stringify(data);
  for (const line of payload.split("\n")) lines.push(`data: ${line}`);
  return lines.join("\n") + "\n\n";
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function authenticateClientMessageRequest(env, body) {
  const licenseKey = normalize(body?.license_key);
  const hardwareId = normalize(body?.hardware_id);
  if (!licenseKey || !hardwareId) return { error: json({ok:false,error:"LICENSE_KEY_AND_HARDWARE_ID_REQUIRED"},400) };

  const license = await env.DB.prepare(`SELECT id,status,expires_at,hardware_id FROM licenses WHERE license_key=? LIMIT 1`).bind(licenseKey).first();
  if (!license) return { error: json({ok:false,error:"LICENSE_NOT_FOUND"},404) };
  if (license.status !== "active") return { error: json({ok:false,error:"LICENSE_NOT_ACTIVE"},403) };
  if (!license.hardware_id || normalize(license.hardware_id) !== hardwareId) return { error: json({ok:false,error:"HARDWARE_MISMATCH"},403) };
  const expiry = new Date(license.expires_at).getTime();
  if (!Number.isFinite(expiry) || expiry <= Date.now()) return { error: json({ok:false,error:"LICENSE_EXPIRED"},403) };

  return { license, licenseKey, hardwareId };
}

async function touchClientPresence(env, licenseId, body) {
  try {
    await ensurePresenceSchema(env);
    await env.DB.prepare(`UPDATE licenses SET last_seen_at=?,last_tool=COALESCE(?,last_tool),last_version=COALESCE(?,last_version) WHERE id=?`)
      .bind(nowISO(), normalize(body?.tool)||null, normalize(body?.version)||null, licenseId).run();
  } catch (e) {
    console.error("message presence update failed", e);
  }
}

async function streamClientMessages(env, license, body, request) {
  const encoder = new TextEncoder();
  const startedAt = Date.now();
  const maxLifetime = 25000;
  const interval = 1000;
  const initialMessages = await getClientMessages(env, license.id, 20, false);
  let lastSnapshot = messageSnapshot(initialMessages);
  let lastId = Number(initialMessages[0]?.id || 0);

  const stream = new ReadableStream({
    async start(controller) {
      let closed = false;
      const close = () => {
        if (closed) return;
        closed = true;
        try { controller.close(); } catch (_) {}
      };
      try {
        controller.enqueue(encoder.encode(`retry: 1000\n\n`));
        controller.enqueue(encoder.encode(sseFrame("ready", {ok:true,server_time:nowISO()})));

        while (!closed && Date.now() - startedAt < maxLifetime) {
          await sleep(interval);
          if (closed) break;
          const messages = await getClientMessages(env, license.id, 20, false);
          const snapshot = messageSnapshot(messages);
          if (snapshot !== lastSnapshot) {
            lastSnapshot = snapshot;
            const newestId = Number(messages[0]?.id || 0);
            if (newestId > lastId) lastId = newestId;
            controller.enqueue(encoder.encode(sseFrame("messages", {ok:true,messages,server_time:nowISO()}, lastId || undefined)));
          } else {
            // Keep the connection alive through proxies and Workers.
            controller.enqueue(encoder.encode(`: heartbeat ${Date.now()}\n\n`));
          }
        }
      } catch (e) {
        console.error("client message stream failed", e);
        try { controller.enqueue(encoder.encode(sseFrame("error", {ok:false,error:"STREAM_ERROR"}))); } catch (_) {}
      } finally {
        close();
      }
    },
    cancel() {}
  });

  return new Response(stream, {
    status: 200,
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-store, must-revalidate",
      "Pragma": "no-cache",
      "Connection": "keep-alive",
      "X-Accel-Buffering": "no",
      ...CORS
    }
  });
}

// ============================================================
// WORKER
// ============================================================

export default {

  async fetch(
    request,
    env
  ) {

    // ========================================================
    // CORS
    // ========================================================

    if (
      request.method ===
      "OPTIONS"
    ) {

      return new Response(
        null,
        {
          status:
            204,

          headers:
            CORS
        }
      );

    }

    const url =
      new URL(
        request.url
      );

    const path =
      url.pathname;

    try {

      // ======================================================
      // OWNER PANEL
      // ======================================================

      if (
        path === "/owner" &&
        request.method === "GET"
      ) {

        return html(
          OWNER_HTML
        );

      }

      // ======================================================
      // ADMIN PANEL
      // ======================================================

      if (
        path === "/admin" &&
        request.method === "GET"
      ) {

        return html(
          ADMIN_HTML
        );

      }

      // ======================================================
      // HEALTH
      // ======================================================

      if (
        path === "/" &&
        request.method === "GET"
      ) {

        const serverTime =
          nowISO();

        return json({

          ok:
            true,

          service:
            "Tools Cloud License",

          version:
            VERSION,

          timezone:
            WIB_TIMEZONE,

          server_time:
            serverTime,

          server_time_wib:
            formatWIB(
              serverTime
            )

        });

      }

      // ======================================================
      // SERVER TIME
      // ======================================================

      if (
        path === "/server-time" &&
        request.method === "GET"
      ) {

        const utc =
          nowISO();

        return json({

          ok:
            true,

          utc:
            utc,

          wib:
            formatWIB(
              utc
            ),

          timezone:
            WIB_TIMEZONE,

          unix:
            Date.now()

        });

      }

      // ======================================================
      // ADMIN LOGIN / LOGOUT / MANAGEMENT
      // ======================================================

      if (path === "/owner/login" && request.method === "POST") {
        const limited = rateLimitOwner(request);
        if (limited) return limited;
        await ensureAdminSchema(env);

        let body;
        try { body = await request.json(); } catch {
          return json({ ok: false, error: "INVALID_JSON" }, 400);
        }

        const username = String(body.username || "").trim().toLowerCase().substring(0, 64);
        const password = String(body.password || "");
        if (!username || !password) return json({ ok: false, error: "USERNAME_PASSWORD_REQUIRED" }, 400);

        // Kompatibilitas akun lama: username dicocokkan tanpa membedakan huruf besar/kecil.
        const admin = await env.DB.prepare(`SELECT id, username, password_hash, role, active FROM admin_users WHERE LOWER(username) = ? LIMIT 1`).bind(username).first();
        if (!admin) {
          return json({ ok: false, error: "INVALID_USERNAME", message: "Akun Admin tidak ditemukan." }, 401);
        }
        if (Number(admin.active) !== 1) {
          return json({ ok: false, error: "ADMIN_INACTIVE", message: "Akun Admin sedang nonaktif." }, 401);
        }
        if (!(await verifyAdminPassword(password, admin.password_hash))) {
          return json({ ok: false, error: "INVALID_PASSWORD", message: "Password Admin tidak sesuai." }, 401);
        }

        const session = await signAdminSession(admin.username, admin.role, env);
        await writeAuditLog(env, request, "ADMIN_LOGIN", "admin", admin.id, null, { username: admin.username, role: admin.role });
        return new Response(JSON.stringify({ ok: true, username: admin.username, role: admin.role, expires_in: ADMIN_SESSION_TTL_SECONDS }), {
          status: 200,
          headers: {
            "Content-Type": "application/json; charset=utf-8",
            "Cache-Control": "no-store",
            "Set-Cookie": sessionCookie(session),
            ...CORS
          }
        });
      }

      if (path === "/owner/logout" && request.method === "POST") {
        return new Response(JSON.stringify({ ok: true }), {
          status: 200,
          headers: {
            "Content-Type": "application/json; charset=utf-8",
            "Cache-Control": "no-store",
            "Set-Cookie": sessionCookie("", 0),
            ...CORS
          }
        });
      }

      if (path === "/owner/admin/bootstrap" && request.method === "POST") {
        const limited = rateLimitOwner(request);
        if (limited) return limited;
        if (!(await ownerTokenAuth(request, env))) return json({ ok: false, error: "OWNER_TOKEN_REQUIRED" }, 401);
        await ensureAdminSchema(env);
        const count = await env.DB.prepare(`SELECT COUNT(*) AS count FROM admin_users`).first();
        if (Number(count?.count || 0) > 0) return json({ ok: false, error: "ADMIN_ALREADY_INITIALIZED" }, 409);

        let body;
        try { body = await request.json(); } catch { return json({ ok: false, error: "INVALID_JSON" }, 400); }
        const username = String(body.username || "").trim().toLowerCase().substring(0, 64);
        const password = String(body.password || "");
        if (!/^[a-z0-9._-]{3,64}$/.test(username)) return json({ ok: false, error: "INVALID_USERNAME" }, 400);
        if (password.length < 10 || password.length > 200) return json({ ok: false, error: "PASSWORD_MIN_10" }, 400);
        const now = nowISO();
        const hash = await hashAdminPassword(password);
        const created = await env.DB.prepare(`INSERT INTO admin_users (username, password_hash, role, active, created_at, updated_at) VALUES (?, ?, 'admin', 1, ?, ?)`).bind(username, hash, now, now).run();
        await writeAuditLog(env, request, "ADMIN_BOOTSTRAP", "admin", created.meta?.last_row_id || null, null, { username, role: "admin" });
        return json({ ok: true, username, role: "admin", message: "Admin pertama berhasil dibuat" });
      }

      if (path === "/owner/admin/create" && request.method === "POST") {
        const limited = rateLimitOwner(request);
        if (limited) return limited;
        if (!(await ownerTokenAuth(request, env))) return json({ ok: false, error: "OWNER_TOKEN_REQUIRED" }, 401);
        await ensureAdminSchema(env);
        let body;
        try { body = await request.json(); } catch { return json({ ok: false, error: "INVALID_JSON" }, 400); }
        const username = String(body.username || "").trim().toLowerCase().substring(0, 64);
        const password = String(body.password || "");
        const role = body.role === "viewer" ? "viewer" : "admin";
        if (!/^[a-z0-9._-]{3,64}$/.test(username)) return json({ ok: false, error: "INVALID_USERNAME" }, 400);
        if (password.length < 10 || password.length > 200) return json({ ok: false, error: "PASSWORD_MIN_10" }, 400);
        const exists = await env.DB.prepare(`SELECT id FROM admin_users WHERE username = ? LIMIT 1`).bind(username).first();
        if (exists) return json({ ok: false, error: "USERNAME_EXISTS" }, 409);
        const now = nowISO();
        const hash = await hashAdminPassword(password);
        const created = await env.DB.prepare(`INSERT INTO admin_users (username, password_hash, role, active, created_at, updated_at) VALUES (?, ?, ?, 1, ?, ?)`).bind(username, hash, role, now, now).run();
        await writeAuditLog(env, request, "ADMIN_CREATE", "admin", created.meta?.last_row_id || null, null, { username, role });
        return json({ ok: true, username, role });
      }

      if (path === "/owner/admin/list" && request.method === "GET") {
        const limited = rateLimitOwner(request);
        if (limited) return limited;
        if (!(await ownerTokenAuth(request, env))) return json({ ok: false, error: "OWNER_TOKEN_REQUIRED" }, 401);
        await ensureAdminSchema(env);
        const result = await env.DB.prepare(`SELECT id, username, role, active, created_at, updated_at FROM admin_users ORDER BY id ASC`).all();
        return json({ ok: true, admins: result.results || [] });
      }

      if (path.startsWith("/owner/admin/delete/") && request.method === "DELETE") {
        const limited = rateLimitOwner(request);
        if (limited) return limited;
        if (!(await ownerTokenAuth(request, env))) return json({ ok: false, error: "OWNER_TOKEN_REQUIRED" }, 401);
        await ensureAdminSchema(env);
        const id = Number(path.split("/").pop());
        if (!Number.isInteger(id) || id <= 0) return json({ ok: false, error: "INVALID_ID" }, 400);
        const count = await env.DB.prepare(`SELECT COUNT(*) AS count FROM admin_users`).first();
        if (Number(count?.count || 0) <= 1) return json({ ok: false, error: "LAST_ADMIN" }, 409);
        const result = await env.DB.prepare(`DELETE FROM admin_users WHERE id = ?`).bind(id).run();
        if ((result.meta?.changes || 0) !== 1) return json({ ok: false, error: "ADMIN_NOT_FOUND" }, 404);
        await writeAuditLog(env, request, "ADMIN_DELETE", "admin", id, null, { admin_id: id });
        return json({ ok: true, message: "Admin dihapus" });
      }
      if (path.startsWith("/owner/admin/update/") && request.method === "POST") {
        const limited = rateLimitOwner(request);
        if (limited) return limited;
        if (!(await ownerTokenAuth(request, env))) return json({ ok: false, error: "OWNER_TOKEN_REQUIRED" }, 401);
        await ensureAdminSchema(env);

        const id = Number(path.split("/").pop());
        if (!Number.isInteger(id) || id <= 0) return json({ ok: false, error: "INVALID_ID" }, 400);

        let body;
        try { body = await request.json(); } catch { return json({ ok: false, error: "INVALID_JSON" }, 400); }

        const admin = await env.DB.prepare(`SELECT id, username, role, active FROM admin_users WHERE id = ? LIMIT 1`).bind(id).first();
        if (!admin) return json({ ok: false, error: "ADMIN_NOT_FOUND" }, 404);

        const role = body.role === undefined ? String(admin.role || "admin") : (body.role === "viewer" ? "viewer" : body.role === "admin" ? "admin" : null);
        if (!role) return json({ ok: false, error: "INVALID_ROLE" }, 400);

        const active = body.active === undefined ? Number(admin.active) : (body.active ? 1 : 0);
        if (![0, 1].includes(active)) return json({ ok: false, error: "INVALID_ACTIVE" }, 400);

        if (active === 0 && Number(admin.active) === 1) {
          const count = await env.DB.prepare(`SELECT COUNT(*) AS count FROM admin_users WHERE active = 1`).first();
          if (Number(count?.count || 0) <= 1) {
            return json({ ok: false, error: "LAST_ACTIVE_ADMIN" }, 409);
          }
        }

        let passwordHash = null;
        if (body.password !== undefined) {
          const password = String(body.password || "");
          if (password.length < 10 || password.length > 200) return json({ ok: false, error: "PASSWORD_MIN_10" }, 400);
          passwordHash = await hashAdminPassword(password);
        }

        const now = nowISO();
        if (passwordHash) {
          await env.DB.prepare(`UPDATE admin_users SET role = ?, active = ?, password_hash = ?, updated_at = ? WHERE id = ?`)
            .bind(role, active, passwordHash, now, id).run();
        } else {
          await env.DB.prepare(`UPDATE admin_users SET role = ?, active = ?, updated_at = ? WHERE id = ?`)
            .bind(role, active, now, id).run();
        }

        await writeAuditLog(env, request, "ADMIN_UPDATE", "admin", id, null, {
          username: admin.username,
          role_from: admin.role,
          role_to: role,
          active_from: Number(admin.active),
          active_to: active,
          password_reset: !!passwordHash
        });

        return json({ ok: true, id, username: admin.username, role, active });
      }


      // ======================================================
      // ADMIN CREATE
      // ======================================================

      if (
        path === "/admin/create" &&
        request.method === "POST"
      ) {

        const limited = rateLimitOwner(request);
        if (limited) return limited;

        if (
          !(await adminAuth(
            request,
            env
          ))
        ) {

          return json(
            {
              ok:
                false,

              error:
                "ADMIN_UNAUTHORIZED"
            },
            401
          );

        }

        if (Number(request.headers.get("Content-Length") || 0) > 16_384) {
          return json({ valid: false, error: "REQUEST_TOO_LARGE" }, 413);
        }

        let body;

        try {

          body =
            await request.json();

        } catch {

          return json(
            {
              ok:
                false,

              error:
                "INVALID_JSON"
            },
            400
          );

        }

        const customer =
          String(
            body.customer_name ||
            "Customer"
          )
            .trim()
            .substring(
              0,
              100
            );

        const requestedDays =
          Number(
            body.days
          );

        const days =
          Number.isFinite(
            requestedDays
          )

            ? Math.max(
                1,
                Math.min(
                  Math.floor(
                    requestedDays
                  ),
                  3650
                )
              )

            : 30;

        const licenseKey =
          generateLicense();

        const createdAt =
          nowISO();

        const expiresAt =
          addDaysISO(
            days
          );

        await env.DB
          .prepare(`
            INSERT INTO licenses
            (
              license_key,
              customer_name,
              status,
              expires_at,
              hardware_id,
              created_at,
              activated_at,
              revoked_at
            )
            VALUES
            (
              ?,
              ?,
              'active',
              ?,
              NULL,
              ?,
              NULL,
              NULL
            )
          `)
          .bind(
            licenseKey,
            customer,
            expiresAt,
            createdAt
          )
          .run();

        await writeAuditLog(env, request, "LICENSE_CREATE", "license", null, customer, { days, license_key: maskLicenseKey(licenseKey) });

        return json({

          ok:
            true,

          license_key:
            licenseKey,

          customer_name:
            customer,

          status:
            "active",

          created_at:
            createdAt,

          created_at_wib:
            formatWIB(
              createdAt
            ),

          expires_at:
            expiresAt,

          expires_at_wib:
            formatWIB(
              expiresAt
            ),

          hardware_id:
            null,

          activated_at:
            null,

          server_time:
            createdAt

        });

      }

      // ======================================================
      
// ADMIN LIST
      // ======================================================

      if (
        path === "/admin/list" &&
        request.method === "GET"
      ) {

        const limited = rateLimitOwner(request);
        if (limited) return limited;

        if (
          !(await adminAuth(
            request,
            env
          ))
        ) {

          return json(
            {
              ok:
                false,

              error:
                "ADMIN_UNAUTHORIZED"
            },
            401
          );

        }

        // PENTING: jangan pakai PRAGMA/ALTER TABLE pada saat login.
        // Coba query lengkap terlebih dahulu. Jika kolom presence belum ada
        // pada database lama, otomatis fallback ke query dasar agar Owner
        // tetap bisa login dan melihat license.
        let licenses = [];

        try {
          const result = await env.DB
            .prepare(`
              SELECT
                id,
                license_key,
                customer_name,
                status,
                expires_at,
                hardware_id,
                created_at,
                activated_at,
                revoked_at,
                last_seen_at,
                last_tool,
                last_version
              FROM licenses
              ORDER BY id DESC
            `)
            .all();

          licenses = result.results || [];

        } catch (presenceQueryError) {
          console.warn("OWNER_LIST_PRESENCE_COLUMNS_UNAVAILABLE", presenceQueryError);

          const result = await env.DB
            .prepare(`
              SELECT
                id,
                license_key,
                customer_name,
                status,
                expires_at,
                hardware_id,
                created_at,
                activated_at,
                revoked_at
              FROM licenses
              ORDER BY id DESC
            `)
            .all();

          licenses = (result.results || []).map(license => ({
            ...license,
            last_seen_at: null,
            last_tool: null,
            last_version: null
          }));
        }

        const serverNow =
          Date.now();

        // Jangan melakukan UPDATE satu-per-satu saat Owner membuka daftar.
        // Ini membuat halaman Owner lambat/stuck bila jumlah license banyak.
        // Status expired dihitung di memory; perubahan database tetap dilakukan
        // oleh endpoint license lain saat diperlukan.
        for (const license of licenses) {
          if (license.status === "active" && license.expires_at) {
            const expiry = new Date(license.expires_at).getTime();
            if (Number.isFinite(expiry) && expiry <= serverNow) {
              license.status = "expired";
            }
          }
        }

        const currentServerTime =
          nowISO();

        return json({

          ok:
            true,

          server_time:
            currentServerTime,

          server_time_wib:
            formatWIB(
              currentServerTime
            ),

          licenses:
            licenses

        });

      }

      // ======================================================
      
// ADMIN EXTEND
      // ======================================================

      if (
        path.startsWith(
          "/admin/extend/"
        ) &&
        request.method === "POST"
      ) {

        const limited = rateLimitOwner(request);
        if (limited) return limited;

        if (
          !(await adminAuth(
            request,
            env
          ))
        ) {

          return json(
            {
              ok:
                false,

              error:
                "ADMIN_UNAUTHORIZED"
            },
            401
          );

        }

        const id =
          Number(
            path
              .split("/")
              .pop()
          );

        if (
          !Number.isInteger(id) ||
          id <= 0
        ) {

          return json(
            {
              ok:
                false,

              error:
                "INVALID_ID"
            },
            400
          );

        }

        if (Number(request.headers.get("Content-Length") || 0) > 16_384) {
          return json({ valid: false, error: "REQUEST_TOO_LARGE" }, 413);
        }

        let body;

        try {

          body =
            await request.json();

        } catch {

          return json(
            {
              ok:
                false,

              error:
                "INVALID_JSON"
            },
            400
          );

        }

        const days =
          Number(
            body.days
          );

        if (
          !Number.isInteger(days) ||
          days < 1 ||
          days > 3650
        ) {

          return json(
            {
              ok:
                false,

              error:
                "INVALID_DAYS"
            },
            400
          );

        }

        const license =
          await env.DB
            .prepare(`
              SELECT
                id,
                license_key,
                customer_name,
                status,
                expires_at,
                hardware_id,
                created_at,
                activated_at,
                revoked_at
              FROM licenses
              WHERE id = ?
              LIMIT 1
            `)
            .bind(
              id
            )
            .first();

        if (!license) {

          return json(
            {
              ok:
                false,

              error:
                "LICENSE_NOT_FOUND"
            },
            404
          );

        }

        // Jangan mengaktifkan kembali
        // license yang direvoke.

        if (
          license.status ===
          "revoked" ||
          license.status ===
          "banned"
        ) {

          return json(
            {
              ok:
                false,

              error:
                "LICENSE_BANNED_CANNOT_EXTEND"
            },
            403
          );

        }

        const serverNow =
          Date.now();

        const currentExpiry =
          new Date(
            license.expires_at
          ).getTime();

        let baseTime =
          serverNow;

        // Jika masih aktif,
        // tambahkan dari tanggal
        // expiry yang lama.

        if (
          Number.isFinite(
            currentExpiry
          ) &&
          currentExpiry >
            serverNow
        ) {

          baseTime =
            currentExpiry;

        }

        const newExpiry =
          addDaysISO(
            days,
            baseTime
          );

        const result =
          await env.DB
            .prepare(`
              UPDATE licenses
              SET
                expires_at = ?,
                status = 'active'
              WHERE
                id = ?
                AND status != 'revoked' AND status != 'banned'
            `)
            .bind(
              newExpiry,
              id
            )
            .run();

        if (
          (result.meta?.changes || 0) !== 1
        ) {

          return json(
            {
              ok:
                false,

              error:
                "LICENSE_UPDATE_FAILED"
            },
            500
          );

        }

        const serverTime =
          nowISO();

        const auditRow = await env.DB.prepare(`SELECT customer_name, expires_at FROM licenses WHERE id = ?`).bind(id).first();
        await writeAuditLog(env, request, "LICENSE_EXTEND", "license", id, auditRow?.customer_name || null, { days, expires_at: auditRow?.expires_at || null });

        return json({

          ok:
            true,

          message:
            "License berhasil diperpanjang",

          license_key:
            license.license_key,

          customer_name:
            license.customer_name,

          status:
            "active",

          old_expires_at:
            license.expires_at,

          old_expires_at_wib:
            formatWIB(
              license.expires_at
            ),

          expires_at:
            newExpiry,

          expires_at_wib:
            formatWIB(
              newExpiry
            ),

          added_days:
            days,

          server_time:
            serverTime,

          server_time_wib:
            formatWIB(
              serverTime
            )

        });

      }

      // ======================================================
      
// ADMIN RESET
      // ======================================================

      if (
        path.startsWith(
          "/admin/reset/"
        ) &&
        request.method === "POST"
      ) {

        const limited = rateLimitOwner(request);
        if (limited) return limited;

        if (
          !(await adminAuth(
            request,
            env
          ))
        ) {

          return json(
            {
              ok:
                false,

              error:
                "ADMIN_UNAUTHORIZED"
            },
            401
          );

        }

        const id =
          Number(
            path
              .split("/")
              .pop()
          );

        if (
          !Number.isInteger(id) ||
          id <= 0
        ) {

          return json(
            {
              ok:
                false,

              error:
                "INVALID_ID"
            },
            400
          );

        }

        const result =
          await env.DB
            .prepare(`
              UPDATE licenses
              SET
                hardware_id = NULL,
                activated_at = NULL
              WHERE id = ?
            `)
            .bind(
              id
            )
            .run();

        if (
          (result.meta?.changes || 0) !== 1
        ) {

          return json(
            {
              ok:
                false,

              error:
                "LICENSE_NOT_FOUND"
            },
            404
          );

        }

        const serverTime =
          nowISO();

        const auditRow = await env.DB.prepare(`SELECT customer_name FROM licenses WHERE id = ?`).bind(id).first();
        await writeAuditLog(env, request, "LICENSE_RESET", "license", id, auditRow?.customer_name || null, { device_reset: true });

        return json({

          ok:
            true,

          message:
            "Device berhasil di-reset",

          server_time:
            serverTime,

          server_time_wib:
            formatWIB(
              serverTime
            )

        });

      }

      // ======================================================
      // ADMIN UNBAN
      // ======================================================

      if (
        path.startsWith("/admin/unban/") &&
        request.method === "POST"
      ) {
        const limited = rateLimitOwner(request);
        if (limited) return limited;
        if (!(await adminAuth(request, env))) {
          return json({ ok:false, error:"ADMIN_UNAUTHORIZED" }, 401);
        }
        const id = Number(path.split("/").pop());
        if (!Number.isInteger(id) || id <= 0) return json({ok:false,error:"INVALID_ID"},400);
        const row = await env.DB.prepare(`SELECT id, status, expires_at FROM licenses WHERE id = ?`).bind(id).first();
        if (!row) return json({ok:false,error:"LICENSE_NOT_FOUND"},404);
        const newStatus = row.expires_at && new Date(row.expires_at).getTime() > Date.now() ? "active" : "expired";
        const result = await env.DB.prepare(`UPDATE licenses SET status = ? WHERE id = ?`).bind(newStatus,id).run();
        if ((result.meta?.changes||0)!==1) return json({ok:false,error:"LICENSE_UPDATE_FAILED"},500);
        const auditRow = await env.DB.prepare(`SELECT customer_name FROM licenses WHERE id = ?`).bind(id).first();
        await writeAuditLog(env, request, "LICENSE_UNBAN", "license", id, auditRow?.customer_name || null, { status: newStatus });
        const t=nowISO();
        return json({ok:true,message:"License berhasil diaktifkan kembali",status:newStatus,server_time:t,server_time_wib:formatWIB(t)});
      }

      // ======================================================
      
// ADMIN BAN
      // ======================================================

      if (
        path.startsWith(
          "/admin/ban/"
        ) &&
        request.method === "POST"
      ) {

        const limited = rateLimitOwner(request);
        if (limited) return limited;

        if (
          !(await adminAuth(
            request,
            env
          ))
        ) {

          return json(
            {
              ok:
                false,

              error:
                "ADMIN_UNAUTHORIZED"
            },
            401
          );

        }

        const id =
          Number(
            path
              .split("/")
              .pop()
          );

        if (
          !Number.isInteger(id) ||
          id <= 0
        ) {

          return json(
            {
              ok:
                false,

              error:
                "INVALID_ID"
            },
            400
          );

        }

        const bannedAt =
          nowISO();

        const result =
          await env.DB
            .prepare(`
              UPDATE licenses
              SET
                status = 'banned',
                revoked_at = ?
              WHERE id = ?
            `)
            .bind(
              bannedAt,
              id
            )
            .run();

        if (
          (result.meta?.changes || 0) !== 1
        ) {

          return json(
            {
              ok:
                false,

              error:
                "LICENSE_NOT_FOUND"
            },
            404
          );

        }

        const auditRow = await env.DB.prepare(`SELECT customer_name, license_key FROM licenses WHERE id = ?`).bind(id).first();
        await writeAuditLog(env, request, "LICENSE_BAN", "license", id, auditRow?.customer_name || null, { license_key: maskLicenseKey(auditRow?.license_key) });

        return json({

          ok:
            true,

          message:
            "License berhasil di-ban",

          revoked_at:
            bannedAt,

          banned_at_wib:
            formatWIB(
              bannedAt
            ),

          server_time:
            bannedAt,

          server_time_wib:
            formatWIB(
              bannedAt
            )

        });

      }

      // ADMIN DELETE DISABLED
      // Admin tidak memiliki hak menghapus license.
      if (path.startsWith("/admin/delete/") && (request.method === "DELETE" || request.method === "POST")) {
        return json({ok:false,error:"ADMIN_DELETE_DISABLED",message:"Admin tidak diizinkan menghapus license."},403);
      }


      // ======================================================
      // OWNER CLIENT MESSAGES
      // ======================================================
      if (path === "/owner/messages" && request.method === "GET") {
        const limited = rateLimitOwner(request); if (limited) return limited;
        if (!(await ownerTokenAuth(request, env))) return json({ok:false,error:"OWNER_UNAUTHORIZED"},401);
        await ensureMessageSchema(env);
        const result = await env.DB.prepare(`SELECT m.id,m.target_type,m.target_license_id,m.type,m.title,m.body,m.sticky,m.active,m.created_at,m.expires_at,l.customer_name,l.license_key FROM client_messages m LEFT JOIN licenses l ON l.id=m.target_license_id ORDER BY m.id DESC LIMIT 100`).all();
        return json({ok:true,messages:result.results||[]});
      }
      if (path === "/owner/messages" && request.method === "POST") {
        const limited = rateLimitOwner(request); if (limited) return limited;
        if (!(await ownerTokenAuth(request, env))) return json({ok:false,error:"OWNER_UNAUTHORIZED"},401);
        await ensureMessageSchema(env);
        let body; try { body=await request.json(); } catch { return json({ok:false,error:"INVALID_JSON"},400); }
        const targetType=["online","all","license"].includes(String(body.target_type||""))?String(body.target_type):"online";
        const targetLicenseId=targetType==="license"?Number(body.target_license_id||0):null;
        if(targetType==="license"&&(!Number.isInteger(targetLicenseId)||targetLicenseId<=0)) return json({ok:false,error:"TARGET_LICENSE_REQUIRED"},400);
        if(targetLicenseId){const l=await env.DB.prepare(`SELECT id FROM licenses WHERE id=? LIMIT 1`).bind(targetLicenseId).first();if(!l)return json({ok:false,error:"LICENSE_NOT_FOUND"},404)}
        const type=normalizeMessageType(body.type),title=String(body.title||"").trim().slice(0,120),messageBody=String(body.body||"").trim().slice(0,2000);
        if(!title||!messageBody)return json({ok:false,error:"MESSAGE_TITLE_AND_BODY_REQUIRED"},400);
        const duration=Math.max(0,Math.min(604800,Number(body.duration_seconds||86400))),sticky=body.sticky?1:0,createdAt=nowISO(),expiresAt=duration>0?new Date(Date.now()+duration*1000).toISOString():null;
        const created=await env.DB.prepare(`INSERT INTO client_messages (target_type,target_license_id,type,title,body,sticky,active,created_at,expires_at) VALUES (?,?,?,?,?,?,?,?,?)`).bind(targetType,targetLicenseId,type,title,messageBody,sticky,1,createdAt,expiresAt).run();
        let onlineCount=0;
        if(targetType==="online"){const r=await env.DB.prepare(`SELECT COUNT(*) AS count FROM licenses WHERE status='active' AND last_seen_at IS NOT NULL AND julianday(last_seen_at) >= julianday(?) - (90.0/86400.0)`).bind(createdAt).first();onlineCount=Number(r?.count||0)}
        if(targetType==="license"){const r=await env.DB.prepare(`SELECT COUNT(*) AS count FROM licenses WHERE id=? AND status='active' AND last_seen_at IS NOT NULL AND julianday(last_seen_at) >= julianday(?) - (90.0/86400.0)`).bind(targetLicenseId,createdAt).first();onlineCount=Number(r?.count||0)}
        await writeAuditLog(env,request,"MESSAGE_SEND","message",created.meta?.last_row_id||null,null,{target_type:targetType,target_license_id:targetLicenseId,type,title,sticky});
        return json({ok:true,id:created.meta?.last_row_id||null,online_count:onlineCount,created_at:createdAt,expires_at:expiresAt});
      }
      if (path.startsWith("/owner/messages/") && request.method === "POST" && path.endsWith("/deactivate")) {
        const limited = rateLimitOwner(request); if (limited) return limited;
        if (!(await ownerTokenAuth(request, env))) return json({ok:false,error:"OWNER_UNAUTHORIZED"},401);
        await ensureMessageSchema(env);
        const id=Number(path.split("/")[3]);
        if(!Number.isInteger(id)||id<=0)return json({ok:false,error:"INVALID_ID"},400);
        const result=await env.DB.prepare(`UPDATE client_messages SET active=0 WHERE id=? AND active=1`).bind(id).run();
        if((result.meta?.changes||0)!==1)return json({ok:false,error:"MESSAGE_NOT_FOUND_OR_ALREADY_INACTIVE"},404);
        await writeAuditLog(env,request,"MESSAGE_DEACTIVATE","message",id,null,{});
        return json({ok:true,active:0});
      }
      if (path.startsWith("/owner/messages/") && request.method === "DELETE") {
        const limited = rateLimitOwner(request); if (limited) return limited;
        if (!(await ownerTokenAuth(request, env))) return json({ok:false,error:"OWNER_UNAUTHORIZED"},401);
        await ensureMessageSchema(env); const id=Number(path.split("/").pop());
        if(!Number.isInteger(id)||id<=0)return json({ok:false,error:"INVALID_ID"},400);
        const exists=await env.DB.prepare(`SELECT id,sticky FROM client_messages WHERE id=? LIMIT 1`).bind(id).first();
        if(!exists)return json({ok:false,error:"MESSAGE_NOT_FOUND"},404);
        if(Number(exists.sticky)===1)return json({ok:false,error:"STICKY_MESSAGE_DELETE_DISABLED",message:"Pesan sticky tidak dapat dihapus."},403);
        const result=await env.DB.prepare(`DELETE FROM client_messages WHERE id=?`).bind(id).run();
        if((result.meta?.changes||0)!==1)return json({ok:false,error:"MESSAGE_DELETE_FAILED"},500);
        await writeAuditLog(env,request,"MESSAGE_DELETE","message",id,null,{permanent:true});
        return json({ok:true,deleted:true});
      }
      // ======================================================
      // CLIENT MESSAGE REALTIME STREAM (SSE over POST)
      // ======================================================
      if (path === "/client/messages/stream" && request.method === "POST") {
        const limited = rateLimitMessageStream(request);
        if (limited) return limited;
        let body; try { body = await request.json(); } catch { return json({ok:false,error:"INVALID_JSON"},400); }
        const auth = await authenticateClientMessageRequest(env, body);
        if (auth.error) return auth.error;
        await touchClientPresence(env, auth.license.id, body);
        return streamClientMessages(env, auth.license, body, request);
      }

      // ======================================================
      // CLIENT MESSAGE INBOX
      // ======================================================
      if (path === "/client/messages" && request.method === "POST") {
        const limited = rateLimitHeartbeat(request); if (limited) return limited;
        let body; try { body=await request.json(); } catch { return json({ok:false,error:"INVALID_JSON"},400); }
        const licenseKey=normalize(body.license_key),hardwareId=normalize(body.hardware_id);
        if(!licenseKey||!hardwareId)return json({ok:false,error:"LICENSE_KEY_AND_HARDWARE_ID_REQUIRED"},400);
        const license=await env.DB.prepare(`SELECT id,status,expires_at,hardware_id FROM licenses WHERE license_key=? LIMIT 1`).bind(licenseKey).first();
        if(!license)return json({ok:false,error:"LICENSE_NOT_FOUND"},404); if(license.status!=="active")return json({ok:false,error:"LICENSE_NOT_ACTIVE"},403);
        if(!license.hardware_id||normalize(license.hardware_id)!==hardwareId)return json({ok:false,error:"HARDWARE_MISMATCH"},403);
        const expiry=new Date(license.expires_at).getTime(); if(!Number.isFinite(expiry)||expiry<=Date.now())return json({ok:false,error:"LICENSE_EXPIRED"},403);
        try { await ensurePresenceSchema(env); await env.DB.prepare(`UPDATE licenses SET last_seen_at=?,last_tool=COALESCE(?,last_tool),last_version=COALESCE(?,last_version) WHERE id=?`).bind(nowISO(),normalize(body.tool)||null,normalize(body.version)||null,license.id).run(); } catch(e){ console.error("message presence update failed",e); }
        return json({ok:true,valid:true,messages:await getClientMessages(env,license.id,20),server_time:nowISO()});
      }

      // ======================================================
      // AUDIT LOGS
      // ======================================================
      if (path === "/owner/audit-actors" && request.method === "GET") {
        const limited = rateLimitOwner(request);
        if (limited) return limited;
        if (!(await ownerTokenAuth(request, env))) return json({ ok:false, error:"OWNER_UNAUTHORIZED" },401);
        await ensureAuditSchema(env);
        const result = await env.DB.prepare(`
          SELECT actor, COUNT(*) AS count
          FROM audit_logs
          WHERE LOWER(role) = 'admin'
          GROUP BY actor
          ORDER BY actor ASC
        `).all();
        return json({ ok:true, actors: result.results || [] });
      }

      if (path === "/owner/audit-logs" && request.method === "GET") {
        const limited = rateLimitOwner(request);
        if (limited) return limited;
        if (!(await ownerTokenAuth(request, env))) return json({ ok:false, error:"OWNER_UNAUTHORIZED" },401);
        await ensureAuditSchema(env);
        const limit = Math.min(200, Math.max(1, Number(url.searchParams.get("limit") || 100)));
        const actor = String(url.searchParams.get("actor") || "").trim().substring(0,64);
        let result;
        if (actor) {
          result = await env.DB.prepare(`
            SELECT id, actor, role, action, target_type, target_id, customer_name, details, ip_address, created_at
            FROM audit_logs WHERE actor = ? ORDER BY id DESC LIMIT ?
          `).bind(actor, limit).all();
        } else {
          result = await env.DB.prepare(`
            SELECT id, actor, role, action, target_type, target_id, customer_name, details, ip_address, created_at
            FROM audit_logs ORDER BY id DESC LIMIT ?
          `).bind(limit).all();
        }
        return json({ ok:true, logs: result.results || [] });
      }

      if (path === "/admin/audit-logs" && request.method === "GET") {
        const limited = rateLimitOwner(request);
        if (limited) return limited;
        if (!(await adminAuth(request, env))) return json({ ok:false, error:"ADMIN_UNAUTHORIZED" },401);
        await ensureAuditSchema(env);
        const limit = Math.min(200, Math.max(1, Number(url.searchParams.get("limit") || 100)));
        const result = await env.DB.prepare(`
          SELECT id, actor, role, action, target_type, target_id, customer_name, details, ip_address, created_at
          FROM audit_logs ORDER BY id DESC LIMIT ?
        `).bind(limit).all();
        return json({ ok:true, logs: result.results || [] });
      }

      // ======================================================
      // ACTIVATE
      // ======================================================

      if (
        path === "/activate" &&
        request.method === "POST"
      ) {

        let body;

        try {

          body =
            await request.json();

        } catch {

          return json(
            {
              ok:
                false,

              error:
                "INVALID_JSON"
            },
            400
          );

        }

        const licenseKey =
          normalize(
            body.license_key
          );

        const hardwareId =
          normalize(
            body.hardware_id
          );

        if (
          !licenseKey ||
          !hardwareId
        ) {

          return json(
            {
              ok:
                false,

              error:
                "LICENSE_KEY_AND_HARDWARE_ID_REQUIRED"
            },
            400
          );

        }

        const license =
          await env.DB
            .prepare(`
              SELECT *
              FROM licenses
              WHERE license_key = ?
              LIMIT 1
            `)
            .bind(
              licenseKey
            )
            .first();

        if (!license) {

          return json(
            {
              ok:
                false,

              error:
                "LICENSE_NOT_FOUND"
            },
            404
          );

        }

        // ----------------------------------------------------
        // REVOKED
        // ----------------------------------------------------

        if (
          license.status ===
          "revoked" ||
          license.status ===
          "banned"
        ) {

          return json(
            {
              ok:
                false,

              error:
                "LICENSE_BANNED",

              server_time:
                nowISO()
            },
            403
          );

        }

        // ----------------------------------------------------
        // EXPIRED
        // ----------------------------------------------------

        const expiresTime =
          new Date(
            license.expires_at
          ).getTime();

        const serverNow =
          Date.now();

        if (
          !Number.isFinite(
            expiresTime
          ) ||
          expiresTime <=
            serverNow
        ) {

          await env.DB
            .prepare(`
              UPDATE licenses
              SET status = 'expired'
              WHERE id = ?
            `)
            .bind(
              license.id
            )
            .run();

          const serverTime =
            nowISO();

          return json(
            {
              ok:
                false,

              error:
                "LICENSE_EXPIRED",

              server_time:
                serverTime,

              server_time_wib:
                formatWIB(
                  serverTime
                )
            },
            403
          );

        }

        // ----------------------------------------------------
        // SAME DEVICE
        // ----------------------------------------------------

        if (
          license.hardware_id &&
          normalize(
            license.hardware_id
          ) === hardwareId
        ) {

          const serverTime =
            nowISO();

          return json({

            ok:
              true,

            activated:
              false,

            message:
              "LICENSE_VALID",

            license_key:
              license.license_key,

            customer_name:
              license.customer_name,

            status:
              "active",

            hardware_id:
              license.hardware_id,

            created_at:
              license.created_at,

            activated_at:
              license.activated_at,

            expires_at:
              license.expires_at,

            revoked_at:
              license.revoked_at,

            server_time:
              serverTime,

            activated_at_wib:
              formatWIB(
                license.activated_at
              ),

            expires_at_wib:
              formatWIB(
                license.expires_at
              )

          });

        }

        // ----------------------------------------------------
        // DIFFERENT DEVICE
        // ----------------------------------------------------

        if (
          license.hardware_id &&
          normalize(
            license.hardware_id
          ) !== hardwareId
        ) {

          return json(
            {
              ok:
                false,

              error:
                "LICENSE_ALREADY_BOUND_TO_ANOTHER_PC",

              server_time:
                nowISO()
            },
            403
          );

        }

        // ----------------------------------------------------
        // FIRST DEVICE
        // ----------------------------------------------------

        const activatedAt =
          nowISO();

        const result =
          await env.DB
            .prepare(`
              UPDATE licenses
              SET
                hardware_id = ?,
                activated_at = ?
              WHERE
                id = ?
                AND hardware_id IS NULL
                AND status = 'active'
                AND expires_at > ?
            `)
            .bind(
              hardwareId,
              activatedAt,
              license.id,
              activatedAt
            )
            .run();

        // ----------------------------------------------------
        // SUCCESS
        // ----------------------------------------------------

        if (
          (result.meta?.changes || 0) === 1
        ) {

          const activated =
            await env.DB
              .prepare(`
                SELECT
                  license_key,
                  customer_name,
                  status,
                  expires_at,
                  hardware_id,
                  created_at,
                  activated_at,
                  revoked_at
                FROM licenses
                WHERE id = ?
                LIMIT 1
              `)
              .bind(
                license.id
              )
              .first();

          const serverTime =
            nowISO();

          await writeAuditLog(env, request, "LICENSE_ACTIVATE", "license", license.id, activated?.customer_name || license.customer_name || null, {
            hardware_id: maskLicenseKey(hardwareId),
            license_key: maskLicenseKey(activated?.license_key || licenseKey),
            activated_at: activated?.activated_at || activatedAt
          });

          return json({

            ok:
              true,

            activated:
              true,

            message:
              "LICENSE_ACTIVATED",

            license_key:
              activated.license_key,

            customer_name:
              activated.customer_name,

            status:
              activated.status,

            hardware_id:
              activated.hardware_id,

            created_at:
              activated.created_at,

            activated_at:
              activated.activated_at,

            expires_at:
              activated.expires_at,

            revoked_at:
              activated.revoked_at,

            server_time:
              serverTime,

            activated_at_wib:
              formatWIB(
                activated.activated_at
              ),

            expires_at_wib:
              formatWIB(
                activated.expires_at
              )

          });

        }

        // ----------------------------------------------------
        // RACE CONDITION FALLBACK
        // ----------------------------------------------------

        const current =
          await env.DB
            .prepare(`
              SELECT *
              FROM licenses
              WHERE id = ?
              LIMIT 1
            `)
            .bind(
              license.id
            )
            .first();

        if (
          current &&
          normalize(
            current.hardware_id
          ) === hardwareId &&
          current.status ===
            "active"
        ) {

          const serverTime =
            nowISO();

          return json({

            ok:
              true,

            activated:
              false,

            message:
              "LICENSE_VALID",

            license_key:
              current.license_key,

            customer_name:
              current.customer_name,

            status:
              current.status,

            hardware_id:
              current.hardware_id,

            created_at:
              current.created_at,

            activated_at:
              current.activated_at,

            expires_at:
              current.expires_at,

            revoked_at:
              current.revoked_at,

            server_time:
              serverTime,

            activated_at_wib:
              formatWIB(
                current.activated_at
              ),

            expires_at_wib:
              formatWIB(
                current.expires_at
              )

          });

        }

        return json(
          {
            ok:
              false,

            error:
              "LICENSE_ALREADY_BOUND_TO_ANOTHER_PC",

            server_time:
              nowISO()
          },
          403
        );

      }

      // ======================================================
      
// OWNER CREATE
      // ======================================================

      if (
        path === "/owner/create" &&
        request.method === "POST"
      ) {

        const limited = rateLimitOwner(request);
        if (limited) return limited;

        if (
          !(await ownerAuth(
            request,
            env
          ))
        ) {

          return json(
            {
              ok:
                false,

              error:
                "OWNER_UNAUTHORIZED"
            },
            401
          );

        }

        if (Number(request.headers.get("Content-Length") || 0) > 16_384) {
          return json({ valid: false, error: "REQUEST_TOO_LARGE" }, 413);
        }

        let body;

        try {

          body =
            await request.json();

        } catch {

          return json(
            {
              ok:
                false,

              error:
                "INVALID_JSON"
            },
            400
          );

        }

        const customer =
          String(
            body.customer_name ||
            "Customer"
          )
            .trim()
            .substring(
              0,
              100
            );

        const requestedDays =
          Number(
            body.days
          );

        const days =
          Number.isFinite(
            requestedDays
          )

            ? Math.max(
                1,
                Math.min(
                  Math.floor(
                    requestedDays
                  ),
                  3650
                )
              )

            : 30;

        const licenseKey =
          generateLicense();

        const createdAt =
          nowISO();

        const expiresAt =
          addDaysISO(
            days
          );

        await env.DB
          .prepare(`
            INSERT INTO licenses
            (
              license_key,
              customer_name,
              status,
              expires_at,
              hardware_id,
              created_at,
              activated_at,
              revoked_at
            )
            VALUES
            (
              ?,
              ?,
              'active',
              ?,
              NULL,
              ?,
              NULL,
              NULL
            )
          `)
          .bind(
            licenseKey,
            customer,
            expiresAt,
            createdAt
          )
          .run();

        await writeAuditLog(env, request, "LICENSE_CREATE", "license", null, customer, { days, license_key: maskLicenseKey(licenseKey) });

        return json({

          ok:
            true,

          license_key:
            licenseKey,

          customer_name:
            customer,

          status:
            "active",

          created_at:
            createdAt,

          created_at_wib:
            formatWIB(
              createdAt
            ),

          expires_at:
            expiresAt,

          expires_at_wib:
            formatWIB(
              expiresAt
            ),

          hardware_id:
            null,

          activated_at:
            null,

          server_time:
            createdAt

        });

      }

      // ======================================================
      // OWNER LIST
      // ======================================================

      if (
        path === "/owner/list" &&
        request.method === "GET"
      ) {

        const limited = rateLimitOwner(request);
        if (limited) return limited;

        if (
          !(await ownerAuth(
            request,
            env
          ))
        ) {

          return json(
            {
              ok:
                false,

              error:
                "OWNER_UNAUTHORIZED"
            },
            401
          );

        }

        // PENTING: jangan pakai PRAGMA/ALTER TABLE pada saat login.
        // Coba query lengkap terlebih dahulu. Jika kolom presence belum ada
        // pada database lama, otomatis fallback ke query dasar agar Owner
        // tetap bisa login dan melihat license.
        let licenses = [];

        try {
          const result = await env.DB
            .prepare(`
              SELECT
                id,
                license_key,
                customer_name,
                status,
                expires_at,
                hardware_id,
                created_at,
                activated_at,
                revoked_at,
                last_seen_at,
                last_tool,
                last_version
              FROM licenses
              ORDER BY id DESC
            `)
            .all();

          licenses = result.results || [];

        } catch (presenceQueryError) {
          console.warn("OWNER_LIST_PRESENCE_COLUMNS_UNAVAILABLE", presenceQueryError);

          const result = await env.DB
            .prepare(`
              SELECT
                id,
                license_key,
                customer_name,
                status,
                expires_at,
                hardware_id,
                created_at,
                activated_at,
                revoked_at
              FROM licenses
              ORDER BY id DESC
            `)
            .all();

          licenses = (result.results || []).map(license => ({
            ...license,
            last_seen_at: null,
            last_tool: null,
            last_version: null
          }));
        }

        const serverNow =
          Date.now();

        // Jangan melakukan UPDATE satu-per-satu saat Owner membuka daftar.
        // Ini membuat halaman Owner lambat/stuck bila jumlah license banyak.
        // Status expired dihitung di memory; perubahan database tetap dilakukan
        // oleh endpoint license lain saat diperlukan.
        for (const license of licenses) {
          if (license.status === "active" && license.expires_at) {
            const expiry = new Date(license.expires_at).getTime();
            if (Number.isFinite(expiry) && expiry <= serverNow) {
              license.status = "expired";
            }
          }
        }

        const currentServerTime =
          nowISO();

        return json({

          ok:
            true,

          server_time:
            currentServerTime,

          server_time_wib:
            formatWIB(
              currentServerTime
            ),

          licenses:
            licenses

        });

      }

      // ======================================================
      // OWNER EXTEND
      // ======================================================

      if (
        path.startsWith(
          "/owner/extend/"
        ) &&
        request.method === "POST"
      ) {

        const limited = rateLimitOwner(request);
        if (limited) return limited;

        if (
          !(await ownerAuth(
            request,
            env
          ))
        ) {

          return json(
            {
              ok:
                false,

              error:
                "OWNER_UNAUTHORIZED"
            },
            401
          );

        }

        const id =
          Number(
            path
              .split("/")
              .pop()
          );

        if (
          !Number.isInteger(id) ||
          id <= 0
        ) {

          return json(
            {
              ok:
                false,

              error:
                "INVALID_ID"
            },
            400
          );

        }

        if (Number(request.headers.get("Content-Length") || 0) > 16_384) {
          return json({ valid: false, error: "REQUEST_TOO_LARGE" }, 413);
        }

        let body;

        try {

          body =
            await request.json();

        } catch {

          return json(
            {
              ok:
                false,

              error:
                "INVALID_JSON"
            },
            400
          );

        }

        const days =
          Number(
            body.days
          );

        if (
          !Number.isInteger(days) ||
          days < 1 ||
          days > 3650
        ) {

          return json(
            {
              ok:
                false,

              error:
                "INVALID_DAYS"
            },
            400
          );

        }

        const license =
          await env.DB
            .prepare(`
              SELECT
                id,
                license_key,
                customer_name,
                status,
                expires_at,
                hardware_id,
                created_at,
                activated_at,
                revoked_at
              FROM licenses
              WHERE id = ?
              LIMIT 1
            `)
            .bind(
              id
            )
            .first();

        if (!license) {

          return json(
            {
              ok:
                false,

              error:
                "LICENSE_NOT_FOUND"
            },
            404
          );

        }

        // Jangan mengaktifkan kembali
        // license yang direvoke.

        if (
          license.status ===
          "revoked" ||
          license.status ===
          "banned"
        ) {

          return json(
            {
              ok:
                false,

              error:
                "LICENSE_BANNED_CANNOT_EXTEND"
            },
            403
          );

        }

        const serverNow =
          Date.now();

        const currentExpiry =
          new Date(
            license.expires_at
          ).getTime();

        let baseTime =
          serverNow;

        // Jika masih aktif,
        // tambahkan dari tanggal
        // expiry yang lama.

        if (
          Number.isFinite(
            currentExpiry
          ) &&
          currentExpiry >
            serverNow
        ) {

          baseTime =
            currentExpiry;

        }

        const newExpiry =
          addDaysISO(
            days,
            baseTime
          );

        const result =
          await env.DB
            .prepare(`
              UPDATE licenses
              SET
                expires_at = ?,
                status = 'active'
              WHERE
                id = ?
                AND status != 'revoked' AND status != 'banned'
            `)
            .bind(
              newExpiry,
              id
            )
            .run();

        if (
          (result.meta?.changes || 0) !== 1
        ) {

          return json(
            {
              ok:
                false,

              error:
                "LICENSE_UPDATE_FAILED"
            },
            500
          );

        }

        const serverTime =
          nowISO();

        const auditRow = await env.DB.prepare(`SELECT customer_name, expires_at FROM licenses WHERE id = ?`).bind(id).first();
        await writeAuditLog(env, request, "LICENSE_EXTEND", "license", id, auditRow?.customer_name || null, { days, expires_at: auditRow?.expires_at || null });

        return json({

          ok:
            true,

          message:
            "License berhasil diperpanjang",

          license_key:
            license.license_key,

          customer_name:
            license.customer_name,

          status:
            "active",

          old_expires_at:
            license.expires_at,

          old_expires_at_wib:
            formatWIB(
              license.expires_at
            ),

          expires_at:
            newExpiry,

          expires_at_wib:
            formatWIB(
              newExpiry
            ),

          added_days:
            days,

          server_time:
            serverTime,

          server_time_wib:
            formatWIB(
              serverTime
            )

        });

      }

      // ======================================================
      // OWNER EDIT EXPIRY
      // ======================================================
      // Owner dapat mengatur tanggal/jam expired secara langsung.
      // Format input: ISO 8601, misalnya 2026-12-31T23:59:59.000Z
      // Endpoint ini khusus Owner dan tidak mengubah hardware/device.
      if (
        path.startsWith(
          "/owner/edit-expiry/"
        ) &&
        request.method === "POST"
      ) {

        const limited = rateLimitOwner(request);
        if (limited) return limited;

        if (
          !(await ownerAuth(
            request,
            env
          ))
        ) {
          return json(
            {
              ok: false,
              error: "OWNER_UNAUTHORIZED"
            },
            401
          );
        }

        const id =
          Number(
            path
              .split("/")
              .pop()
          );

        if (
          !Number.isInteger(id) ||
          id <= 0
        ) {
          return json(
            {
              ok: false,
              error: "INVALID_ID"
            },
            400
          );
        }

        if (Number(request.headers.get("Content-Length") || 0) > 16_384) {
          return json(
            {
              ok: false,
              error: "REQUEST_TOO_LARGE"
            },
            413
          );
        }

        let body;
        try {
          body = await request.json();
        } catch {
          return json(
            {
              ok: false,
              error: "INVALID_JSON"
            },
            400
          );
        }

        const expiresAtText =
          String(
            body.expires_at || ""
          ).trim();

        const expiryTime =
          new Date(
            expiresAtText
          ).getTime();

        if (
          !expiresAtText ||
          !Number.isFinite(expiryTime)
        ) {
          return json(
            {
              ok: false,
              error: "INVALID_EXPIRES_AT"
            },
            400
          );
        }

        const license =
          await env.DB
            .prepare(`
              SELECT
                id,
                license_key,
                customer_name,
                status,
                expires_at,
                hardware_id,
                created_at,
                activated_at,
                revoked_at
              FROM licenses
              WHERE id = ?
              LIMIT 1
            `)
            .bind(id)
            .first();

        if (!license) {
          return json(
            {
              ok: false,
              error: "LICENSE_NOT_FOUND"
            },
            404
          );
        }

        // Jangan mengubah license yang dibanned/revoked.
        if (
          license.status === "revoked" ||
          license.status === "banned"
        ) {
          return json(
            {
              ok: false,
              error: "LICENSE_BANNED_CANNOT_EDIT_EXPIRY"
            },
            403
          );
        }

        const newExpiry =
          new Date(
            expiryTime
          ).toISOString();

        const result =
          await env.DB
            .prepare(`
              UPDATE licenses
              SET
                expires_at = ?,
                status = 'active'
              WHERE
                id = ?
                AND status != 'revoked'
                AND status != 'banned'
            `)
            .bind(
              newExpiry,
              id
            )
            .run();

        if (
          (result.meta?.changes || 0) !== 1
        ) {
          return json(
            {
              ok: false,
              error: "LICENSE_UPDATE_FAILED"
            },
            500
          );
        }

        const serverTime = nowISO();

        await writeAuditLog(
          env,
          request,
          "LICENSE_EXPIRY_EDIT",
          "license",
          id,
          license.customer_name || null,
          {
            old_expires_at: license.expires_at || null,
            old_expires_at_wib: formatWIB(license.expires_at),
            expires_at: newExpiry,
            expires_at_wib: formatWIB(newExpiry)
          }
        );

        return json({
          ok: true,
          message: "Expired license berhasil diubah",
          license_key: license.license_key,
          customer_name: license.customer_name,
          status: "active",
          old_expires_at: license.expires_at,
          old_expires_at_wib: formatWIB(license.expires_at),
          expires_at: newExpiry,
          expires_at_wib: formatWIB(newExpiry),
          server_time: serverTime,
          server_time_wib: formatWIB(serverTime)
        });
      }

      // ======================================================
      // OWNER RESET
      // ======================================================

      if (
        path.startsWith(
          "/owner/reset/"
        ) &&
        request.method === "POST"
      ) {

        const limited = rateLimitOwner(request);
        if (limited) return limited;

        if (
          !(await ownerAuth(
            request,
            env
          ))
        ) {

          return json(
            {
              ok:
                false,

              error:
                "OWNER_UNAUTHORIZED"
            },
            401
          );

        }

        const id =
          Number(
            path
              .split("/")
              .pop()
          );

        if (
          !Number.isInteger(id) ||
          id <= 0
        ) {

          return json(
            {
              ok:
                false,

              error:
                "INVALID_ID"
            },
            400
          );

        }

        const result =
          await env.DB
            .prepare(`
              UPDATE licenses
              SET
                hardware_id = NULL,
                activated_at = NULL
              WHERE id = ?
            `)
            .bind(
              id
            )
            .run();

        if (
          (result.meta?.changes || 0) !== 1
        ) {

          return json(
            {
              ok:
                false,

              error:
                "LICENSE_NOT_FOUND"
            },
            404
          );

        }

        const serverTime =
          nowISO();

        const auditRow = await env.DB.prepare(`SELECT customer_name FROM licenses WHERE id = ?`).bind(id).first();
        await writeAuditLog(env, request, "LICENSE_RESET", "license", id, auditRow?.customer_name || null, { device_reset: true });

        return json({

          ok:
            true,

          message:
            "Device berhasil di-reset",

          server_time:
            serverTime,

          server_time_wib:
            formatWIB(
              serverTime
            )

        });

      }

      // ======================================================
      // OWNER UNBAN
      // ======================================================

      if (
        path.startsWith("/owner/unban/") &&
        request.method === "POST"
      ) {
        const limited = rateLimitOwner(request);
        if (limited) return limited;
        if (!(await ownerAuth(request, env))) return json({ok:false,error:"OWNER_UNAUTHORIZED"},401);
        const id=Number(path.split("/").pop());
        if (!Number.isInteger(id)||id<=0) return json({ok:false,error:"INVALID_ID"},400);
        const row=await env.DB.prepare(`SELECT id,status,expires_at FROM licenses WHERE id = ?`).bind(id).first();
        if (!row) return json({ok:false,error:"LICENSE_NOT_FOUND"},404);
        const newStatus=row.expires_at && new Date(row.expires_at).getTime()>Date.now()?"active":"expired";
        const result=await env.DB.prepare(`UPDATE licenses SET status = ? WHERE id = ?`).bind(newStatus,id).run();
        if ((result.meta?.changes||0)!==1) return json({ok:false,error:"LICENSE_UPDATE_FAILED"},500);
        const auditRow = await env.DB.prepare(`SELECT customer_name FROM licenses WHERE id = ?`).bind(id).first();
        await writeAuditLog(env, request, "LICENSE_UNBAN", "license", id, auditRow?.customer_name || null, { status: newStatus });
        const t=nowISO();
        return json({ok:true,message:"License berhasil diaktifkan kembali",status:newStatus,server_time:t,server_time_wib:formatWIB(t)});
      }

      // ======================================================
      // OWNER BAN
      // ======================================================

      if (
        path.startsWith(
          "/owner/ban/"
        ) &&
        request.method === "POST"
      ) {

        const limited = rateLimitOwner(request);
        if (limited) return limited;

        if (
          !(await ownerAuth(
            request,
            env
          ))
        ) {

          return json(
            {
              ok:
                false,

              error:
                "OWNER_UNAUTHORIZED"
            },
            401
          );

        }

        const id =
          Number(
            path
              .split("/")
              .pop()
          );

        if (
          !Number.isInteger(id) ||
          id <= 0
        ) {

          return json(
            {
              ok:
                false,

              error:
                "INVALID_ID"
            },
            400
          );

        }

        const bannedAt =
          nowISO();

        const result =
          await env.DB
            .prepare(`
              UPDATE licenses
              SET
                status = 'banned',
                revoked_at = ?
              WHERE id = ?
            `)
            .bind(
              bannedAt,
              id
            )
            .run();

        if (
          (result.meta?.changes || 0) !== 1
        ) {

          return json(
            {
              ok:
                false,

              error:
                "LICENSE_NOT_FOUND"
            },
            404
          );

        }

        const auditRow = await env.DB.prepare(`SELECT customer_name, license_key FROM licenses WHERE id = ?`).bind(id).first();
        await writeAuditLog(env, request, "LICENSE_BAN", "license", id, auditRow?.customer_name || null, { license_key: maskLicenseKey(auditRow?.license_key) });

        return json({

          ok:
            true,

          message:
            "License berhasil di-ban",

          revoked_at:
            bannedAt,

          banned_at_wib:
            formatWIB(
              bannedAt
            ),

          server_time:
            bannedAt,

          server_time_wib:
            formatWIB(
              bannedAt
            )

        });

      }

      // ======================================================
      // OWNER DELETE
      // ======================================================

      if (
        path.startsWith(
          "/owner/delete/"
        ) &&
        (
          request.method ===
            "DELETE" ||
          request.method ===
            "POST"
        )
      ) {

        const limited = rateLimitOwner(request);
        if (limited) return limited;

        if (
          !(await ownerAuth(
            request,
            env
          ))
        ) {

          return json(
            {
              ok:
                false,

              error:
                "OWNER_UNAUTHORIZED"
            },
            401
          );

        }

        const id =
          Number(
            path
              .split("/")
              .pop()
          );

        if (
          !Number.isInteger(id) ||
          id <= 0
        ) {

          return json(
            {
              ok:
                false,

              error:
                "INVALID_ID"
            },
            400
          );

        }

        const license =
          await env.DB
            .prepare(`
              SELECT
                id,
                license_key,
                customer_name,
                status,
                expires_at,
                hardware_id,
                created_at,
                activated_at,
                revoked_at
              FROM licenses
              WHERE id = ?
              LIMIT 1
            `)
            .bind(
              id
            )
            .first();

        if (!license) {

          return json(
            {
              ok:
                false,

              error:
                "LICENSE_NOT_FOUND"
            },
            404
          );

        }

        const result =
          await env.DB
            .prepare(`
              DELETE FROM licenses
              WHERE id = ?
            `)
            .bind(
              id
            )
            .run();

        if (
          (result.meta?.changes || 0) !== 1
        ) {

          return json(
            {
              ok:
                false,

              error:
                "LICENSE_DELETE_FAILED"
            },
            500
          );

        }

        const serverTime =
          nowISO();

        await writeAuditLog(env, request, "LICENSE_DELETE", "license", id, license.customer_name || null, {
          license_key: maskLicenseKey(license.license_key),
          previous_status: license.status,
          previous_expires_at: license.expires_at
        });

        return json({

          ok:
            true,

          message:
            "License berhasil dihapus permanen",

          deleted_id:
            license.id,

          license_key:
            license.license_key,

          customer_name:
            license.customer_name,

          server_time:
            serverTime,

          server_time_wib:
            formatWIB(
              serverTime
            )

        });

      }

      // ======================================================
      // ACTIVATE
      // ======================================================

      if (
        path === "/activate" &&
        request.method === "POST"
      ) {

        let body;

        try {

          body =
            await request.json();

        } catch {

          return json(
            {
              ok:
                false,

              error:
                "INVALID_JSON"
            },
            400
          );

        }

        const licenseKey =
          normalize(
            body.license_key
          );

        const hardwareId =
          normalize(
            body.hardware_id
          );

        if (
          !licenseKey ||
          !hardwareId
        ) {

          return json(
            {
              ok:
                false,

              error:
                "LICENSE_KEY_AND_HARDWARE_ID_REQUIRED"
            },
            400
          );

        }

        const license =
          await env.DB
            .prepare(`
              SELECT *
              FROM licenses
              WHERE license_key = ?
              LIMIT 1
            `)
            .bind(
              licenseKey
            )
            .first();

        if (!license) {

          return json(
            {
              ok:
                false,

              error:
                "LICENSE_NOT_FOUND"
            },
            404
          );

        }

        // ----------------------------------------------------
        // REVOKED
        // ----------------------------------------------------

        if (
          license.status ===
          "revoked" ||
          license.status ===
          "banned"
        ) {

          return json(
            {
              ok:
                false,

              error:
                "LICENSE_BANNED",

              server_time:
                nowISO()
            },
            403
          );

        }

        // ----------------------------------------------------
        // EXPIRED
        // ----------------------------------------------------

        const expiresTime =
          new Date(
            license.expires_at
          ).getTime();

        const serverNow =
          Date.now();

        if (
          !Number.isFinite(
            expiresTime
          ) ||
          expiresTime <=
            serverNow
        ) {

          await env.DB
            .prepare(`
              UPDATE licenses
              SET status = 'expired'
              WHERE id = ?
            `)
            .bind(
              license.id
            )
            .run();

          const serverTime =
            nowISO();

          return json(
            {
              ok:
                false,

              error:
                "LICENSE_EXPIRED",

              server_time:
                serverTime,

              server_time_wib:
                formatWIB(
                  serverTime
                )
            },
            403
          );

        }

        // ----------------------------------------------------
        // SAME DEVICE
        // ----------------------------------------------------

        if (
          license.hardware_id &&
          normalize(
            license.hardware_id
          ) === hardwareId
        ) {

          const serverTime =
            nowISO();

          return json({

            ok:
              true,

            activated:
              false,

            message:
              "LICENSE_VALID",

            license_key:
              license.license_key,

            customer_name:
              license.customer_name,

            status:
              "active",

            hardware_id:
              license.hardware_id,

            created_at:
              license.created_at,

            activated_at:
              license.activated_at,

            expires_at:
              license.expires_at,

            revoked_at:
              license.revoked_at,

            server_time:
              serverTime,

            activated_at_wib:
              formatWIB(
                license.activated_at
              ),

            expires_at_wib:
              formatWIB(
                license.expires_at
              )

          });

        }

        // ----------------------------------------------------
        // DIFFERENT DEVICE
        // ----------------------------------------------------

        if (
          license.hardware_id &&
          normalize(
            license.hardware_id
          ) !== hardwareId
        ) {

          return json(
            {
              ok:
                false,

              error:
                "LICENSE_ALREADY_BOUND_TO_ANOTHER_PC",

              server_time:
                nowISO()
            },
            403
          );

        }

        // ----------------------------------------------------
        // FIRST DEVICE
        // ----------------------------------------------------

        const activatedAt =
          nowISO();

        const result =
          await env.DB
            .prepare(`
              UPDATE licenses
              SET
                hardware_id = ?,
                activated_at = ?
              WHERE
                id = ?
                AND hardware_id IS NULL
                AND status = 'active'
                AND expires_at > ?
            `)
            .bind(
              hardwareId,
              activatedAt,
              license.id,
              activatedAt
            )
            .run();

        // ----------------------------------------------------
        // SUCCESS
        // ----------------------------------------------------

        if (
          (result.meta?.changes || 0) === 1
        ) {

          const activated =
            await env.DB
              .prepare(`
                SELECT
                  license_key,
                  customer_name,
                  status,
                  expires_at,
                  hardware_id,
                  created_at,
                  activated_at,
                  revoked_at
                FROM licenses
                WHERE id = ?
                LIMIT 1
              `)
              .bind(
                license.id
              )
              .first();

          const serverTime =
            nowISO();

          return json({

            ok:
              true,

            activated:
              true,

            message:
              "LICENSE_ACTIVATED",

            license_key:
              activated.license_key,

            customer_name:
              activated.customer_name,

            status:
              activated.status,

            hardware_id:
              activated.hardware_id,

            created_at:
              activated.created_at,

            activated_at:
              activated.activated_at,

            expires_at:
              activated.expires_at,

            revoked_at:
              activated.revoked_at,

            server_time:
              serverTime,

            activated_at_wib:
              formatWIB(
                activated.activated_at
              ),

            expires_at_wib:
              formatWIB(
                activated.expires_at
              )

          });

        }

        // ----------------------------------------------------
        // RACE CONDITION FALLBACK
        // ----------------------------------------------------

        const current =
          await env.DB
            .prepare(`
              SELECT *
              FROM licenses
              WHERE id = ?
              LIMIT 1
            `)
            .bind(
              license.id
            )
            .first();

        if (
          current &&
          normalize(
            current.hardware_id
          ) === hardwareId &&
          current.status ===
            "active"
        ) {

          const serverTime =
            nowISO();

          return json({

            ok:
              true,

            activated:
              false,

            message:
              "LICENSE_VALID",

            license_key:
              current.license_key,

            customer_name:
              current.customer_name,

            status:
              current.status,

            hardware_id:
              current.hardware_id,

            created_at:
              current.created_at,

            activated_at:
              current.activated_at,

            expires_at:
              current.expires_at,

            revoked_at:
              current.revoked_at,

            server_time:
              serverTime,

            activated_at_wib:
              formatWIB(
                current.activated_at
              ),

            expires_at_wib:
              formatWIB(
                current.expires_at
              )

          });

        }

        return json(
          {
            ok:
              false,

            error:
              "LICENSE_ALREADY_BOUND_TO_ANOTHER_PC",

            server_time:
              nowISO()
          },
          403
        );

      }

      // ======================================================
      // VALIDATE
      // ======================================================

      if (
        path === "/validate" &&
        request.method === "POST"
      ) {

        const limited = rateLimitValidate(request);
        if (limited) return limited;

        let body;

        try {

          body =
            await request.json();

        } catch {

          return json(
            {
              valid:
                false,

              error:
                "INVALID_JSON"
            },
            400
          );

        }

        const licenseKey =
          normalize(
            body.license_key
          );

        const hardwareId =
          normalize(
            body.hardware_id
          );

        if (
          !licenseKey ||
          !hardwareId
        ) {

          return json(
            {
              valid:
                false,

              error:
                "LICENSE_KEY_AND_HARDWARE_ID_REQUIRED"
            },
            400
          );

        }

        const license =
          await env.DB
            .prepare(`
              SELECT *
              FROM licenses
              WHERE license_key = ?
              LIMIT 1
            `)
            .bind(
              licenseKey
            )
            .first();

        if (!license) {

          return json(
            {
              valid:
                false,

              error:
                "LICENSE_NOT_FOUND"
            },
            404
          );

        }

        if (
          license.status !==
          "active"
        ) {

          const serverTime =
            nowISO();

          return json(
            {
              valid:
                false,

              error:
                license.status ===
                "revoked" ||
                license.status ===
                "banned"

                  ? "LICENSE_BANNED"

                  : "LICENSE_NOT_ACTIVE",

              server_time:
                serverTime,

              server_time_wib:
                formatWIB(
                  serverTime
                )
            },
            403
          );

        }

        const expiresTime =
          new Date(
            license.expires_at
          ).getTime();

        if (
          !Number.isFinite(
            expiresTime
          ) ||
          expiresTime <=
            Date.now()
        ) {

          await env.DB
            .prepare(`
              UPDATE licenses
              SET status = 'expired'
              WHERE id = ?
            `)
            .bind(
              license.id
            )
            .run();

          const serverTime =
            nowISO();

          return json(
            {
              valid:
                false,

              error:
                "LICENSE_EXPIRED",

              server_time:
                serverTime,

              server_time_wib:
                formatWIB(
                  serverTime
                )
            },
            403
          );

        }

        if (
          !license.hardware_id ||
          normalize(
            license.hardware_id
          ) !== hardwareId
        ) {

          const serverTime =
            nowISO();

          return json(
            {
              valid:
                false,

              error:
                "HARDWARE_MISMATCH",

              server_time:
                serverTime,

              server_time_wib:
                formatWIB(
                  serverTime
                )
            },
            403
          );

        }

        const serverTime =
          nowISO();

        // Catat /validate yang berhasil sebagai aktivitas terakhir.
        // Migrasi hanya dilakukan di sini, SETELAH license valid, bukan pada
        // setiap request Owner sehingga halaman login tidak bisa macet karena DDL.
        try {
          await ensurePresenceSchema(env);

          await env.DB
            .prepare(`
              UPDATE licenses
              SET
                last_seen_at = ?,
                last_tool = COALESCE(?, last_tool),
                last_version = COALESCE(?, last_version)
              WHERE id = ?
            `)
            .bind(
              serverTime,
              normalize(body.tool) || null,
              normalize(body.version) || null,
              license.id
            )
            .run();
        } catch (e) {
          // Presence hanya fitur tambahan; jangan membuat /validate gagal.
          console.error("presence update failed", e);
        }

        return json({

          valid:
            true,

          status:
            "active",

          license_key:
            license.license_key,

          customer_name:
            license.customer_name,

          hardware_id:
            license.hardware_id,

          created_at:
            license.created_at,

          activated_at:
            license.activated_at,

          expires_at:
            license.expires_at,

          revoked_at:
            license.revoked_at,

          server_time:
            serverTime,

          activated_at_wib:
            formatWIB(
              license.activated_at
            ),

          expires_at_wib:
            formatWIB(
              license.expires_at
            )

        });

      }

      // ======================================================
      // HEARTBEAT
      // ======================================================

      if (
        path === "/heartbeat" &&
        request.method === "POST"
      ) {

        const limited = rateLimitHeartbeat(request);
        if (limited) return limited;

        let body;

        try {

          body =
            await request.json();

        } catch {

          return json(
            {
              valid:
                false,

              error:
                "INVALID_JSON"
            },
            400
          );

        }

        const licenseKey =
          normalize(
            body.license_key
          );

        const hardwareId =
          normalize(
            body.hardware_id
          );

        if (
          !licenseKey ||
          !hardwareId
        ) {

          return json(
            {
              valid:
                false,

              error:
                "LICENSE_KEY_AND_HARDWARE_ID_REQUIRED"
            },
            400
          );

        }

        const license =
          await env.DB
            .prepare(`
              SELECT *
              FROM licenses
              WHERE license_key = ?
              LIMIT 1
            `)
            .bind(
              licenseKey
            )
            .first();

        if (!license) {

          return json(
            {
              valid:
                false,

              error:
                "LICENSE_NOT_FOUND"
            },
            404
          );

        }

        if (
          license.status !==
          "active"
        ) {

          const serverTime =
            nowISO();

          return json(
            {
              valid:
                false,

              error:
                license.status ===
                "revoked" ||
                license.status ===
                "banned"

                  ? "LICENSE_BANNED"

                  : "LICENSE_NOT_ACTIVE",

              server_time:
                serverTime,

              server_time_wib:
                formatWIB(
                  serverTime
                )
            },
            403
          );

        }

        const expiresTime =
          new Date(
            license.expires_at
          ).getTime();

        if (
          !Number.isFinite(
            expiresTime
          ) ||
          expiresTime <=
            Date.now()
        ) {

          await env.DB
            .prepare(`
              UPDATE licenses
              SET status = 'expired'
              WHERE id = ?
            `)
            .bind(
              license.id
            )
            .run();

          const serverTime =
            nowISO();

          return json(
            {
              valid:
                false,

              error:
                "LICENSE_EXPIRED",

              server_time:
                serverTime,

              server_time_wib:
                formatWIB(
                  serverTime
                )
            },
            403
          );

        }

        if (
          !license.hardware_id ||
          normalize(
            license.hardware_id
          ) !== hardwareId
        ) {

          const serverTime =
            nowISO();

          return json(
            {
              valid:
                false,

              error:
                "HARDWARE_MISMATCH",

              server_time:
                serverTime,

              server_time_wib:
                formatWIB(
                  serverTime
                )
            },
            403
          );

        }

        const serverTime =
          nowISO();

        try {
          // Lazy migration: hanya saat client benar-benar mengirim heartbeat.
          await ensurePresenceSchema(env);

          await env.DB
            .prepare(`
              UPDATE licenses
              SET
                last_seen_at = ?,
                last_tool = COALESCE(?, last_tool),
                last_version = COALESCE(?, last_version)
              WHERE id = ?
            `)
            .bind(
              serverTime,
              normalize(body.tool) || null,
              normalize(body.version) || null,
              license.id
            )
            .run();
        } catch (e) {
          // Presence hanya fitur tambahan; jangan membuat /heartbeat gagal.
          console.error("presence heartbeat update failed", e);
        }

        return json({

          valid:
            true,

          status:
            "active",

          license_key:
            license.license_key,

          customer_name:
            license.customer_name,

          hardware_id:
            license.hardware_id,

          created_at:
            license.created_at,

          activated_at:
            license.activated_at,

          expires_at:
            license.expires_at,

          revoked_at:
            license.revoked_at,

          server_time:
            serverTime,

          activated_at_wib:
            formatWIB(
              license.activated_at
            ),

          expires_at_wib:
            formatWIB(
              license.expires_at
            ),

          // The client can render these messages if its heartbeat handler supports them.
          messages: await getClientMessages(env, license.id, 20)

        });

      }

      // ======================================================
      // UNKNOWN ENDPOINT
      // ======================================================

      return json(
        {
          ok:
            false,

          error:
            "ENDPOINT_NOT_FOUND"
        },
        404
      );

    } catch (error) {

      console.error(
        error
      );

      return json(
        {
          ok:
            false,

          error:
            error?.message ||
            "INTERNAL_SERVER_ERROR"
        },
        500
      );

    }

  }

};