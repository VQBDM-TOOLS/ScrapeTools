const PRODUCTS = new Set(["Scraper Tools V1", "BantuSaku Scraper Pro"]);

const $=id=>document.getElementById(id);
let hardwareId="";

// Extension-only device binding. No Windows agent/service is required.
// A random device ID is generated once and kept in chrome.storage.local.
// This is a browser-profile binding, not a true Windows hardware ID.
async function getHardwareId(){
  const key="device_binding_id";
  const saved=await chrome.storage.local.get([key]);
  if(saved[key]) return String(saved[key]).toUpperCase();
  const raw=crypto.randomUUID().replaceAll("-","").toUpperCase();
  const id="EXT-"+raw;
  await chrome.storage.local.set({[key]:id});
  return id;
}
async function getLicense(){
  const s=await chrome.storage.local.get(["license"]);
  return s.license||{};
}
async function serverStatus(key,hw){
  const r=await fetch(LICENSE_SERVER_URL+"/validate",{
    method:"POST",headers:{"content-type":"application/json"},
    body:JSON.stringify({license_key:key,hardware_id:hw})
  });
  let d={};try{d=await r.json()}catch(_){d={error:"Respons server tidak valid"}}
  if(!r.ok) throw new Error(d.error||`Server HTTP ${r.status}`);
  return d;
}
function parseExpiry(value){
  if(!value) return null;
  const s=String(value);
  const d=new Date(s);
  if(Number.isNaN(d.getTime())) return null;
  // Server returns ISO timestamps; date-only values are treated as end-of-day local time.
  if(/^\d{4}-\d{2}-\d{2}$/.test(s)){
    const [y,m,day]=s.split("-").map(Number);
    return new Date(y,m-1,day,23,59,59,999);
  }
  return d;
}
function formatExpiry(value){
  const d=parseExpiry(value);
  if(!d) return value||"-";
  return d.toLocaleString("id-ID",{dateStyle:"medium",timeStyle:"short"});
}
async function licenseInfo(){
  const lic=await getLicense();
  if(!lic.license_key) return {active:false,status:"BELUM AKTIF",expires:"-",days:null,key:"-",hw:hardwareId};
  try{
    const d=await serverStatus(lic.license_key,hardwareId);
    const end=parseExpiry(d.expires_at), now=new Date();
    const days=Math.max(0,Math.ceil((end-now)/86400000));
    return {active:true,status:"AKTIF",expires:formatExpiry(d.expires_at),days,key:lic.license_key,hw:hardwareId};
  }catch(e){
    const msg=String(e.message||e);
    if(msg.toLowerCase().includes("expired")) return {active:false,status:"EXPIRED",expires:formatExpiry(lic.expires_at),days:null,key:lic.license_key,hw:hardwareId};
    if(msg.includes("LICENSE_ALREADY_BOUND_TO_ANOTHER_PC") || msg.includes("HARDWARE_MISMATCH")) return {active:false,status:"DEVICE TIDAK COCOK",expires:formatExpiry(lic.expires_at),days:null,key:lic.license_key,hw:hardwareId};
    if(msg.includes("REVOKED")||msg.toLowerCase().includes("revoke")) return {active:false,status:"REVOKED",expires:formatExpiry(lic.expires_at),days:null,key:lic.license_key,hw:hardwareId};
    return {active:false,status:"SERVER TIDAK TERHUBUNG",expires:formatExpiry(lic.expires_at),days:null,key:lic.license_key,hw:hardwareId};
  }
}
async function refreshLicense(){
  const i=await licenseInfo();
  $("licStatus").textContent=i.status; $("licExpiry").textContent=i.expires;
  $("licDays").textContent=i.days==null?"-":`${i.days} hari`;
  $("licenseBadge").textContent=i.status;
  $("licenseBadge").className="badge "+(i.active?"ok":"off");
  $("start").disabled=!i.active;
  return i.active;
}
async function activate(){
  const key=$("licenseKey").value.trim().toUpperCase();
  if(!key){$("licenseMsg").textContent="Masukkan License Key.";return}
  try{
    const r=await fetch(LICENSE_SERVER_URL+"/activate",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({license_key:key,hardware_id:hardwareId,app_version:chrome.runtime.getManifest().version})});
    let d={};try{d=await r.json()}catch(_){d={error:"Respons server tidak valid"}}
    if(!r.ok){$("licenseMsg").textContent=d.error||`Aktivasi gagal (HTTP ${r.status}).`;await refreshLicense();return}
    await chrome.storage.local.set({license:{license_key:key,expires_at:d.expires_at,activated_at:new Date().toISOString()}});
    $("licenseMsg").textContent=`Lisensi aktif sampai ${formatExpiry(d.expires_at)}. Device terkunci di PC ini.`;
    await refreshLicense();
  }catch(e){$("licenseMsg").textContent=e.message||"Gagal terhubung ke License Server."}
}
async function clearLicense(){
  await chrome.storage.local.remove("license"); $("licenseKey").value="";
  $("licenseMsg").textContent="Data license lokal dihapus. Binding di server TIDAK dihapus; Owner harus Reset Binding jika ingin dipindahkan.";
  await refreshLicense();
}

async function activeTab(){
  const tabs=await chrome.tabs.query({active:true,currentWindow:true});
  return tabs[0];
}
async function pingTab(){
  const tab=await activeTab();
  if(!tab?.id) return false;
  if(!/^https:\/\/cco-agent\.bantusaku\.id\//.test(tab.url||"")) return false;
  try{
    await chrome.tabs.sendMessage(tab.id,{type:"PING"});
    return true;
  }catch(_){return false}
}
async function startScrape(){
  if(!(await refreshLicense())) return;
  const tab=await activeTab();
  if(!tab?.id || !/^https:\/\/cco-agent\.bantusaku\.id\//.test(tab.url||"")){
    $("status").textContent="Buka cco-agent.bantusaku.id pada tab aktif terlebih dahulu.";return;
  }
  try{
    await chrome.tabs.sendMessage(tab.id,{type:"START_SCRAPE",options:{
      tenantId:$("tenantId").value,pageSize:$("pageSize").value,maxPages:$("maxPages").value,
      retry:$("retry").value,caseFilter:$("caseFilter").value
    }});
    $("start").disabled=true;$("stop").disabled=false;$("bar").style.width="0%";
    $("status").textContent="Scrape dimulai...";
  }catch(e){$("status").textContent="Session/tab belum siap. Refresh halaman lalu coba lagi."}
}
async function stopScrape(){
  const tab=await activeTab(); if(tab?.id) try{await chrome.tabs.sendMessage(tab.id,{type:"STOP_SCRAPE"})}catch(_){}
  $("stop").disabled=true;$("status").textContent="Meminta penghentian...";
}
chrome.runtime.onMessage.addListener(msg=>{
  if(msg.type==="SCRAPER_PROGRESS"){
    if(msg.phase==="CASE") $("status").textContent=`Case page ${msg.page}: ${msg.total} case terkumpul`;
    else {
      const pct=msg.total?Math.round(msg.index/msg.total*100):0;
      $("bar").style.width=pct+"%";
      $("status").textContent=`Case ${msg.index}/${msg.total} • ${msg.users||0} user • ${msg.contacts||0} contact`;
      $("caseCount").textContent=msg.index||0;$("userCount").textContent=msg.users||0;$("contactCount").textContent=msg.contacts||0;
    }
  }
  if(msg.type==="SCRAPER_DONE"){
    $("stop").disabled=true;$("start").disabled=false;$("bar").style.width="100%";
    $("caseCount").textContent=msg.cases;$("userCount").textContent=msg.users;$("contactCount").textContent=msg.contacts;
    $("status").textContent=`Selesai. File hasil masuk ke folder download "${msg.folder}".`;
  }
  if(msg.type==="SCRAPER_ERROR"){
    $("stop").disabled=true; refreshLicense(); $("status").textContent="ERROR: "+msg.message;
  }
});
(async()=>{
  try{ hardwareId=await getHardwareId(); $("deviceId").textContent=hardwareId; }
  catch(e){ $("deviceId").textContent="DEVICE ID GAGAL DIBUAT"; $("licenseMsg").textContent=e.message; }
  const saved=await getLicense(); $("licenseKey").value=saved.license_key||"";
  if(hardwareId) await refreshLicense();
  $("siteNotice").innerHTML=await pingTab() ? "Session tab terdeteksi. <b>Siap scrape.</b>" : "Buka dan login ke <b>cco-agent.bantusaku.id</b> pada tab Chrome aktif.";
})();
$("activate").onclick=activate; $("clearLicense").onclick=clearLicense; $("start").onclick=startScrape; $("stop").onclick=stopScrape;